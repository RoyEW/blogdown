# Core Activity D — Evaluate and mitigate risk (15–25%)

**"I can" outcomes:** evaluate risks & responses / maintain the risk register · identify ethical dilemmas & responses · evaluate and mitigate cyber risks · recommend internal controls.

## Risk register — six required fields
1. **Risk description & impact** (causes + specific impact pathway)
2. **Likelihood and impact ratings** (e.g. 1–5 each) → prioritisation
3. **Overall risk rating** (likelihood × impact) → ranking
4. **Dates identified & review dates** → keeps register current
5. **Residual risk rating** (after mitigation → more action needed?)
6. **Risk owner** (named accountability — e.g. Marketing Director owns demand volatility)
Extras that score: **KRIs** (lead indicators — e.g. aggressive sales culture flags vetting compromise); board-defined **risk appetite**; **net vs gross risk** basis; remember **upside risk** too.

## Risk responses — TARA
**Transfer** (insure, outsource, hedge) · **Avoid** (don't do it) · **Reduce** (controls) · **Accept** (low likelihood/impact; or where mitigation costs exceed benefit — the economic-FX-risk argument).

## "Should this risk have been on the register?" debate (workbook D2)
FOR recognition: foreseeable strategic risk given high-impact technology; register too narrow (own-factory penalties only — missed customer-misuse reputational risk); no KRIs. WHY omitted (counters): external criminal act, hard to quantify post-sale; "trust" values create cognitive bias (risk deemed too remote); assessed net of assumed controls; **no board IT expertise** to explain exploitability; assumed Legal covered external liabilities. Then design the mitigation: technical preventative controls, KRIs, risk appetite, balanced-scorecard sales incentives (vetting accuracy, end-use audits — not volume-only).

## Cyber risk — six categories (have controls ready per category)
- **Strategic** — no board IT capability, behind the times → appoint IT Director/CTO oversight, board digital literacy
- **Economic** — dead money on poor systems / big data with no insight → accountant-led business cases, quantified deliverables
- **Availability** — outages, DDoS → test new systems; distribute apps/databases across regions; hot backup site (real-time mirror, geographically remote, bank-connected); communication plan; consultants on retainer
- **Security** — hacking, data loss/integrity → passwords, encryption, penetration testing, response plans, patch management
- **Compliance** — data/regulatory breaches → internal audit, legal monitoring of legislation
- **Performance** — slow systems → steering groups, outsource with SLAs

### Ransomware: pay or not? (Mock A 3b — model says DON'T pay)
No guarantee criminals decrypt · paying marks you as a repeat target · decryption raises criminals' capture risk so they won't bother · residual malware enables worse follow-up attacks/bank hijacking · counter-argument (hackers' "reputation" incentive) rebutted — victims keep hacks secret · governance angle: a ransom in the accounts signals weak controls; shareholders demand answers; directors risk removal. Rival attacked first? "Fortunate it hit a competitor — free lesson; audit our own vulnerability."

## Internal controls — DAMPSOAP (control menu)
**D**ivision of responsibilities · **A**rithmetic & accounting · **M**anagement · **P**ersonnel (vetting, references) · **S**upervision · **O**rganisation (structure, procedures) · **A**uthorisation (thresholds, senior sign-off) · **P**hysical (protection).
Kwirtmak-flavoured controls that recur: centralised independent vetting unit (outside sales line) with "hard block" despatch sign-off · digital-handshake certificates before printing regulated geometries (preventative + detective) · board-level IT Director ("security-by-design") · right-to-audit clauses + random usage audits reported to Audit Committee · authority matrix (e.g. >E$50m needs Board resolution + dual CEO/CFO signature) · ERP hard controls blocking single-signature commitments · emergency decision subcommittee (Chair+CEO+CFO) with 24-hour full-board ratification.

## Culture as a risk (the Kwirtmak special)
"**Trusts its staff**" and "**overdelivers on promises**" are values that keep causing incidents (relaxed encryption, bypassed KYC, split invoices, unauthorised E$400m order). Standard lines: **trust is not a control — "trust but verify"** · a culture value without defined boundaries empowers managers to compromise controls for local gains · aggressive targets are a **KRI** for corner-cutting · fix incentives (safety/compliance as a **gatekeeper** for any bonus; 'Safety Gate': any bypass = department-wide bonus forfeiture + automatic disciplinary proceedings) · tone at the top.

# Ethics (examined within D)

## CIMA Code — five fundamental principles (define, then apply to the person's own words)
- **Integrity** — straightforward and honest; **omission = lying by omission** if the fact is material to the deal; don't be associated with misleading information.
- **Objectivity** — no bias, conflict of interest or undue influence; "nervous about losing the contract" = conflict of interest overriding judgement; "shareholders' interest" never justifies misleading on safety-critical matters.
- **Professional competence & due care** — maintain knowledge; act diligently; due care can *require* telling an affected client so it can protect itself.
- **Confidentiality** — don't disclose or exploit business information; but it never justifies hiding negligence that endangers a client — and it's futile if the press is about to break the story.
- **Professional behaviour** — comply with law/regulation; avoid anything discrediting the profession/company; hoping to fix a problem before launch does not excuse a lie.
Balance point that scores: the counterparty's own failings (e.g. weak due diligence) **never excuse** deception — they *increase* your ethical burden. State it, then rebut it.

## Bribery (Mock B 3a — pair each principle with a THREAT)
- **Integrity ↔ self-interest threat**: a "quid pro quo" demand (fund X or lose your permit) forces buying what is already legally yours; participating in a corrupt process "even for a good cause" contradicts trusted-provider values.
- **Objectivity ↔ advocacy threat**: coercion pressures you to fund/promote a third party's (political) agenda; judgement no longer neutral or in shareholders' financial interest; sets a precedent — future decisions clouded by political pressure.
- **Professional behaviour ↔ legal breach**: apply the strictest standard (UK Bribery Act or similar) — **motive is irrelevant**: intent to influence a public official for commercial advantage is a corporate offence; facilitation payments are also prohibited.
- **Transparency**: hiding the payment inside another budget = a *second* breach — misrepresenting financial data to auditors and investors; proper disclosure would itself attract damaging attention.
- **Self-review threat**: a Board that knowingly compromises a process cannot objectively oversee/audit it later.
- **Public interest + consequence chain**: duty to uphold the rule of law → permanent reputational "stain" → further depresses an already-low share price → long-term damage outweighs the short-term strategic benefit.

## Responding to an ethical dilemma (action list)
Transparency & proactive disclosure ("radical honesty" before the press breaks it) · express empathy/awareness of harm · communicate with victims and regulator · compensating actions · remedial action (state the fixes made) — accountability is what a "trusted provider" looks like; **brand protection never justifies ignoring ethics**.

Practice: [[QB - Mock Exam A]] Tasks 1b & 3b · [[QB - Mock Exam C]] Task 3 · [[QB - Practice Workbook Tasks]] D1, D2, CH7-EX · [[QB - Mock Exam D]] Task 3 · Flashcards: [[Flashcards - D Risk & Ethics]]
