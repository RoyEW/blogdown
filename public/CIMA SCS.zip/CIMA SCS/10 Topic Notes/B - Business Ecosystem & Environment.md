# Core Activity B — Business ecosystem & environment (15–25%)

**"I can" outcomes:** recommend financial/non-financial/sustainability objectives · apply strategic analytical tools · stakeholder-needs analysis · respond to ecosystem changes · recommend KPIs · respond to economic, political and currency risks.

## Analytical tools
- **PESTLE** — Political (legislation, regulators, H&S duty of care), Economic (rates, inflation, FX, demand cycles), Social (medical reliance, customisation culture, skills shift to CAD), Technological (rapid prototyping, five print technologies, material innovation, CAD-interface churn), Environmental (less waste, localisation, recyclability, kWh/kg), Legal (product liability, EHS approvals, IP).
- **Porter's Five Forces** — entrants, buyers, suppliers, substitutes, rivalry.
- **Scenario planning** — model megatrends/drivers; per scenario: impact → leading indicators to monitor → short-term liquidity response (sensitivity cash-flow forecasts, worst-case overdraft) → medium-term structural response → pre-arranged relationships (banks, consultants on retainer). See [[QB - Mock Exam A]] Task 3a.

## Stakeholder analysis — Mendelow power/interest
Assess **interest** (how much the outcome affects them) and **power** (ability to influence) — then manage by quadrant:
- Low power/low interest → minimal effort · High power/low interest → keep satisfied
- **Low–medium power / high interest → "keep informed"** — empathy, clear communication, redundancy packages (protects reputation)
- **High power / high interest → "key players"** — direct consultation, mitigation and transition plans
- **Power is contextual**: employees' power rises if unionised/collective action can disrupt production or attract national attention (but short-lived if the site is closing anyway); a government's power rises if we have other in-country interests (licences, audits, legal challenges, customers) and falls if it's a manufacturing base only. Governments can't force us to keep trading.
- Other host governments are watching how we treat this one → global reputation.

## Political risk (Mock B pattern — investing in a developing economy)
Risk menu: **government change/election cycle** (negotiate under one regime, operate under the next; grants may be branded "unfair corporate handouts" by a populist successor → policy reversal, retrospective tax, repayment demands) · **expropriation of physical assets** (weaker legal protection for foreign firms) · **forced technology transfer** (the bigger threat for a tech firm — mandated sharing of proprietary designs as a "cost of doing business") · **border/transfer restrictions** (unrest or diplomatic disputes stop people, materials, prototypes crossing → isolates the facility) · civil unrest.
Mitigations: **good corporate citizenship** (local high-skilled jobs, university links, preventing brain drain → politically costly to attack; government will publicise the investment) · **local financing as a political shield** (local bank becomes an ally — it lobbies against expropriation to protect its loan) · join a broader FDI trend.

## CSFs and KPIs
KPIs must be **SMART** (specific, measurable, attainable, relevant, time-bound). For breadth use the **Balanced Scorecard** (examiner explicitly praised it): Financial (ROCE per project, net margin by product line) · Customer (market share in target sector, retention/repeat purchases — printers + materials ecosystem) · Internal process (compliance pass rate, CAD-to-print lead time) · Learning & growth (time to regulatory certification, % staff trained in new standards). Formula per KPI: **name it → what it measures → why it matters for THIS venture** (link a scenario number). Entering a regulated sector? Always include a regulatory-approval-speed KPI and a staff-training KPI.

## Economic risk — interest-rate rises (four risk buckets, then responses)
1. **Cost of debt & gearing** — compute: current gearing, post-borrowing gearing, implied interest rate (108/1,350 = 8%), sensitised interest cost ("at say 10% on E$3,350m = E$335m, +210%") → margin and dividend threat.
2. **Demand suppression** — printers are customer CapEx; dearer financing → deferred upgrades → lower sales.
3. **Currency** — higher rates → stronger E$ → exports dearer → share loss to weak-currency rivals.
4. **WACC/NPV** — higher rates → higher WACC → projects flip to negative NPV.
Responses: fix the rate (fixed-rate bonds, interest-rate swaps); phase/modularise capex (delay drawdown, exit points — caveat feasibility); customer leasing/financing to protect volumes; natural hedging via overseas production. Monitor indicators (inflation) to forewarn the Board; maintain lender relationships.

## CapEx-freeze response playbook (workbook B2a)
1. **Pivot to non-cyclical sectors** — healthcare/medical still investing (inelastic demand); redeploy marketing/salespeople; don't abandon industrial capacity entirely.
2. **CapEx→OpEx models** — ≤12-month leases / machine-as-a-service; fixed monthly or usage fees bypass customers' CapEx freezes; recurring predictable revenue for us — BUT upfront manufacturing cost vs drip-fed cash → **model working capital** (E$136.2m cash + facilities).
3. **Maximise aftermarket** — consumables (compatibility loyalty), long-term supply contracts, volume discounts, maintenance packages for ageing machines.
4. **Sell software/hardware upgrades** — extend machine life, efficiency retrofits (32% energy cut) → high-margin revenue.

## Currency risk — the three types (know cold)
- **Transaction** — short-term: specific invoices/payments in foreign currency; volatility changes the home-currency value of receipts/costs. Hedging menu: invoice in E$; leading/lagging payments; **real/operational hedging** (make where you sell — but political risk); foreign-currency borrowing / money-market hedge; **forward contracts** (certainty, maybe bad rate); **futures** (perfect hedge, lose upside); **options** (keep upside, pay premium); **swaps** (counterparty risk).
- **Translation** — accounting exposure: foreign net assets/profits consolidated into E$; strong E$ → unrealised losses reduce group equity (2026: **E$44.3m currency-reserve loss**; expect larger after a 15% appreciation). Possible hedge = **matching** (fund foreign assets with local-currency debt). **Model recommendation: do NOT hedge** — non-cash, no cash-flow impact; spending real cash (forwards) to hedge paper losses is inefficient; restructuring E$1,350m debt not commercially justified. Instead **manage investor relations** — annual-report narrative explaining it's translation mechanics, not poor performance.
- **Economic** — long-term effect of FX on the PV of future cash flows and competitiveness. Strong E$ + E$ cost base → hold prices and lose share, or discount and erode margin (already 50.6% from 56.4%). Partial offset: imports get cheaper. **Model recommendation: DO mitigate** — derivatives can't hedge an indefinite global position, so use (1) **operational hedging** — shift manufacturing/sourcing to the three overseas factories to align cost currency with revenue currency; (2) **value-based pricing** not discounting — sell total cost of ownership (32% energy cut, less waste, technical advice) to defend premium pricing; a price war damages premium brand equity.

### Challenges of *understanding* economic exposure (Mock A 1a)
Concentration hard to quantify (41% Westland); customers may hedge themselves; demand may be price-inelastic (mission-critical spares); 90-country fragmentation unmodellable; capital purchases can be deferred; contract terms differ by customer size; competitor home-currency mismatch and unknowable pricing response; multi-country factories = partial natural hedge, but **weak when GP margin is high (64.3%)** — costs too small to offset revenue swings.

### Accept vs mitigate economic risk (Mock A 1b)
Accept: high margin buffers volatility; hedging cost may exceed benefit for unquantifiable long-term risk; existing natural hedges (factories + 90-country portfolio); pragmatism. Dangers: structural pricing-out of concentrated market; relies on brand loyalty holding. Mitigate: investor perception/beta 2.3, pricing consistency for key clients. Against mitigating: operational hedges are costly/irreversible; lose upside; strategic distraction. **Middle ground: reject factory relocation, use targeted financial mitigation (currency-matched debt on the 41% W$ exposure).**

Practice: [[QB - Mock Exam A]] Tasks 1 & 3a · [[QB - Mock Exam C]] Tasks 1b & 2b · [[QB - Practice Workbook Tasks]] B1, B2, PESTEL · Flashcards: [[Flashcards - B Ecosystem]]
