# Core Activity E — Internal control environment (15–25%)

**"I can" outcomes:** apply internal audit resources · recommend controls & evaluate compliance failures · respond to threats from poor governance.

## Internal audit (IA)
**Definition**: independent appraisal of the design and operation of controls; investigates and **reports to management/the board — it does not fix systems itself**.
**Independence problems**: IA depends on management for jobs → report to an **Audit Committee of independent NEDs**, not through executives; rotate/"stranger" teams between sites; consider outsourcing; watch the **self-review threat** (IA can't objectively investigate what IA previously audited/missed — defensive reporting risk).

**Types of audit**: systems-based (does an appropriate system exist/work? what limits it?) · **risk-based** (resources to highest inherent risk) · substantive procedures (test transactions/balances where controls broke) · compliance (statutory/accreditation) · social & environmental · management audits (targets, delegation, competence, decision information) · post-completion review (lessons after projects).

**Deploying IA — step sequence**: staff competent & independent? → research/map existing procedures → assess **adequacy** of system design (vs industry practice) → assess **operation** (test real outputs) → communicate findings to management.

**Forensic investigation approach** (workbook E2): forensic, risk-based, advisory, objective → widen the search beyond the incident (other departments/regions) → **preserve evidence** (read-only system logs) → urgent timetable + immediate preliminary report (board can act early) → sceptical interviews tested against digital footprints → root-cause analysis (system flaw vs culture/bonus design) → fact-check with CFO → final report with permanent system fixes + **6-month follow-up**.

**Test types** (compliance = test the process; substantive = test transactions/assets):
- Compliance: ERP exception reports (purchases missing mandatory codes) · authorisation-limit testing (clusters just below thresholds) · PO sequencing (rapid same-supplier splits = premeditation) · access-rights audit (who could miscode without alert?)
- Substantive: supplier bank-detail matching vs approved list · physical stock-to-record verification (trace batch numbers) · digital forensics (email keyword search: "split", "sundry", "bonus") · data-pattern mining (invoices under oversight triggers)

**"Should IA investigate individuals?"** FOR: knows the control framework; already security-cleared → fast; pinpoints policy/training fixes; accountability = deterrence; isolated vs systemic. AGAINST: IA as "police force" kills psychological safety → blame culture hides future errors; forensic HR work may exceed IA's proper scope; distracts from root cause (board's own deadline-vs-risk balancing); **self-review threat**.

**Audit Committee commissioning checklist**: independence/reporting lines first (bypass conflicted executives) · materiality threshold (any safety bypass = material regardless of value) · management override & culture pressure · resources/competence (joint IA+QA, forensic specialists) · when to notify external auditors/regulators (protect licences) · whistleblowing amnesty · **interim directive** (quarantine suspect inventory NOW) · tone at the top.

**Anti-bribery audit programme** (Mock B 3b — each step: what IA does + the fraud pattern it detects + scenario link):
1. **Risk assessment & control environment first** — tone at the top of the local operation; are anti-bribery policies communicated to local staff/contractors? Weak environment ⇒ more substantive testing.
2. **Forensic review of third-party intermediaries** — bribes hide as "success fees"/"consultancy charges" to agents who "smooth over" planning; verify due diligence, valid contracts, fees commensurate with work.
3. **Physical-to-financial reconciliation** — site visits comparing build progress to contractor invoices; detects ghost employees and inflated material costs generating cash for bribes.
4. **Facilitation payments / local expense testing** — petty cash and the local manager's accounts; official stamped receipts; investigate "sundry"/"misc" items (facilitation payments illegal under UK Bribery Act-style law).
5. **Data analytics** — round-sum payments, duplicate invoices, payments just below authorisation limits.
6. **Whistleblowing channel** — hotline accessible and communicated locally; confidential staff interviews (early-warning system for extortion).
7. **Report directly to the Audit Committee** — independence of the reporting line.

## Corporate governance (principles-based, UK-style)
- **Board balance**: equal executives and independent NEDs; strong independent element to challenge the CEO. *Kwirtmak: 5 ED vs 3 independent NEDs — imbalanced.* Adding an ED worsens it; restoring balance needs 2+ new NEDs (cost, months of searching, interim non-compliance).
- **CEO ≠ Chair** — Kwirtmak complies (Wallace/Fedele).
- **Audit Committee**: independent NEDs, **≥1 with recent & relevant financial experience** (Kwirtmak's NEDs: economist, academic, tech entrepreneur — gap; an accountant CFO doesn't fix the NED side). **Chair should not sit on it** (Fedele does). Chair on Remuneration Committee also discouraged.
- **Committees**: Audit, Risk & CSR, Remuneration, Nomination — Kwirtmak's four have **identical membership** (poor practice); combined Risk+CSR risks shortchanging both.
- **Independence threats**: familiarity via shared university ties (UCC: Wallace/Abouchdak/Usta; CCU: Wallace/Fedele — plus Fedele on the CCU Senate = fiduciary conflict).
- Director shareholdings align interests, reduce agency costs; but principal–agent problems mean pay must be set by the **Remuneration Committee**, appointments by the **Nomination Committee** (not the CEO/CFO).
- Skills gaps to recommend: **IT/Cyber Director (urgent)** · CSO · HR Director · CRO/CCO · supply-chain expertise.

## Board appointment questions (nomination committee logic)
It's the **Nomination Committee's decision** (never one director's, never pre-agreed with a big shareholder). Assess: what role will they actually perform · independence (no favour to either merging party; NEDs whose jobs were "guaranteed" by a CEO are compromised) · skills/experience balance across the combined businesses · time commitment vs existing responsibilities · personality/culture fit — a board must challenge ideas without being permanently conflicted · a domineering chair needs counterweights.
**Specialist NED (e.g. cybersecurity) for/against**: FOR — independent technical "constructive challenge"; relieves an overloaded executive; elevates the domain to a strategic risk; "fresh eyes" free of familiarity threats satisfy client due diligence. AGAINST — others may "switch off" (governance is collective; the NED should catalyse whole-board literacy); a part-time NED can't fix day-to-day management gaps (may need a full-time executive too); an executive alone worsens balance. **Balanced answer: appoint BOTH an executive (daily management) and a NED (oversight + balance)** — two salaries justified by the contract at stake.

## How NEDs enforce mission/vision (workbook E1b)
- **Audit/Risk Committee**: widen remit beyond financial reporting; don't rely on executive assurances — mandate IA/third-party **unannounced site visits and technical inspections** (prevents "mission drift").
- **Remuneration Committee**: the primary realignment tool — replace volume-only bonuses with stretching **non-financial KPIs** (data-security accreditation, product integrity, ethical compliance) tied to long-term incentives = tone at the top.
- **Board/Nomination Committee**: constructive challenge as fiduciary duty; skills-matrix review; **formal board training** (digital literacy to interpret technical audits); report enhancements in the Annual Report to reassure institutional investors.

## Unauthorised executive action (Mock C 3a pattern)
Implications: breached **Matters Reserved for the Board** · time-pressure excuse rejected (negotiate a consultation window or decline) · bypassed NED scepticism + CFO oversight · **sunk-cost bias** forces the Board's hand · asset may be unnecessary if plans change · fiduciary duty breached · mission/vision/values are no defence ("opportunity is no excuse for a governance breach"; **trust ≠ unregulated authority**; not a "team player").
Fixes: Remuneration Committee reflects it in the bonus · consider (and weigh) resignation — signal severity · authority matrix (>E$50m = Board resolution + dual CEO/CFO signature) · hard ERP controls · **Emergency Decision-Making Policy** (Chair+CEO+CFO subcommittee, full-Board ratification within 24h).

## Discipline & clawbacks (workbook E2b)
FOR: explicit ethical-integrity clause breached; premeditation (order splitting); clinical harm; gross misconduct in safety-critical manufacturing; bonuses earned under false pretences → clawback justified. MITIGATION: "meet the numbers at any cost" culture; fear for livelihoods; the executive-designed incentive scheme created the conflict → punishing juniors = **scapegoating** + unfair-dismissal exposure. REFORM: Remuneration Committee signs off all incentive schemes; detailed policies replace vague "trust"; **'Safety Gate'** — any bypass = automatic department-wide bonus forfeiture + formal disciplinary proceedings.

Practice: [[QB - Mock Exam A]] Task 2b · [[QB - Mock Exam C]] Task 3a · [[QB - Practice Workbook Tasks]] E1, E2, CH8-EX · [[QB - Mock Exam D]] Task 3 · Flashcards: [[Flashcards - E Controls & Governance]]
