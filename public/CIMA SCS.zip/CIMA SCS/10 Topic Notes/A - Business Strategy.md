# Core Activity A — Develop business strategy (15–25%)

**"I can" outcomes:** evaluate strategic options · recommend strategic decisions · evaluate acquisitions/divestments · respond to digital technology opportunities/threats · respond to sustainability issues.

## SAF — the default evaluation framework (Johnson & Scholes)
Define each criterion before applying it (definitions score):
- **Suitability** — is the strategy consistent with the company's position and strategic direction? (strategic fit, addresses the issue, resource redeployment logic, mission/vision fit, fit with existing competences)
- **Acceptability** — is it consistent with stakeholder aims? (returns, risk, reactions — weigh the principal stakeholder, shareholders, against employees/government/customers)
- **Feasibility** — do we have the resources to do it? (finance: cash E$136.2m + debt headroom; logistics/capacity; legal compliance; skills)
- **Conclude explicitly against all three**, then recommend. Have SWOT, risk and stakeholder points ready to feed in.

## Evaluating an acquisition (checklist of argument families)
**For:**
- Strategic/reputational fit — target's reputation absorbed; enhances innovation/quality brand image
- **Related diversification = lower risk** than unrelated (we understand the industry — 30+ years in 3D printing)
- Acquire skilled/motivated workforce and their expertise immediately (vs building in-house)
- Order pipeline adds value from day one → share price/shareholder-wealth reassurance
- Target in a growth segment (e.g. carbon fibre: light + strong; aerospace/automotive/sporting goods)
- Customer synergies — cross-sell as the target's medium-sized clients grow into our larger machines
- Negotiating strength if seller distressed (deadline, refused loans) → buy at good value

**Against:**
- Lenders' refusal to lend may signal deeper problems → **full due diligence** on historic & forecast cash flows before any offer
- The asset you're buying may evaporate — employee-owners lose their stake → motivation falls, staff leave
- **Valuation risk / bidding war** (Breskko sniffing around) → competition inflates price → don't overpay
- Management time distraction harms core operations of buyer AND seller
- Alternative: wait for insolvency and buy cheaper — but a rival may complete a deal first
- Unverified quality/internal controls at the target → could damage our premium brand → investor concern → share price/WACC

**Post-acquisition problems:**
- IT/system integration long and arduous (no IT Director!); unknown quality of target's management information
- Staff who lose equity → demotivation/turnover → mitigate with **share-for-share exchange** (but may aggrieve our own staff without a scheme)
- Redundancy fears → pre-emptive departures → public job-security messaging + growth/career narrative
- **Cash drain**: consideration goes to the sellers, NOT into the target; acquirer must also fund the target's debts → is E$136.2m enough or is fresh capital needed? (Bank may extend facility with a parent-company guarantee)
- Cultural clashes; sustainability fit unexplored

## Corporate re-shaping menu
Organic/internal growth · external growth (acquisition) · joint development/alliances · disposal (part or whole). Reasons to acquire: consolidate market, buy technology/skills/pipeline, speed. Reasons to dispose: better return on liquidated funds, focus.

## In-house R&D vs buying capability (Mock D pattern)
For in-house: keep 100% of benefits; cost control with familiar R&D disciplines; serendipitous spin-off applications & possible own patents; builds internal skills. Against: up-front cost + time (shareholders impatient with depressed share price); behind the first-mover; lack of industry expertise/connections; may duplicate work purchasable at a discount; patent-infringement analysis costs; distracts marketing/management; appraise against other R&D projects via NPV at WACC.

## Digital strategy
Technology disruptors: AI · cloud/mobile · IoT · big data · blockchain · data visualisation · 3D printing · process automation.
Impacts: business model, structure, people/skills, processes, better customer offerings, customised engagement.
Responding to digital threats: **hyperawareness · perpetual innovation/adoption · customer-centricity**.
Evaluate any digital proposal with SAF (see the app example: cheap pilot to test engagement ≠ a full digital strategy).

## Sustainability strategy evaluation (brand-new "I can" — highly likely)
Structure: **Benefits vs Risks → preliminary conclusion**, then deploy Kwirtmak's existing record (see [[Kwirtmak Key Facts]] §Sustainability).
- Benefits: public statement of intent; meets customers' own supply-chain sustainability expectations (may actively shape their buying); restores competitive position (Breskko's PLA push = 30% of its mix while we fell 19%); consistency with the "sustainable manner" vision → avoids greenwash accusations → ecosystem trust; attracts ESG investors → demand for shares → share price ↑ → WACC ↓.
- Risks: cost to customers (PLA 25% dearer — worst for thin-margin high-volume users); up-front investment (development, production, marketing) → full financial appraisal, may need fresh capital; **challenge arbitrary targets** (why 50%? why 4 years? research feasibility — neither too demanding nor unambitious).
- Don't commit expediently because of press pressure — recommend Board debate with proper research, and respond to journalists with the existing 5-pillar sustainability record.

## Mission/Vision/Values consistency questions (Mock B pattern)
- **Dissect the statement phrase by phrase**; offer more than one plausible interpretation of ambiguous words ("transform its customers" = shape what customers want; "sustainable manner" = sustainable products OR sustainable operations; "overdeliver" = faster delivery or unexpected functionality) and evaluate against each.
- **Test the vision against current performance**: "leading provider" = highest revenues — Kwirtmak is NOT currently achieving it (revenue −18.8%, Breskko overtook it) → a proposal that closes the gap is consistent.
- Values: map "creates wealth and success" across ALL stakeholders (employees' job security, customers' output, suppliers' volumes, shareholders' long-term equity — acknowledge short-term cost); "innovations driven by customer need" → consistent **only if** customer needs stay at the research core (sophistication without demand has no value); people values → honest verdict "consistent, but not in any new or unique way" scores.
- Conclude + recommend next step ("recommended for further Board discussion / full financial appraisal").

## First-mover / new-market entry arguments (Mock C pattern)
- Market size vs our scale ("E$10bn potential vs our E$2.32bn revenue")
- First mover: brand + early regulatory approvals = barriers to entry; rivals face the same lead time, so speed decides
- Government preference for local suppliers → leverage board's government links (Fedele, Rothenberg)
- Mission/vision alignment; fit with existing precision/quality competences reduces failure risk
- Against: financial exposure vs total assets (E$2bn > half of E$3.79bn); execution/lead-time risk (18 months of outflows; market/tech can shift); new-competency risk (sterile ops = higher costs + compliance CSF; a hygiene failure destroys sector reputation); timing vs declining performance (announce carefully, use PR experts); raises the already-high beta 2.3
- **Always close**: "a full financial appraisal must be conducted before any final decision."
- L3 habit: counter your own argument ("However, this is true of any project and so is not itself a reason to reject...").

Practice: [[QB - Practice Workbook Tasks]] A1, A2 · [[QB - Mock Exam C]] Task 1 · [[QB - Mock Exam D]] · Flashcards: [[Flashcards - A Strategy]]
