# Core Activity C — Financing strategies (15–25%)

**"I can" outcomes:** recommend sources of finance · recommend dividend policy · recommend and apply business valuation models.

## Sources of finance
- Internal: retained profits (**pecking order theory: cheapest, least disruptive — use first**, then debt, then new equity).
- Short-term: overdraft (flexible, expensive), commercial bills, debt factoring.
- Long-term: term loans, corporate bonds, mezzanine/convertibles, leasing, sale-and-leaseback, equity (rights issue, placing).
- **Debt vs equity**: debt is quicker, tax-deductible, repayable, no dilution — but adds financial risk, needs cash for interest, depresses cash flow. Equity is permanent, no repayment pressure — but dilutes control/voting, costly to raise, and "cash has an equity cost" (shareholders expect a return). Mix to minimise **WACC**.
- **Capital-structure considerations**: business risk & security; flexibility; tax; **currency (raise debt in the currency of the assets/revenues it funds — matching)**; market sentiment; debt capacity evidence (gearing 39.1% vs Breskko 29.9%; interest cover 10.9x falling).

## Borrowing in a foreign currency (Mock B 2b pattern)
**For:** local goodwill — planning/permits smoother when funds are raised locally; a local bank accepts the local facility/land as security more readily than a home bank facing cross-border foreclosure risk → lower rate; debt cheaper than equity; interest tax-deductible → tax shield on local profits (compare tax rates across jurisdictions); the local bank becomes a **political ally** (threat of default on a big loan makes it lobby against expropriation/punitive taxes).
**Against:** **FX risk is the most significant** — an R&D centre is a *cost centre* with no local-currency revenue → no natural hedge; must continuously convert E$ to service the loan; if the local currency strengthens, servicing cost rises. International Fisher Effect (higher rates offset by depreciation) exists in theory but "relying on it in a developing economy is incredibly dangerous" — emerging currencies suffer sudden violent volatility. Also **strict covenants** likely (dividend blocks, local liquidity requirements) → restrict *global* financial flexibility.
Always name the currencies and amounts, and say which disadvantage is the most significant and why.

## Rights issues (workbook C2)
- Must be priced at a **discount** to encourage take-up. If market price falls below issue price during the offer → shareholders buy in the market instead → **issue fails**.
- **TERP**: discounted shares dilute price and future EPS; total value rises by cash raised but per-share metrics fall — retail investors may misread TERP as real loss and sell.
- **Signalling risk**: huge issue from a struggling firm (E$1.2bn ≈ 57% of equity) reads as a desperate bailout.
- Remedies: **deep discount** (cushion against price falls — accept dilution); **underwriting** (banks guarantee take-up; fees high for volatile stock, an "insurance premium"; deep discount lowers underwriters' risk); **positive signalling** (IR campaign framing proceeds as high-margin strategic investment).

## Dividend policy
Four types: constant amount (predictable, but inflexible and a missed payment screams trouble) · constant % of profits (volatile, may drive short-termism) · residual (invest first, pay out what's left) · zero/growth.
Setting policy considerations: **profit stability · growth/investment plans · signalling effect · clientele effect** (change policy and your investor base sells) · cash preservation vs "bribing" investors.
- **Signalling**: the most visible board signal. Maintaining a dividend despite falling profits (Kwirtmak 53% payout) signals stability; a sudden cut to zero signals panic — in a hostile bid it validates the bidder's "severe decline" narrative.
- **Clientele**: income-reliant investors sell if cut — and in a takeover the ready buyer is the bidder → cutting the dividend literally hands over control.
- Hostile-bid conclusion pattern: **survival first — maintain the dividend**; fund strategy via debt restructuring, selling non-core assets, targeted innovation financing.
- Breskko contrast: ~70% payout = confidence signalling; Kwirtmak's 53% = prudence/retention for R&D.

## Business valuation methods (know all five + when each flatters)
1. **Net assets** — floor/minimum value; ignores brand, staff, earning potential. **Replacement-cost variant**: what it would cost a bidder to replicate PP&E (E$2,551.3m), undervalued intangibles (patents, software, E$497.2m book), factories, barriers to entry → exposes asset-stripping bids.
2. **Dividend valuation (DVM)** — PV of future dividends; useless if target pays none (use that in negotiation to argue price down).
3. **DCF / PV of future cash flows** — most robust; captures R&D pipeline (E$270m/yr) and recovery plans; caveats: forecasting risk, and beta 2.3 → high WACC discount rate.
4. **P/E multiple** — use comparable-company P/E × earnings; **normalise earnings** (average 3–5 years) rather than depressed current profit, or you play into a hostile bidder's narrative; support with historical price highs (E$400+ vs E$55 offer).
5. **Synergies** — justify paying above stand-alone value; quantify before offering.
Plus negotiation adjustments: minority-stake discount (30% holding = limited influence — check if we'd be largest shareholder, get board representation); distressed-seller discount; competing-bidder premium risk.

## Share price, EMH and beta (common exam question)
- **EMH**: price = PV of expected future cash flows given available information. Weak form (past prices) · semi-strong (all public info — the exam's working assumption) · strong (all info incl. private).
- **Factors moving share price**: expectations of future free cash flow; perceived risk (→ cost of capital); dividend policy; speculation/rumour; systematic (market-wide) factors.
- **Announcement playbook** (Mock C 2a): market reacts to perceived NPV — negative drivers are unconvincing viability, materiality without appraisal (E$2bn > half of assets), risk perception (beta 2.3, regulator), debt funding amid rising rates, and looking like an impulsive reaction to a 6% price fall. **Protect the price**: delay until appraisal/funding certain; brief investors/analysts on existing strengths; balance disclosure vs commercial confidentiality (Breskko copies); absolute honesty — never present potential market size as guaranteed revenue.
- **Beta/CAPM**: beta = systematic (market-wide, undiversifiable) risk measured empirically vs the local index; market beta = 1; Kwirtmak 2.3 = 130% more volatile. **Equity beta = business risk + financial risk**; ungeared asset beta ≈ 1.55. Currency exposure is **unsystematic** (diversifiable by pairing with inversely-exposed stocks) → shouldn't drive beta; only an empirical study across comparable multinationals could prove a link. **Translation losses are accounting entries, not cash flows → shouldn't move share price or beta.**
- **What raises beta**: concentrating in a cyclical sector (pure-play aerospace pivot — locks cash flows into aviation cycles); higher **operating gearing** (fixed-cost-heavy capex amplifies profit volatility); higher financial gearing. Chain to rehearse: **beta ↑ → cost of equity ↑ (CAPM) → WACC ↑ → NPV ↓ → "high margins" may still destroy shareholder wealth if cash flows don't beat the higher discount rate.**
- Cost of capital drivers: general interest rates (debt); beta/gearing (equity); risk profile → reducing risk lowers WACC and lifts share price (use as a "so what" everywhere).

Practice: [[QB - Mock Exam A]] Task 2a · [[QB - Mock Exam C]] Task 2a · [[QB - Practice Workbook Tasks]] C1, C2, EX2, EX3 · [[QB - Mock Exam D]] Task 2 · Flashcards: [[Flashcards - C Financing]]
