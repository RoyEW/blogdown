1. a. SAF frame on acquisition
	1. Premium components, high quality
	2. Area for growth
	3. Techincal skills and combined learning across teams
	4. They have a patent for Northland but may not be granted globally
	5. Preferred supplier to to Alpha, good brand awareness, but may not pay off, preferred supplier may become lucrative contract
	6. Why is she looking for investors? Maybe lack of current revenue and market share even if they have the competitive product, is is marketed well? What is the appropriate amount of debt that Titan could take on? Perhaps integratingthis business into Kwirtmak with its size could easily fund the business venture. Does it match our structure for debt/equity?

**answer**
**Suitability**
Titan is a 3D printing company who specialises in producing advanced materials, i.e., carbon fibre at a more competitive price due to the nature of 3D printing. Kwirtmak understand 3D printing so should be able to assist and scale, or even design new better printers around this technology to enhance the product and gain a new source of revenue from people who are interested in producing or wanting carbon fibre products. Kwirtmak does not yet have this technology or understanding so may benefit greatly from acquiring the business and absorbing its staff with their knowledge and expertise in this area. 

Titan produces high quality premium components which fits nicely into the trusted and premium brand image of Kwirtmak, by kwirtmak furthering its expansion into this area of technology, it can shore up its brand image of being innovators and producing trusted premium products. There may be risk in this area as we do not yet understand the level of contracts that Titan currently has, but 4 years trading suggests that they are relatively new to the market but have some awareness in the market already. 

There is a chance that the passion of the CEO of Titan around the technology and cycling is infectious and overstates the demand for these products. It may be that customers are fine with mass produced products with tooling and there is little need for bespoke manufacture. If there is a demand for bespoke manufacture of carbon fibre technology in cycling then it may be lower than expected.  

I would say that the purchase satifies the suitability critera as its brand image and technological expertise fits nicely with Kwirtmaks mission to offer more high quality products to customers and committment to innovation. 

**Acceptability**
Shareholders expect a return on investments. Share prices are currently down and revenues are falling from the previous year. The purchase of Titan may incur additional debt or at least loss of cash to fund other projects so for management to be distracted on this acquisition, this may not be suitable for shareholders who may prefer them to work on the core business acitivities. 

However, shareholders may see this as an area that Kwirtmak needs to enter as its suuitability and goals align with the goals of Titan making it a natural fit, and the need to diversify into a potentially secure source of revenue with the patent. 

Titan has been trading for 4 years producing this technology to print with carbon fibre, and they have a patent in Northlans. This may be attractive for shareholders who are wanting to invest in a business that has certainty for growth and a stable return, and exploiting this patent could bring significant revenue to Kwirtmak. There is uncertainty as to whether a global patent will be issues however, so the value of the markets for Northland should be considered along with the likelyhood modifyier for the value of the global market if the global patent would be granted. 

Titan is looking for more investment as it appears they are running low on cash, this could suggest that they are not able to control costs well enough, and with Kwirtmak having a cost control issue with oeprating profit margin falling in times of falling revenue, it could be unwise to take on a project of acquisition of a company with a similar sub-par cost controlling culture, thus worrying investors as manaagemnt may be distracted on a risky bet to increase revenues instead of controlling costs. 

There appears to be some interest from Team Alpha as Titan being the preferred supplier to them, thus representing some demand for the products. With Kwirtmaks expertise in 3D printing technology, they could innovate further, market the technology better, and produce more high quality goods for customers which they may enjoy. 

Based on the above reasons, I would say that the purcahse does fit the acceptibility critera considering that internal controls are put in place and risks mitigated against. 


**Feasibility**
Kwirtmak will need to decide how best to purchase Titan. We could take on more debt to fund this purchase and Kwitmak has an interest cover of around ~10 meanning and is ~40% geared, meaning that it can take on some debt to fund the purchase of Titan. 

Kwirtmak does have around E$120 in the bank to fund the purcahse or part of the purcahse of Titan. It is unclear so to what it should pay however absed on the information provided. If cash is used to fund the purcahse, it should consider the required rate of return needed on this investment as cash has an equity cost as shareholders expect a return on this money. Perhaps a mix of debt and equity finance should be used according to the optimum balance of the WACC to ensure that the investment is done as efficiently as possible. There is undcertainty on the value of the potential contracts that Titan or the integrated titan entity could return, so an analysis should be undertaken prior to purchase checking to see the likelyhood of being the preferred supplier to Team Alpha and the value of this contract, as well as the market for bespoke 3D printed carbon fibre technology. 

There is a chance that the purcahse of Titan will distract management during a time of low share price and falling market share and revenue. Perhaps this will detract from core business operations which presents a greater risk of losing further market share. 

**Internal controls**
Kwirtmak will need to ensure that internal controls are sufficient to ensure that the acqusition will be a success. 
The team that are currently working for Titan, we do not understand how motivated they are or what motivates them. This will need to be understood so that they can be kept happy post-acqusition and are happy to share their skills and expertise in the printing of carbon fibre technology. They may own shares themselves in Titan, so an offer of a share for share deal for these employees may keep them happy to work for Kwirtmak. 

We have the word of the CEO regarding the premium quality of the products that they produce, but no oversight outselves on the output quality of these goods, or what technical challenges or waste is produced in the output of these goods. It will be worth verifying and ensuring a quality assurance control is put in place to monitor the quality of the output and to minimise production waste. It may be that Titan is needing more investment because they are in a similiar position to Kwirtmak and are not able to control costs well enough to ensure profit can be extracted from revenue. 

There may be a potential issue where it may be difficult to integrat the IT of both companies. To ensure that value and synergy can be extracted further, it may be beneficial to integrate both IT systems together. Kwirtmak currently does not have an IT director responsible for this area so may benefit from installing one prior to acqusition, who can be repsonsible for ensuring the success of the merger of technical systems and IT. There are also informational security concerns that are present in Titan that we may be unaware of. A lack of head of IT may present a risk as we may be unable to evaluate these sufficiently. 

Strong financial oversight will also need to be installed over the integrated entity to ensure that it meets its targets as a single entity thus contributing value to the group. We do not yet have a picture of the financials of the business so this should be investigated and mapped to ensure it aligns with the goals of Kiwrtmak. 

**Task 2**

**TASK 2 (60 Minutes)**

1. Recommend with reasons the approach that Kwirtmak should take to deciding an acceptable purchase price for 30% of Titan Cycles’ share capital.

**Answer**
Nature of 30% equity
As Kwirtmak can only accept 30% of Titan's share capital, it may be limited to how much it can influence the ddecisions of the company. The current structure and ownership of Titan should be analysed to determine if Kwirtmak would become the largest shareholder and be able to influence decision making and strategy of the business to ensure success or if the CEO or someone else remains the only majority shareholder. It may be that the efforts of the current CEO is not enough, and Kwirtmak is unable to replace her or install a new managing director. 

The business is currently lacking the ability to turn a profit within the 4 years of trading, so it should be analysed if there is a core issue with the approach of the business, there doesn't appear to be a worthwhile market to sell to at the end of the development of the 3D printed carbon fiber technology, or if they are typical hurdles to overcome for a newly trading company. 

It may be possible to learn from Titan regarding the printing of carbon fibre technology for use in other applications whilst still being a minority shareholder, so these learning experiences should be evaluated against the purchase price, even if Kwirtmak isn't able to influence that business for its own gain. There would typically be synergies to consider allowing the purchase price to be inflated somewhat, although it isn't clear how much integration would be possible due to the nature of being a minority shareholder. In the deal, it can be investigated if Kwirtmak can have board representation to be able to have the power to share technological knowledge and bring about synergies for Kwirtmak. 

Approach
net assets
The net assets approach could be used as a first basis to evaulate the purchase price of Titan, as this would be a relatively simple measure picked up from their financial statements. This figure would likely be extremely low as a lot of investment has gone into Titan and they are yet to make a return. This would be favourable to Kwirtmak though and may even appeal to Titan as their approach seems to be raising cash and would not be giving up control over the business. This method provides a baseline valuation of the assets that could be extracted from Titan thus ensuring no value to Kwirtmak shareholders is lost if the Titan venture fails as the assets could be sold to cover the investment. 

Dividend growth method would not be appropriate as Titan has yet to issue any dividends as they are yet to make a profit. Although, this could be suggested to Titan in negotiations to highlight the risks involved with investing to justify a lower purcahse price which would be beneficial to Kwirtmak. 

net present value of future cash flow may be a more appropriate method, but comes with a lot of risk as it would be very difficult to determine future cash flows due to there being a lack of solid contracts in place with customers, althouigh there is a patent in Northalnd, the market would need to be analysed to ensure what return could be extracted from this market. The chance of the patent being issued globally should also be analysed, perhaps by an expert in global patend law, as well as the size of this market being analysed. I would recommend a full analysis of these areas to determine the potential contract sizes. 

Perhaps a discount should be negotiated on top of the net present value of future cash flows as kwirtmak would be a minority shareholder and lack full control over the strategy of the business. There may also be other discounts available such as the need for new investment into Titan to avoid waisting investor capital, this could raise the negotiating power of Kwirtmak in the sale to get a better value to Kwirtmak shareholders in the acqusition. it isn't clear if Breskko has been approached by the Titan CEO however, it isn't clear if there is a need to ensure a timely purchasing deal so there could be room for an extended negotiation on price of Titan to ensure an optimum valuation and suitable return for Kwirtmak shareholders. 

2. Evaluate the arguments for and against starting research into developing 3D printers for the cycling industry.

**Answer**
Starting in-house research into 3D printers for the cycling industry can come with benefits and challenges. 

**Benefits**

In-house research can ensure that the benefits that arise from the research can be fully enjoyed by Kwirtmak as they won't have to share profits from entering into a minority shareholding position to get exposure to the cycling market.

Cost measures can be evaulated and controlled in line with other R&D projects that have been undertaken to ensure that these do not baloon up to ensure good return on shareholder capital. Titan may have succeeded in producing the useful technology, but may have overspent on R&D and detroyed shareholder wealth in the process as it is a new company not experienced with cost controlling for R&D projects. In-house development may be cheaper in the long-run than the asking price of Titan, although it depends if the 30% shareholding of Titan provides this knowledge at a significant discount. The values will need to be evaluated. 

The R&D into the new technology could give rise to ideas for new applications of the technology giving rise to unforeseen opportunities, perhaps a new patent of kwirtmak's own and opportunities to sell to other markets or licence out to other companies for profit. These serendipities are difficult to quantify or foresee however but could put Kwirtmak into a good position if such opportunities exist. This research could also enhance the skills and expertise of employees working on these projects giving a better understanding and integrated understanding of the technology as opposed to working with outside entities on the same project which could return greater benefits for Kwirtmak as these skills would be available in-house rather than outsourced potentially at greater expense. These skills could be useful for other applications of carbon fiber outside of the already identified cycling market, such as in the medical sector for artificial limbs etc. 

We currently have the research and development skills and expertise to start research projects with clear goals and targets, whilst understanding cost control measures from an R&D perspective as we're used to these type of projects. This could be in contrast to Titan who may have not used investor funds as efficiently as they may have overspent on developing the carbon fiber technology. If we were to purchase this entity or part of it, we may be overspending as opposed to developing this in-house. 


**Drawbacks**
There is significant up-front costs involved with developing new technologies for a new market. Firstly, this market will need to be analysed and understood to determine the size of it and what potential revenue could be gained from having exposure to this market. This will incur time costs and perhaps distract the marketing director from other activities. There is also the financial burden of these costs as cash incurrs a cost of equity and shareholder expect a return on this cash. It will need to be analysed if this is worthwhile purely from a cost perspective or if the cash could be better spent elsewhere. 

Starting in-house research into this area is likely to take significant time, so it may be a while before returns could be realised which may not satisfy shareholders especially as the share price is currently down for Kwirtmak and shareholders may already be wary of the strategy of management. 

There is a chance that the slow approach of developing technology for the cycling industry means that Kwirtmak would be behind in terms of development, meaning that any costs incurred may not be able to be recouped in full if they aren't the first to market their product. Titan already has a headstart but it isn't clear if they have made significant progress. Although if their strategy is unlikely to change, this could be a huge benefit to Kwirtmak as they can use their size and marketing strategies expertise to influence customers and gain market share, although this is a risk. 

Kwirtmak doesn't currently operate in the cycling industry and it isn't clear if anyone on the board understands it. There may be a lack of expertise in this area which represents risk, which could have been avoided if kwirtmak partnered with another company like Titan who has a CEO that potentially has expertise in the cycling market. 

The costs involved in in-house research could simply be avoided by purchasing another entity who has already explored the technology involved. There may be a duplication in costs and time going overr the same research processes whereas there could be savings to be made by purchasing Titan, potentially at a discount if it can be nogotiated.

R&D into the new technology for the cycling industry could take away research into other areas. Other R&D projects should be evaluated against the new project to ensure that it is a good use of resources and is likely to return value to shareholders. Perhaps capital budgeting approach could be useful here to evaulate each projects against the WACC using a net present value approach to determine if in-house R&D of this specfic technology is worthwhile on the whole. 

Kwirtmak currently does not have any conenctions in the cycling industry or know the industry well to know how to sell to it. The marketing director may need to explore this industry which comes at a cost and may distract them from other marketing strategies which could be a better use of resources for Kwirtmak.  

The technology and development may overlap with the patent that is currently held by Titan. There may be legal and technical expertise costs applied to analysing the patents to ensure that any technical research doesn't overlap, to avoid producing technologies that Kwirtmak would not be able to sell onto other businesses or to the cycling industry. 


**TASK 3 (60 Minutes)**

1. Evaluate the ethical issues arising from the points made in Madda’s email.

Madda has suggested changes about the personel who should be on or remain on the board of the new group. This raises ethical issues as the nomination committe has yet to assess potential nominees. She has also garnered support from Kwirtmak's largest shareholder prior to the assessments by the nomination commitee. This has the potential of jeapodising the independence of this committe and may lead to a less objective and optimum output, as there could be more suitable personel who could have taken the roles on the board. 

There is an issue of reaching an agreemnt with the largest shareholder meeting before the nomination committe has conducted their assessments, as it could solidify the decision in favour of the largest shareholder's interests without any concern for smaller shareholders. This isn't giving equal weight or taking into consideration the intersts of smaller shareholders which poses an ethical issue and may even alienate smaller shareholders. 

By forcing all but one of the executive directors of Titan to step down, this risks losing experience and knowledge that they have which could be crucial to success for the new business ventures that the group is now undertaking. This could be a dysfunctional action simply for personel to retain their own positions on the board. The decision shouldbe independently assessed by the nomnination committee. 

It is suggested that the payouts for the outgoing dirtectors are to be decided upon by the remuneration commitee, although it is suggested that these will be generous. This is an ethical issues as it needs to be understood whether it it right simply to spend significant shareholder wealth simply to ensure a smooth transition of directors. There is potential to simply use shareholder wealth to better the financial position of the ijndividuals themselves without any return. It is appropriate however to leave the final deciusion and level of remuneration to the remuneration commitee however as they will have chance to evaulate the right level of remuneration to ensure value for shareholders. 

By the CEO ensuring the jobs of the non-executive directors, this highlights an issue where they could become biased in favour of the the CEO and can no longer be percieved to be independent thus corrupting the nature and purpose of having non-executive directors who should be able to advise and guide the business in an independent way. There is risk that the chairman is looking to dominate proceedings and control over the workings of the business. 


Nomination committee recommendations

The nomination commitee should select NEDs who are independent and do not have specific favour of kwirtmak or Titan. This would be to ensure that the NEDs remain independent and are able to guide the business in the best interests of shareholders, rather than working against shareholders in favour of specific goals or personel, and remove preference biases from the guidance. 

The nomination committee should consider the skills, expertise, and experience of both Kwirtmak and Titan to ensure that a good presentation of both businesses are included so to ensure good oversight and management of both sub-entities returns good overall value back to shareholders. A good balance should also ensure the expertise of both entities are incorporated into the new entity giving a stronger chance of success for the merged group. 

Perhaps the personalities and current relationships should be considered for the new makup of the board as if directors have been working with each other for a while, they may find it harder to challenge ideas and push for strategic directions as to not damage these personal relationships at the detriment to shareholder value. Differing strategic options should be valued independently and free from bias. 

I would recommend that the nomination committee assess the knowledge and experience of each potential non-executive and non-executiuve director to ensure that the new board has the skills and experience of each business venture ready for decision-making at the highest level ensuring that it is in a good strong position to return shareholder wealth across all business activities of the group. Promoting someone who already has significant repsonsibilities within Kwirtmak or Titan could leave them distracted and unable to perform their current or new responsibilities well enough to optimise return of shareholder wealth. 

I would also recommend that the domineering personality of the chairman be considered as they have made suggestions to influence the direction of the makeup of the board. Perhaps balancing out the board with similar personalities could ensure that ideas and strategic are sufficiently challaenged potentially bringing about better deciisons that could return value to shareholders. Although, the board shouldn't be continually conflicted in its approaches to decision-making so members of the board should be able to work well and collaborate together to avoid slow and drawn out decision-making which would cause the business to lose out on opportunities or be able to respond to negative risk events timely enough thus destroying shareholder value. 

The nomination comitte should consider the current responsibilites of potential directors to evaluate whther they are able to commit to a role with a high level responsibility and are able to invest significant time in the role to ensure imediate success with decision-making as well and long-term stability in the interests of creating long-term value for shareholders. 
