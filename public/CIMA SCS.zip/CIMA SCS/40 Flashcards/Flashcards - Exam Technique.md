#flashcards/technique

The scoring paragraph formula::Point → Because (theory) → For Kwirtmak specifically (pre-seen/trigger fact or number) → So what (shareholder value, share price, WACC, risk, reputation)
<!--SR:!2026-07-27,1,230-->
The marking level ladder in every trait grid::Level 1 = identifies/describes; Level 2 = evaluates/explains/recommends; Level 3 = does so WITH JUSTIFICATION (tied to a scenario or pre-seen specific) — never leave a point at identification
<!--SR:!2026-07-27,1,230-->
The main reason candidates fail SCS::Answers too generic — insufficient application to the company; the key skill is answering the task set with specific application to Kwirtmak
<!--SR:!2026-07-27,1,230-->
How are core activities weighted?::All five core activities A–E are weighted 15–25% each; every exam balances them across the three tasks
<!--SR:!2026-07-27,1,230-->
Exam structure::3 hours, 3 tasks of 60 minutes; sub-tasks weighted by % (e.g. 60/40) — allocate time and word count proportionally
<!--SR:!2026-07-27,1,230-->
What format should answers take?::Exactly what the trigger requests — usually an email (To/From/Subject + one-line intro restating the request) or a briefing note (Prepared by/For/Subject); headers per requirement part; labelled Conclusion/Recommendation at the end
<!--SR:!2026-07-27,1,230-->
How many points per sub-task?::3–4 DEVELOPED points per trait beat many shallow ones — grids award up to 5 marks per point at Level 3
<!--SR:!2026-07-27,1,230-->
What must you do with the trigger material?::Use every paragraph — each fact exists to be hooked into at least one point; quote the scenario's own phrases in inverted commas ("nervous", "opportunity too good to miss")
<!--SR:!2026-07-27,1,230-->
Obey the verb — what do evaluate/recommend/discuss demand?::Evaluate = both sides + judgement; Recommend = pick one and justify (with reasons); Discuss = explore implications. A "recommend" answer with no recommendation caps your marks
<!--SR:!2026-07-27,1,230-->
Should you give a recommendation even when only asked to "evaluate"?::Yes — model answers end evaluative tasks with a balanced middle-ground or third-option recommendation; it demonstrates judgement
<!--SR:!2026-07-27,1,230-->
What lifts an answer to Level 3 in practically every grid?::Anchoring theory to pre-seen specifics — percentages (−18.8%), E$ amounts (E$1,350m), ratios you compute yourself (10.9x cover), named people (Ouyang Qi) and places (Capital City)
<!--SR:!2026-07-27,1,230-->
Do calculations score in essay tasks?::Yes — simple arithmetic from pre-seen financials embedded in prose (interest cover, gearing chains, "at say 10%...") earns justification credit; stated assumptions are acceptable
<!--SR:!2026-07-27,1,230-->
The universal caveat move::Include at least one counter-argument or "However..." per sub-task — then rebut it; balanced evaluation is rewarded everywhere
<!--SR:!2026-07-27,1,230-->
The "third option" conclusion trick::Strong conclusions often propose a superior cheaper alternative to the binary asked about (e.g. better reporting lines instead of a new director; both an ED and a NED)
<!--SR:!2026-07-27,1,230-->
Time discipline rule::Marks are per task; never overrun — a brilliant Task 1 cannot rescue an unattempted Task 3; plan 3–5 minutes before typing each task
<!--SR:!2026-07-27,1,230-->
Audience awareness::Write to the addressee — respect the CFO's authority (don't propose things that undermine them without acknowledging it), reference the Chair by name when the trigger came from her
<!--SR:!2026-07-27,1,230-->
When a question leaves categories undefined (e.g. "the three main stakeholders")::Any sensible, justified selection scores — Kaplan tutorial note; justify why you chose them
<!--SR:!2026-07-27,1,230-->
