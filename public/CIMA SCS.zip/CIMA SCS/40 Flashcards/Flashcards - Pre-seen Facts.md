#flashcards/preseen

Kwirtmak's mission::"To transform its customers through innovation in design and production"
<!--SR:!2026-07-27,1,230-->
Kwirtmak's vision::To be the leading provider of additive manufacturing solutions across industries, achieved in a sustainable manner (the "trusted provider")
<!--SR:!2026-07-29,3,250-->
Kwirtmak's five values::Creates wealth & success; innovations driven by customer need; overdelivers on its promises; trusts its staff; staff are team players
<!--SR:!2026-07-27,1,230-->
Kwirtmak's Porter generic strategy::Differentiator — "prices tend to reflect the high quality of its products"
<!--SR:!2026-07-29,3,250-->
When was Kwirtmak founded and listed?::Founded 1992; listed on the Ennland stock exchange 2004
<!--SR:!2026-07-27,1,230-->
How many major 3D printer manufacturers globally?::Eight — Kwirtmak is one; Breskko is the only other Ennland-based one (Mock A framing, 5 competitors of which only Breskko in Ennland)
<!--SR:!2026-07-30,4,270-->
Kwirtmak's five printing technologies::Extrusion, stereolithography (SL), digital light processing (DLP), laser melting, material jetting
<!--SR:!2026-07-27,1,230-->
The four market sectors Kwirtmak sells into::Aerospace, automotive, consumer electronics, jewellery (medical pending EHS approval)
<!--SR:!2026-07-27,1,230-->
What is ABS?::A very strong plastic used as filament in extrusion printers
<!--SR:!2026-07-30,4,270-->
What is PLA and why does it matter?::Biodegradable plastic; lowest energy use (~1 kWh/kg); Kwirtmak cut its PLA printing energy 32%; only ~3% of Kwirtmak's relevant machines vs 30% of Breskko's sales mix
<!--SR:!2026-07-29,3,250-->
Three medical uses of 3D printing in the pre-seen::Dental implants, artificial heart valves, artificial limbs
<!--SR:!2026-07-27,1,230-->
Carbon-fibre growth products named in the pre-seen::Tennis rackets and bicycle frames (sporting goods); also aerospace/automotive
<!--SR:!2026-07-29,3,250-->
Kwirtmak factory footprint::Four factories, each in a different country/currency; largest + head office on the outskirts of Capital City, Ennland; three overseas; sells into ~90 countries
<!--SR:!2026-07-29,3,250-->
Which board role does Kwirtmak famously lack?::A Director of IT — hook for cyber risk, integration risk, and board-skills answers
<!--SR:!2026-07-27,1,230-->
Kwirtmak 2026 revenue and change::E$2,320.0m, down 18.8% from E$2,856.6m
<!--SR:!2026-07-27,1,230-->
Kwirtmak 2026 operating profit and change::E$1,174.6m, down 27.1% from E$1,611.1m
<!--SR:!2026-07-30,4,270-->
Kwirtmak operating margin 2026 vs 2025::50.6% vs 56.4%
<!--SR:!2026-07-27,1,230-->
Kwirtmak ROCE 2026 vs 2025::34.0% vs 51.6% — roughly halved
<!--SR:!2026-07-27,1,230-->
Kwirtmak long-term borrowings and finance costs::E$1,350m borrowings; E$108m finance costs; implied rate 8% (suggests fixed-rate debt)
<!--SR:!2026-07-27,1,230-->
Kwirtmak equity and total assets 2026::Equity E$2,106.3m; total assets E$3,789.1m
<!--SR:!2026-07-27,1,230-->
Kwirtmak gearing 2026 (both bases)::D/E 64.1%; D/(D+E) 39.1% (2025 was 43.2%)
<!--SR:!2026-07-27,1,230-->
Kwirtmak interest cover 2026 vs 2025::10.9x vs 14.9x — still comfortable, but the falling trajectory is the concern
<!--SR:!2026-07-30,4,270-->
Kwirtmak profit for year, dividend and payout::Profit E$810.6m; dividend E$432.2m; payout 53.3%; cover 1.9x
<!--SR:!2026-07-27,1,230-->
Kwirtmak cash balance at 31.3.26::E$136.2m
<!--SR:!2026-07-30,4,270-->
Kwirtmak R&D spend 2026 vs 2025::E$270m vs E$285m (cut 5.2% — CTO argues this was a mistake)
<!--SR:!2026-07-29,3,250-->
Kwirtmak 2026 currency reserve loss (and Breskko's)::E$44.3m loss vs Breskko's E$11.3m
<!--SR:!2026-07-27,1,230-->
Kwirtmak share price and history::≈E$50 at 30.4.26, down ~6% since year end; 5-year history volatile with spikes above E$400–500
<!--SR:!2026-07-30,4,270-->
Kwirtmak beta and what it ungears to::Equity beta 2.3 (130% more volatile than market); asset beta ≈1.55 (tax 24%, book≈market, debt beta 0)
<!--SR:!2026-07-30,4,270-->
Tax rate in Ennland::24%
<!--SR:!2026-07-27,1,230-->
Breskko 2026 revenue and growth::E$3,016.0m, +9.9% — overtook Kwirtmak in size (Kwirtmak was larger in 2025)
<!--SR:!2026-07-29,3,250-->
Breskko operating margin and ROCE 2026::53.1% margin (beats Kwirtmak's 50.6%); ROCE 34.2%, stable both years
<!--SR:!2026-07-30,4,270-->
Breskko gearing and interest cover::D/(D+E) 29.9% (less geared than Kwirtmak's 39.1%); interest cover 14.3x and improving
<!--SR:!2026-07-30,4,270-->
Breskko dividend payout::~70% (cover 1.4x) — possibly deliberate confidence signalling vs Kwirtmak's cautious 53%
<!--SR:!2026-07-27,1,230-->
Mock A revenue currency split::41% aircraft manufacturers in Westland (W$); 6% car manufacturers; ~53% across 90 countries
<!--SR:!2026-07-30,4,270-->
Kwirtmak gross profit margin (Mock A)::64.3% — high margin means production costs are small, so the multi-factory natural hedge is weak
<!--SR:!2026-07-27,1,230-->
Who is Madda Fedele?::Non-Executive Chair; ex-senior government administrator (business legislation); political connections; sits on all four committees; CCU Senate ties
<!--SR:!2026-07-27,1,230-->
Who is Dr David Wallace?::CEO; PhD in precision control of mechanical devices; former CTO; UCC and CCU alumnus (familiarity threats)
<!--SR:!2026-07-27,1,230-->
Who is Agata Paluch?::CFO; qualified accountant; responsible for financial reporting and treasury; the usual exam addressee
<!--SR:!2026-07-29,3,250-->
Who is Dr Said Abouchdak?::CTO; PhD in molten plastics; leads R&D; UCC ties; in Mock C signed the unauthorised E$400m purchase order
<!--SR:!2026-07-30,4,270-->
Who is Kristina Eder?::Operations Director; chemical engineer; owns factories, quality, H&S and sustainability (reports on it every routine board meeting)
<!--SR:!2026-07-27,1,230-->
Who is Ouyang Qi?::Marketing Director; B2B sales career; owns marketing, PR, customer service — must investigate whether sales fell due to economy or Breskko
<!--SR:!2026-07-27,1,230-->
Who is Dr Ada Rothenberg?::Senior Independent Director; former Chief Economist; served on three government advisory committees (government links)
<!--SR:!2026-07-29,3,250-->
Who are the other two NEDs?::Professor Ahmet Usta (academic, UCC tie) and Nina Abersek (tech entrepreneur, Chair of Ennland Opera)
<!--SR:!2026-07-27,1,230-->
Kwirtmak board balance problem::5 executive directors vs 3 independent NEDs (+ Chair) — imbalance weakens independent challenge
<!--SR:!2026-07-27,1,230-->
Kwirtmak committee structure problem::Audit, Risk & CSR (combined), Remuneration, Nomination all have IDENTICAL membership; Chair sits on the Audit Committee (against best practice); no NED with recent & relevant financial experience
<!--SR:!2026-07-27,1,230-->
Which governance box does Kwirtmak tick?::CEO and Chair roles separated (Wallace / Fedele)
<!--SR:!2026-07-27,1,230-->
University familiarity threats on the board::Wallace, Abouchdak, Usta share University of Central City ties; Wallace and Fedele share Capital City University ties
<!--SR:!2026-07-27,1,230-->
Board skills gaps to recommend::IT/Cyber Director (urgent), Chief Sustainability Officer, HR Director, Chief Risk/Compliance Officer, supply-chain expertise
<!--SR:!2026-07-27,1,230-->
Kwirtmak's staff sustainability empowerment policy::All staff trained in environmental issues and empowered to halt operations immediately on serious environmental concerns (e.g. excessive emissions)
<!--SR:!2026-07-29,3,250-->
Kwirtmak's five-pillar sustainability record::1) Board-level governance (Ops Director + Risk & CSR Committee + staff empowerment) 2) Additive resource efficiency (less waste, recyclable filament, design optimisation) 3) Localisation cuts transport carbon 4) Continuous improvement (32% PLA energy cut) 5) Proactive regulatory engagement
<!--SR:!2026-07-29,3,250-->
What is the EHS?::Ennland Health Service — the regulator whose approval Kwirtmak needs before selling printers/materials for medical use
<!--SR:!2026-07-30,4,270-->
Kwirtmak's legislation exposure::Health & safety and environmental legislation — non-compliance brings heavy penalties
<!--SR:!2026-07-27,1,230-->
Why do customers keep buying Kwirtmak materials?::Compatibility/optimal output with Kwirtmak printers — consumables loyalty gives recurring revenue beyond machine sales (ecosystem lock-in)
<!--SR:!2026-07-27,1,230-->
Sustainability benefits inherent to 3D printing::Less raw-material waste (additive vs subtractive), greater recycling, lower transportation (local printing) — reduced carbon footprint
<!--SR:!2026-07-27,1,230-->
The aerospace use-case that recurs in answers::Printers make spare parts at airports on demand — avoids expensive aircraft downtime; demand is reliability-driven and price-inelastic
<!--SR:!2026-07-29,3,250-->
Kwirtmak's recognised principal risk about demand::Volatile sales demand — earnings variability and risk of overinvestment in inventory
<!--SR:!2026-07-27,1,230-->
