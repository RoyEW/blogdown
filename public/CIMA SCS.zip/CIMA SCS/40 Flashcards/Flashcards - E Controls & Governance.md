#flashcards/controls-governance

Internal audit — definition and its limit::Independent appraisal of the design and operation of internal controls; investigates and REPORTS to management/board — it does not fix the systems itself
<!--SR:!2026-07-27,1,230-->
How is IA independence protected?::Report to an Audit Committee of independent NEDs (not through executives); rotate "stranger" teams between sites; consider outsourcing; watch the self-review threat
<!--SR:!2026-07-27,1,230-->
What is the self-review threat for IA?::IA cannot objectively investigate what it previously audited and missed (e.g. a year of relaxed protocols) — risk of a defensive report protecting its own record
<!--SR:!2026-07-27,1,230-->
Seven types of internal audit::Systems-based; risk-based (resources to highest inherent risk); substantive procedures; compliance; social & environmental; management audit; post-completion review
<!--SR:!2026-07-27,1,230-->
Steps to deploy internal audit::Check staff competence & independence → research/map existing procedures → assess adequacy of system DESIGN (vs industry practice) → test OPERATION (real outputs) → communicate findings to management
<!--SR:!2026-07-27,1,230-->
IA forensic investigation approach (workbook E2)::Widen the search beyond the incident → preserve evidence (read-only system logs) → urgent timetable + immediate preliminary report → sceptical interviews tested against digital footprints → root-cause analysis (system vs culture/bonuses) → fact-check with CFO → final report with permanent fixes + 6-month follow-up
<!--SR:!2026-07-27,1,230-->
Compliance tests vs substantive tests::Compliance = test the PROCESS (are controls operating); substantive = test TRANSACTIONS/ASSETS themselves
<!--SR:!2026-07-27,1,230-->
Four compliance tests for a procurement bypass::ERP exception report (purchases missing mandatory approved-supplier codes); authorisation-limit testing (clusters just below thresholds); PO sequencing (rapid same-supplier splits = premeditation); access-rights audit (who could miscode without alert?)
<!--SR:!2026-07-27,1,230-->
Four substantive tests for a procurement bypass::Supplier bank-detail matching vs approved list (back-door payments); physical stock-to-record verification (trace batch numbers); digital forensics (email keywords "split", "sundry", "bonus"); data-pattern mining (invoices clustered under oversight triggers)
<!--SR:!2026-07-27,1,230-->
Anti-bribery audit programme (6 steps + reporting)::1) Risk assessment & control environment (local tone at top, policy communication) 2) Forensic review of third-party intermediaries ("success fees", due diligence, fee-vs-work) 3) Physical-to-financial reconciliation on site (ghost employees, inflated materials) 4) Facilitation-payment/petty-cash testing (stamped receipts, investigate "sundry") 5) Data analytics (round sums, duplicates, just-below-limit payments) 6) Whistleblowing hotline effectiveness + confidential interviews → report directly to the Audit Committee
<!--SR:!2026-07-27,1,230-->
IA investigating individuals — FOR::Knows the control framework; already security-cleared (fast start); pinpoints policy/training fixes; accountability = deterrence; establishes isolated lapse vs systemic failure
<!--SR:!2026-07-27,1,230-->
IA investigating individuals — AGAINST::IA as "police force" destroys psychological safety → blame culture hides future errors; forensic HR work may exceed IA's scope (it evaluates control systems); distracts from the root cause; self-review threat
<!--SR:!2026-07-27,1,230-->
Audit Committee commissioning checklist (8)::Independence/reporting lines first; materiality threshold (any safety bypass = material); management override & culture pressure; resources/competence (joint IA+QA, forensic specialists); when to notify external auditors/regulators; whistleblowing amnesty; interim directive (quarantine suspect inventory NOW); tone at the top
<!--SR:!2026-07-27,1,230-->
Board balance principle and Kwirtmak's position::Equal executives and independent NEDs; Kwirtmak has 5 EDs vs 3 independent NEDs — imbalanced, weak independent challenge; adding an ED worsens it and restoring balance needs 2+ NED hires (cost, months, interim non-compliance)
<!--SR:!2026-07-29,3,250-->
Audit Committee composition rules::Independent NEDs only, at least one with recent & relevant financial experience (ex-CFO/audit partner); the company Chair should NOT sit on it — Kwirtmak breaches both (economist/academic/entrepreneur NEDs; Fedele sits on it)
<!--SR:!2026-07-27,1,230-->
Kwirtmak's committee structure flaws::All four committees (Audit, Risk & CSR, Remuneration, Nomination) have identical membership; combined Risk & CSR Committee risks shortchanging both; Chair on Remuneration Committee discouraged
<!--SR:!2026-07-27,1,230-->
Principal–agent problem and the committee fixes::Directors may act in their own interests (e.g. set their own pay) → Remuneration Committee sets pay; Nomination Committee handles appointments; risk committee oversees risk — all NED-led
<!--SR:!2026-07-27,1,230-->
New executive director — advantages (4)::Elevates the issue to board level ("tone at the top"); reassures stakeholders/investors; specialist voice in every board decision; can lower the cost of equity via reduced risk perception
<!--SR:!2026-07-27,1,230-->
New executive director — disadvantages (4)::Worsens ED/NED balance (dilutes independence and "constructive challenge"); knock-on NED hires costly and slow; blurs accountability with an existing remit (e.g. treasury is the CFO's); may be the wrong diagnosis — if the department is strong, the gap is information flow, not capability
<!--SR:!2026-07-27,1,230-->
The "third option" conclusion for board-expansion questions::Instead of a new ED, strengthen reporting lines between the department head and the Audit/Risk Committee — strategic transparency without cost or imbalance
<!--SR:!2026-07-27,1,230-->
Specialist NED (cybersecurity) — for and against::FOR — independent technical constructive challenge; relieves an overloaded executive; elevates the domain to strategic risk; "fresh eyes" free of familiarity threats satisfy client due diligence. AGAINST — others "switch off" (governance is collective — NED should catalyse whole-board literacy); part-time NED can't fix daily management gaps; an executive alone worsens balance → recommend BOTH an executive and a NED
<!--SR:!2026-07-27,1,230-->
Who decides board appointments and what do they assess?::The Nomination Committee (never one director, never pre-agreed with a big shareholder); assess the role to be performed, independence, skills/experience balance, time commitment vs existing duties, personality/challenge culture
<!--SR:!2026-07-27,1,230-->
Why is a CEO "guaranteeing" NED jobs unethical?::NEDs owing their positions to the CEO cannot challenge them — perceived independence destroyed, corrupting the purpose of NEDs; sign of a domineering chair/CEO controlling proceedings
<!--SR:!2026-07-27,1,230-->
How NEDs enforce mission/vision (three committees)::Audit/Risk Committee — widen remit beyond financials; mandate IA/third-party unannounced site inspections (don't rely on executive assurances). Remuneration Committee — replace volume-only bonuses with non-financial KPIs (security accreditation, product integrity, ethics) tied to long-term incentives. Board/Nomination — constructive challenge as fiduciary duty; skills matrix; board training (digital literacy); report enhancements in the Annual Report
<!--SR:!2026-07-27,1,230-->
Unauthorised executive action — the implications list (Mock C 3a)::Breached Matters Reserved for the Board; time-pressure excuse rejected (negotiate a window or decline); bypassed NED scepticism + CFO oversight; sunk-cost bias forces the Board's hand; asset may be unnecessary if plans change; fiduciary duty breached; values are no defence (trust ≠ unregulated authority; not a team player)
<!--SR:!2026-07-27,1,230-->
Control-environment fixes after an unauthorised commitment::Remuneration Committee reflects it in his bonus; consider (but weigh) requesting resignation — signal severity; formal authority matrix (e.g. >E$50m = Board resolution + dual CEO/CFO signatures); hard ERP controls blocking single signatures; Emergency Decision-Making Policy (Chair+CEO+CFO subcommittee, full-Board ratification within 24 hours)
<!--SR:!2026-07-27,1,230-->
Discipline & clawbacks — the FOR case::Explicit ethical-integrity contract clause breached; premeditated circumvention (12 split invoices); direct clinical harm; gross misconduct in safety-critical manufacturing; bonuses earned under false pretences → clawback justified
<!--SR:!2026-07-27,1,230-->
Discipline & clawbacks — the mitigating case::"Meet the numbers at any cost" culture was widespread; staff feared for livelihoods; the executive-designed incentive scheme created the conflict → punishing juniors alone = scapegoating + unfair-dismissal exposure + morale damage
<!--SR:!2026-07-27,1,230-->
Discipline & clawbacks — the systemic reform::Board/Remuneration Committee signs off all incentive schemes; detailed policies replace vague "trust"; 'Safety Gate' — any bypass triggers automatic department-wide bonus forfeiture AND formal disciplinary proceedings
<!--SR:!2026-07-27,1,230-->
Matters Reserved for the Board — what belongs there?::Strategic investments of large magnitude (e.g. E$400m), major contracts, M&A, capital structure changes — decisions requiring collective debate and approval, not individual authority
<!--SR:!2026-07-27,1,230-->
Board operation principles::Culture of constructive challenge; EDs manage, NEDs monitor; strong independent element able to stand up to the CEO; decisions reserved for the board documented
<!--SR:!2026-07-29,3,250-->
