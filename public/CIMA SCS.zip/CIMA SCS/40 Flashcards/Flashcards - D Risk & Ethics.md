#flashcards/risk-ethics

Six required fields of a risk register::1) Risk description & impact pathway 2) Likelihood and impact ratings (1–5) 3) Overall rating (L×I) 4) Dates identified & review dates 5) Residual risk rating 6) Named risk owner
<!--SR:!2026-07-29,3,250-->
What are KRIs and the Kwirtmak example?::Key Risk Indicators — lead indicators that a risk is materialising; e.g. an aggressive "overdeliver" sales culture is a KRI that customer vetting is being compromised for volume
<!--SR:!2026-07-27,1,230-->
TARA::Transfer (insure, outsource, hedge); Avoid (don't do it); Reduce (controls); Accept (low likelihood/impact, or mitigation costs exceed benefit)
<!--SR:!2026-07-29,3,250-->
"Should this risk have been on the register?" — FOR recognition::Foreseeable strategic risk given high-impact technology; register too narrow (own-factory penalties only, missing customer-misuse reputational risk); no KRIs defined
<!--SR:!2026-07-27,1,230-->
"Should this risk have been on the register?" — why it was omitted::External criminal act (hard to quantify/control post-sale); "trust" values created cognitive bias (risk deemed too remote); assessed on a net-risk basis assuming controls sufficed; no board IT expertise to explain exploitability; assumed Legal covered external liabilities
<!--SR:!2026-07-27,1,230-->
The six cyber risk categories::Strategic; Economic; Availability; Security; Compliance; Performance
<!--SR:!2026-07-27,1,230-->
Cyber controls per category (one each)::Strategic — appoint IT Director/board literacy; Economic — accountant-led business cases with quantified deliverables; Availability — regional distribution + hot backup; Security — encryption, penetration testing, patching; Compliance — internal audit + legal monitoring; Performance — steering groups, outsource with SLAs
<!--SR:!2026-07-29,3,250-->
Ransomware — the reasons NOT to pay (5)::No guarantee criminals decrypt; paying marks you as a repeat target; decrypting raises criminals' capture risk so they won't bother; residual malware enables worse follow-up attacks/bank hijacking; a ransom in the accounts signals weak governance — shareholders demand answers, directors risk removal
<!--SR:!2026-07-27,1,230-->
Ransomware — the counter-argument and its rebuttal::"Hackers have a reputation incentive to decrypt so victims keep paying" — rebutted: companies keep successful hacks secret, so no reputation effect operates
<!--SR:!2026-07-27,1,230-->
DAMPSOAP::Division of responsibilities; Arithmetic & accounting; Management; Personnel (vetting, references); Supervision; Organisation (structure, procedures); Authorisation (thresholds, sign-off); Physical protection
<!--SR:!2026-07-27,1,230-->
The KYC/vetting control package (workbook D2)::Centralised independent vetting unit OUTSIDE the sales reporting line; mandatory background checks on end-user identity/regulatory standing; "hard block" — no despatch until an independent compliance officer signs off
<!--SR:!2026-07-29,3,250-->
The digital-handshake control::Printer must verify the CAD file's digital certificate with a secure Kwirtmak server before printing safety-critical geometries; auto-halt + alert on unverified/cloned designs — both preventative and detective
<!--SR:!2026-07-29,3,250-->
The right-to-audit control::Random technical audits of customers with high-capacity printers via a right-to-audit clause in sales agreements (printer logs, material consumption — e.g. a lab consuming medical-grade titanium with no medical certification); report to Audit Committee
<!--SR:!2026-07-29,3,250-->
Why is "Kwirtmak trusts its staff" a risk?::Trust is not a control — "trust but verify"; a culture value without defined boundaries empowers managers to compromise controls for local gains (relaxed encryption, bypassed KYC, split invoices, unauthorised orders)
<!--SR:!2026-07-29,3,250-->
How do you govern an "overdeliver" incentive culture?::Balanced-scorecard incentives (vetting-documentation accuracy, end-use audits — not volume-only); board-defined risk appetite; safety/compliance as a GATEKEEPER for any bonus; 'Safety Gate' — any bypass = department-wide bonus forfeiture + automatic disciplinary proceedings
<!--SR:!2026-07-27,1,230-->
The five CIMA fundamental principles::Integrity; Objectivity; Professional competence & due care; Confidentiality; Professional behaviour
<!--SR:!2026-07-29,3,250-->
Integrity — definition and the omission argument::Straightforward and honest in all professional relationships; withholding a fact MATERIAL to the deal = lying by omission (obtaining a dishonest advantage); don't be associated with misleading information
<!--SR:!2026-07-29,3,250-->
Objectivity — definition and the "nervous" tell::Judgement free of bias, conflict of interest, undue influence; admitting you were "nervous" transparency would kill the deal = a conflict of interest overrode neutrality; "acting in shareholders' interest" never justifies misleading on safety-critical matters
<!--SR:!2026-07-29,3,250-->
Professional competence & due care — the disclosure twist::Due care can REQUIRE informing an affected client so it can protect itself (e.g. after a security lapse endangered its IP)
<!--SR:!2026-07-29,3,250-->
Confidentiality — definition and its limits::Don't disclose or exploit business information; but it never justifies hiding negligence that endangers a client — and it's futile when the press is about to break the story anyway
<!--SR:!2026-07-29,3,250-->
Professional behaviour — the "fix it later" rebuttal::Comply with laws, avoid discrediting the profession; hoping to fix a problem before final launch does not excuse the lie now — safety-critical failure + concealment = liability, negligence claims, regulatory sanctions
<!--SR:!2026-07-29,3,250-->
The counterparty-failings balance point::Arguably the client's own due diligence failed (professional competence) — but their weakness INCREASES your ethical burden to be transparent; it never excuses deception. State it, then rebut it
<!--SR:!2026-07-29,3,250-->
Ethical dilemma response actions (5)::Transparency & proactive disclosure ("radical honesty" before the press breaks it); express empathy/awareness of harm; communicate with victims and regulator; compensating actions; remedial actions (state the fixes)
<!--SR:!2026-07-27,1,230-->
Bribery — principle↔threat pairings (Mock B)::Integrity ↔ self-interest (quid pro quo — buying what's legally yours); Objectivity ↔ advocacy (coerced to promote a politician's project); Professional behaviour ↔ legal breach (Bribery Act); Transparency (hiding it in another budget = second breach); Self-review (Board can't audit a process it compromised); Public interest (rule of law)
<!--SR:!2026-07-27,1,230-->
The bribery motive rule::Motive is irrelevant under Bribery Act-style law — a payment intended to influence a public official for commercial advantage is a corporate offence even "for a good cause"; facilitation payments are also prohibited
<!--SR:!2026-07-29,3,250-->
The bribery consequence chain::Precedent effect → future decisions clouded by political pressure → permanent reputational "stain" → further depresses an already-low share price → long-term damage outweighs the short-term strategic benefit
<!--SR:!2026-07-27,1,230-->
Why was Said's E$400m order a fiduciary breach (Mock C)?::Technical enthusiasm superseded his duty to protect liquidity and verify assets are required before procurement; he bypassed Board debate (Matters Reserved), NED scepticism and CFO oversight, and created sunk-cost bias forcing the Board's hand
<!--SR:!2026-07-27,1,230-->
Why is "the opportunity was too good to miss" no defence?::The benefit of the technology exists regardless of who authorised the purchase — opportunity is no excuse for a governance breach; "trust" means operating within delegated limits, not unregulated authority
<!--SR:!2026-07-27,1,230-->
Risk mitigation menu (generic)::Reduce impact; reduce likelihood; diversify; plus TARA responses — and remember upside risk (opportunities), not just downside
<!--SR:!2026-07-27,1,230-->
Kwirtmak's recurring risk list (name 6 of 11)::Cybersecurity (no IT Director); product misuse/counterfeiting (KYC, software safeguards); reputational (mission-critical QC); technological obsolescence (R&D, university partnerships); supply-chain disruption (diversify suppliers, buffers); regulatory change (Legal monitors); competition (innovate, overdeliver); environmental compliance (energy efficiency); demand volatility (Marketing monitors); economic (Treasury monitors); currency (forwards, money-market, options)
<!--SR:!2026-07-27,1,230-->
