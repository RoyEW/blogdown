#flashcards/financing

Pecking order theory::Fund with retained earnings first (cheapest, least disruptive), then debt, then new equity last
<!--SR:!2026-07-27,1,230-->
Debt vs equity — debt's pros and cons::Pros — quicker to raise, interest tax-deductible (tax shield), repayable, no dilution. Cons — adds financial risk, interest drains cash flow, covenants restrict flexibility
<!--SR:!2026-07-27,1,230-->
Debt vs equity — equity's pros and cons::Pros — permanent, no repayment pressure, no fixed servicing. Cons — dilutes control/voting, expensive to raise, unattractive when the share price is depressed, and "cash has an equity cost" (shareholders expect a return)
<!--SR:!2026-07-27,1,230-->
Capital structure considerations (6)::Business risk & security; flexibility; tax; currency matching (borrow in the currency of the assets/revenues funded); market sentiment; the debt/equity balance that minimises WACC
<!--SR:!2026-07-27,1,230-->
Evidence of Kwirtmak's debt capacity::Gearing 39.1% vs Breskko 29.9% (more geared, but fell from 43.2%); interest cover 10.9x (comfortable — worry is the fall from 14.9x); 8% fixed rates; E$136.2m cash
<!--SR:!2026-07-27,1,230-->
Foreign-currency (N$) borrowing — advantages (4)::Local goodwill smooths planning/permits; local bank accepts local assets as security (home bank fears cross-border foreclosure → higher rate); debt cheaper than equity + tax shield on local profits (compare tax rates); local bank becomes a political ally (default threat → it lobbies against expropriation)
<!--SR:!2026-07-27,1,230-->
Foreign-currency borrowing — disadvantages (2, and which is biggest)::FX risk is the most significant — an R&D centre is a cost centre with no local revenue → no natural hedge; continuous E$→N$ conversion to service debt; N$ appreciation raises true cost. Also strict covenants (dividend blocks, local liquidity) restrict global flexibility
<!--SR:!2026-07-27,1,230-->
International Fisher Effect — and the exam caveat::Higher interest rates should be offset by currency depreciation over time — but "relying on this in a developing economy is incredibly dangerous"; emerging currencies suffer sudden violent volatility models fail to predict
<!--SR:!2026-07-27,1,230-->
Why must a rights issue be priced at a discount?::To encourage take-up; if the market price falls below the issue price during the offer, shareholders just buy in the market → the issue fails and no funding is raised
<!--SR:!2026-07-27,1,230-->
What is TERP and its investor-psychology problem?::Theoretical Ex-Rights Price — discounted new shares dilute the price and future EPS; total value rises by the cash raised, but retail investors may misread the TERP adjustment as a real loss and sell
<!--SR:!2026-07-27,1,230-->
Three fixes for a risky rights issue::Deep discount (cushion against price falls — accept extra dilution); underwriting (banks guarantee take-up; high fees for volatile stock = insurance premium; deep discount makes underwriters keener); positive signalling (IR campaign framing proceeds as strategic investment, not a bailout)
<!--SR:!2026-07-27,1,230-->
Four dividend policy types::Constant amount (predictable but inflexible — a missed payment screams trouble); constant % of profits (volatile, may drive short-termism); residual (invest first, distribute the rest); zero/growth
<!--SR:!2026-07-27,1,230-->
Five considerations when setting dividend policy::Profit stability; growth/investment plans; signalling effect; clientele effect; cash preservation (vs "bribing" investors to save the board)
<!--SR:!2026-07-27,1,230-->
Dividend signalling in a hostile bid::Maintaining a dividend despite falling profits signals stability; a sudden cut to zero signals panic/distress — it validates the bidder's "severe decline" narrative and depresses the price, making the offer look better
<!--SR:!2026-07-27,1,230-->
Dividend clientele in a hostile bid::Income-reliant investors whose dividends are cut will sell — and the readiest buyer is the bidder at its offer price → cutting the dividend literally hands over control
<!--SR:!2026-07-27,1,230-->
The hostile-bid dividend conclusion::Survival first — maintain the dividend to keep shareholder loyalty; fund R&D/strategy via alternatives (debt restructuring, selling non-core assets, targeted innovation financing)
<!--SR:!2026-07-27,1,230-->
The five valuation methods::Net assets (floor value); dividend valuation model; DCF of future cash flows; P/E multiple on earnings; plus synergies (justify paying above stand-alone value)
<!--SR:!2026-07-27,1,230-->
Net assets method — use and weakness::Simple floor/minimum value from the balance sheet; ignores brand, staff, and earning potential (firms trade well above it)
<!--SR:!2026-07-27,1,230-->
Replacement-cost twist on asset valuation::Value what it would cost the bidder to REPLICATE the assets — PP&E E$2,551.3m, undervalued intangibles (patents, software, E$497.2m book), factories, barriers to entry → exposes an asset-stripping bid and sets the real floor
<!--SR:!2026-07-27,1,230-->
DVM — when useless and how to weaponise that::Useless when the target pays no dividends (start-ups); use it in negotiation to argue the price DOWN by highlighting investment risk
<!--SR:!2026-07-27,1,230-->
DCF — strengths and caveats::Most robust: captures R&D pipeline (E$270m/yr), patents, recovery plans. Caveats: forecasting is hard without solid contracts; beta 2.3 means a high WACC discount rate — value must still beat it
<!--SR:!2026-07-27,1,230-->
P/E method — the normalisation rule::Never apply a multiple to depressed current earnings (plays into a hostile bidder's narrative); average 3–5 years of profits to smooth macro shocks, apply a strong industry P/E, support with historical price highs (E$400+ vs the E$55 offer)
<!--SR:!2026-07-27,1,230-->
Valuation adjustments for a 30% minority stake::Minority discount (limited influence — check if we'd be largest shareholder, seek board representation); distressed-seller discount; less synergy value if integration is impossible as a minority
<!--SR:!2026-07-27,1,230-->
EMH — definition and three forms::Share price reflects available information about future cash flows. Weak (past prices); semi-strong (all public information — the exam's working assumption); strong (all information incl. private)
<!--SR:!2026-07-29,3,250-->
Five factors that move a share price::Expectations of future free cash flow; perceived risk (→ cost of capital); dividend policy; speculation and rumour; systematic/market-wide factors
<!--SR:!2026-07-27,1,230-->
Announcement playbook — why might a big investment announcement DROP the price?::Market unconvinced of viability/NPV; material spend (E$2bn > half of assets) with no appraisal shown; risk perception (beta 2.3, tough regulator); debt funding amid rising rates (gearing fears); looks like an impulsive reaction to the 6% share-price fall
<!--SR:!2026-07-27,1,230-->
Four ways to protect the share price around an announcement::Delay until appraisal complete and funding secured; brief investors/analysts on existing strengths (aerospace/automotive); balance disclosure vs commercial confidentiality (Breskko could copy); absolute honesty — never present potential market size (E$10bn) as guaranteed revenue
<!--SR:!2026-07-27,1,230-->
Beta — definition and Kwirtmak's numbers::Measure of systematic (market-wide, undiversifiable) risk from historic returns vs the local index; market = 1; Kwirtmak equity beta 2.3 (130% more volatile); asset beta ≈1.55 ungeared
<!--SR:!2026-07-29,3,250-->
Equity beta vs asset beta::Equity (geared) beta = business risk + financial risk of gearing; asset (ungeared) beta strips out financial risk — Kwirtmak's core operations alone are still well above market risk (1.55)
<!--SR:!2026-07-27,1,230-->
Does currency exposure raise beta? (Mock A 2a)::No — currency risk is UNSYSTEMATIC and diversifiable (investors pair you with inversely-exposed stocks); beta only rises with market-wide co-movement; beta's drivers are empirical, not deducible by logic — only a cross-company study could prove a link
<!--SR:!2026-07-27,1,230-->
Do translation losses move the share price or beta?::No — they are accounting entries, not cash flows; markets price expected future cash flows (E$44.3m reserve loss should not move the price)
<!--SR:!2026-07-27,1,230-->
What raises beta? (workbook C2)::Concentrating in a cyclical sector (pure-play aerospace = cash flows locked to aviation cycles); higher operating gearing (fixed-cost-heavy capex amplifies profit volatility); higher financial gearing
<!--SR:!2026-07-27,1,230-->
The beta→NPV chain (recite it)::Beta up → cost of equity up (CAPM) → WACC up → NPV down → even "high-margin" projects destroy shareholder wealth if cash flows don't beat the higher discount rate
<!--SR:!2026-07-27,1,230-->
Cost of capital drivers::Debt — general interest rates. Equity — beta (business + financial risk). Reducing company risk lowers WACC and lifts the share price (universal "so what")
<!--SR:!2026-07-29,3,250-->
Why is market capitalisation a poor defence valuation?::Short-run market cap is sentiment/panic-driven, not fundamental value — shift the narrative to intrinsic (DCF), maintainable (normalised P/E) and replacement value
<!--SR:!2026-07-27,1,230-->
