#flashcards/ecosystem

PESTLE categories::Political, Economic, Social, Technological, Environmental, Legal
<!--SR:!2026-07-27,1,230-->
Porter's Five Forces::Threat of new entrants; buyer power; supplier power; threat of substitutes; competitive rivalry
<!--SR:!2026-07-27,1,230-->
Mendelow matrix — the four quadrants and strategies::Low power/low interest = minimal effort; high power/low interest = keep satisfied; low power/high interest = keep informed; high power/high interest = key players (engage/consult)
<!--SR:!2026-07-27,1,230-->
How do you score L3 on a Mendelow question?::Rate interest and power SEPARATELY with scenario justification, classify the quadrant, then state the management strategy and what it means for the decision
<!--SR:!2026-07-27,1,230-->
When does employee power rise, and its limit?::If unionised/collective action can disrupt production and attract national attention — but power is short-lived if the site is closing anyway (action may even accelerate closure)
<!--SR:!2026-07-29,3,250-->
When is a government a powerful stakeholder?::When the firm has other in-country interests it can touch (licences, audits, legal challenges, customer sentiment); low power if the country is a manufacturing base only — and it can never force you to keep trading
<!--SR:!2026-07-29,3,250-->
Why treat a closing-site government well anyway?::Other host governments are watching how you handle it — global reputation protection
<!--SR:!2026-07-29,3,250-->
Potential employees on Mendelow::High interest (jobs, careers — higher in a deprived area); LOW power (no collective bargaining as they're not yet employed) → keep informed
<!--SR:!2026-07-30,4,270-->
What makes a Chamber of Commerce a key player?::It proxies for government; grant-giving ability = power; promoting inward investment = high interest → engage over location/design decisions
<!--SR:!2026-07-27,1,230-->
SMART KPIs::Specific, Measurable, Attainable, Relevant, Time-bound
<!--SR:!2026-07-27,1,230-->
Balanced Scorecard perspectives (+example KPI each for a new facility)::Financial (ROCE per project; net margin by product line); Customer (market share in target sector; retention/repeat purchases); Internal process (compliance pass rate; CAD-to-print lead time); Learning & growth (time to regulatory certification; % staff trained in new standards)
<!--SR:!2026-07-27,1,230-->
The per-KPI formula::Name the metric → what it measures → WHY it matters for THIS venture (tie to a scenario number/quote)
<!--SR:!2026-07-27,1,230-->
Two KPIs you must include when entering a regulated sector::A regulatory-approval-speed KPI and a staff-training KPI
<!--SR:!2026-07-27,1,230-->
Scenario planning — the 5-step response template per scenario::1) Impact & why material (quantify) 2) Leading indicators to monitor 3) Short-term liquidity (sensitivity cash-flow forecasts, worst-case overdraft) 4) Medium-term structural response (repricing, debt mix) 5) Pre-arranged relationships (banks, consultants on retainer)
<!--SR:!2026-07-27,1,230-->
Interest-rate scenario staples::Rates track inflation/economic data → monitor indicators; compute interest cover (10.9x) to show headroom; convert part of all-variable debt to fixed (costs more but removes worry); maintain lender relationships
<!--SR:!2026-07-27,1,230-->
IT-disruption/business-continuity staples::Hot backup site mirroring in real time, geographically remote from HQ ("not the outskirts of Capital City"), able to talk to banks; stakeholder communication plan; consultants on retainer; publish realistic restoration timelines
<!--SR:!2026-07-27,1,230-->
The "rival got attacked" framing::Fortunate it happened to a competitor first — a free lesson; assess our own vulnerabilities and build the scenario plans now
<!--SR:!2026-07-27,1,230-->
Interest-rate rise — the four economic risk buckets::1) Cost of debt & gearing (compute the chain) 2) Customer demand suppression (their CapEx is financed) 3) Currency (rates up → E$ up → exports dear) 4) WACC up → NPV down (projects flip unviable)
<!--SR:!2026-07-27,1,230-->
Mock C interest-rate calculation chain::Gearing 1,350/2,106.3 = 64% (Breskko 42.7%); +E$2bn → E$3,350m debt → gearing ≈159% "very aggressive"; implied rate 108/1,350 = 8%; at say 10% on 3,350 → E$335m interest = +210% → squeezes margin, threatens dividend
<!--SR:!2026-07-30,4,270-->
Responses to interest-rate risk (4)::Fix the rate (fixed-rate bonds, interest-rate swaps); phase/modularise capex (delay drawdown, exit points — caveat feasibility); customer leasing/financing; natural currency hedging via overseas production
<!--SR:!2026-07-27,1,230-->
CapEx-freeze playbook (4 moves)::1) Pivot to non-cyclical sectors (healthcare — inelastic, still investing) 2) CapEx→OpEx (≤12-month leases, machine-as-a-service — but model working capital!) 3) Maximise aftermarket (consumables, supply contracts, maintenance) 4) Sell software/hardware upgrades (extend machine life, high margin)
<!--SR:!2026-07-27,1,230-->
Why does leasing beat selling during a customer CapEx freeze?::Lease payments are OpEx so they bypass customers' CapEx freezes; predictable recurring revenue for us — but upfront manufacturing cost vs drip-fed cash strains working capital (check E$136.2m cash + facilities)
<!--SR:!2026-07-27,1,230-->
The three currency risk types in one line each::Transaction = short-term invoice exposure; Translation = paper losses consolidating foreign net assets; Economic = long-term FX impact on PV of future cash flows and competitiveness
<!--SR:!2026-07-29,3,250-->
Transaction risk hedging menu::Invoice in E$; leading/lagging payments; operational/real hedging (make where you sell); foreign-currency borrowing/money-market hedge; forwards (certainty, maybe bad rate); futures (perfect hedge, lose upside); options (keep upside, pay premium); swaps (counterparty risk)
<!--SR:!2026-07-27,1,230-->
Translation risk — impact and the model recommendation::Strong E$ → foreign net assets translate lower → unrealised loss cuts group equity (E$44.3m already; more after 15% appreciation). Do NOT hedge — non-cash, no cash-flow impact; spending real money on paper losses is inefficient → manage investor relations via annual-report narrative instead
<!--SR:!2026-07-27,1,230-->
What is "matching" as a translation hedge?::Fund foreign assets with local-currency debt so asset translation losses are offset by liability translation gains — possible but not commercially justified for Kwirtmak (restructuring E$1,350m is costly)
<!--SR:!2026-07-27,1,230-->
Economic risk — impact and the model recommendation::E$ cost base + weak-currency revenues → hold prices and lose share OR discount and erode margin (50.6% from 56.4%). DO mitigate — derivatives can't hedge indefinitely, so 1) operational hedging (shift production/sourcing to the three overseas factories — align cost currency with revenue currency) 2) value-based pricing (total cost of ownership — 32% energy cut, less waste — never a price war that damages premium brand equity)
<!--SR:!2026-07-27,1,230-->
The partial natural offset of a strong E$::Imported raw materials/parts from third-party suppliers become cheaper — partially offsets the export-margin squeeze
<!--SR:!2026-07-27,1,230-->
Why is economic FX exposure hard to UNDERSTAND (Mock A)?::Concentration hard to quantify (41% Westland); customers may hedge themselves; demand may be price-inelastic (mission-critical spares); 90-country fragmentation unmodellable; capital purchases deferrable; contract terms differ by customer size; competitor pricing response unknowable
<!--SR:!2026-07-27,1,230-->
Why is a multi-factory natural hedge WEAK for Kwirtmak?::GP margin is 64.3% — production costs are small relative to selling prices, so favourable cost-currency moves can't meaningfully offset revenue lost to a strong E$
<!--SR:!2026-07-27,1,230-->
Accept vs mitigate economic FX risk — the middle-ground recommendation::High margins and 90-country diversification permit some acceptance, but beta 2.3 + Westland concentration make total non-mitigation unsustainable → reject costly operational change (factory relocation), use targeted financial mitigation (currency-match debt to the 41% W$ revenue)
<!--SR:!2026-07-29,3,250-->
Arguments FOR accepting economic FX risk::64.3% margin buffers volatility; hedging costs may exceed benefits for an unquantifiable long-term risk; existing natural hedges (4 factories + 90-country portfolio); pragmatism (90 currency pairs unhedgeable)
<!--SR:!2026-07-27,1,230-->
Arguments AGAINST accepting economic FX risk::Structural pricing-out of the concentrated Westland market; relies on brand loyalty/technical superiority holding if the market turns price-sensitive
<!--SR:!2026-07-27,1,230-->
Political risk menu for a developing economy::Government change/election cycle (invest under one regime, operate under the next); policy reversal & retrospective taxation; expropriation of assets; forced technology transfer (the big one for tech firms); border/transfer restrictions; civil unrest
<!--SR:!2026-07-27,1,230-->
Political risk mitigations::Good corporate citizenship (skilled local jobs, university links, preventing brain drain → politically costly to attack); local financing as political shield; join a broader FDI trend; government wants to publicise your investment
<!--SR:!2026-07-27,1,230-->
Why is forced technology transfer worse than expropriation for Kwirtmak?::Its value is IP — cutting-edge software/hardware designs; a government mandating sharing with domestic firms takes the crown jewels as a "cost of doing business" while the factory keeps running
<!--SR:!2026-07-29,3,250-->
The time-lag argument in political risk::You negotiate and invest under the current government but open and operate under whichever government wins the next election
<!--SR:!2026-07-29,3,250-->
