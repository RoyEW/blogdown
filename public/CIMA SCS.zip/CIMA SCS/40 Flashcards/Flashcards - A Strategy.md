#flashcards/strategy

What does SAF stand for and what does each test?::Suitability (consistent with position & strategic direction — fit with mission, competences, the strategic problem); Acceptability (consistent with stakeholder aims — returns, risk, reactions); Feasibility (do we have the resources — finance, capacity, legal, skills)
<!--SR:!2026-07-27,1,230-->
How should every SAF answer end?::Conclude explicitly against all three criteria, then give a recommendation (usually further Board discussion + full financial appraisal)
<!--SR:!2026-07-27,1,230-->
Seven argument families FOR an acquisition::Strategic/reputational fit; related diversification (lower risk); acquire skilled workforce; order pipeline adds value day one; growth segment; customer/cross-sell synergies; distressed seller = negotiating strength
<!--SR:!2026-07-27,1,230-->
Five argument families AGAINST an acquisition::Lenders' refusal signals problems (due diligence!); takeover may destroy the asset (employee-owner motivation); bidding war/overpaying risk; management time distraction; alternative of waiting for insolvency (but rival may buy first)
<!--SR:!2026-07-27,1,230-->
Why does an employee-owned target create a special post-acquisition risk?::Staff motivation stems from their equity stake — a takeover removes it, so motivation falls and staff leave; mitigate with a share-for-share exchange (but your own staff without a scheme may feel aggrieved)
<!--SR:!2026-07-27,1,230-->
The "cash drain" post-acquisition point::Purchase consideration goes to the SELLING shareholders, not into the target — the acquirer must additionally fund the target's debts; check whether E$136.2m cash suffices or fresh capital is needed
<!--SR:!2026-07-27,1,230-->
Post-acquisition problem list (6)::IT/systems integration (no IT Director); unknown quality of target's management information; lost equity motivation; redundancy fears → pre-emptive departures; cash drain + target's debts; cultural clashes
<!--SR:!2026-07-29,3,250-->
How to handle redundancy fears at a target::Public messaging — no redundancy threat, job security improves as insolvency risk disappears, growth means career opportunities
<!--SR:!2026-07-27,1,230-->
Four methods of corporate re-shaping::Organic/internal growth; external growth (acquisition); joint development/alliances; disposal of part or all
<!--SR:!2026-07-27,1,230-->
In-house R&D vs buying capability — key FOR points::Keep 100% of benefits; familiar cost-control disciplines; serendipitous spin-offs and own patents; builds internal skills
<!--SR:!2026-07-27,1,230-->
In-house R&D vs buying capability — key AGAINST points::Up-front cost and time (impatient shareholders, depressed share price); behind the first mover; no industry expertise/connections; duplicates purchasable work; patent-infringement analysis costs; management distraction
<!--SR:!2026-07-27,1,230-->
The first-mover argument (Mock C)::Investing immediately establishes the brand and secures regulatory approvals early, creating barriers to entry; rivals face the same build lead time, so whoever starts first enters first
<!--SR:!2026-07-27,1,230-->
The materiality anchor for any big investment::Compare the cost to total assets or revenue — e.g. "E$2bn is more than half of total assets of E$3,789.1m"
<!--SR:!2026-07-27,1,230-->
Standard against-points for any major investment (5)::Financial exposure/gearing (debt-funded if share price weak); execution & lead-time risk (outflows before revenue, market shifts); new-competency/compliance risk (reputational damage if it fails); timing vs declining performance (announce carefully); raises the already-high beta 2.3
<!--SR:!2026-07-27,1,230-->
The L3 habit in evaluation answers::Counter your own argument — "However, this is true of any project and so is not of itself a reason not to proceed"
<!--SR:!2026-07-27,1,230-->
The compulsory closing line for investment evaluations::"A full financial appraisal will need to be conducted before any final decision is made"
<!--SR:!2026-07-27,1,230-->
How to attack a Mission/Vision/Values consistency question::Dissect phrase by phrase; give multiple interpretations of ambiguous words; test the vision against current performance data; take each value in turn; conclude with a recommendation
<!--SR:!2026-07-27,1,230-->
"Leading provider" vision test applied to Kwirtmak::Leading = highest revenues — Kwirtmak is NOT currently achieving its vision (revenue −18.8%, Breskko overtook it), so proposals that close the gap are consistent with the vision
<!--SR:!2026-07-27,1,230-->
"Innovations driven by customer need" caveat::Consistent ONLY IF customer needs stay at the core of the research — ever-more-sophisticated products no one wants have little value
<!--SR:!2026-07-27,1,230-->
Honest verdict allowed on people values::"Consistent, but not in any new or unique way" — nuanced evaluation scores
<!--SR:!2026-07-27,1,230-->
"Creates wealth and success" — how to analyse::Map benefits across stakeholders (employees' job security, customers' output, suppliers' volumes, shareholders' equity); acknowledge short-term wealth may fall due to investment cost but the proposal is long-term strategic
<!--SR:!2026-07-27,1,230-->
Digital disruptor list::AI; cloud/mobile; IoT; big data; blockchain; data visualisation; 3D printing; process automation
<!--SR:!2026-07-27,1,230-->
Three responses to digital disruption threats::Hyperawareness; perpetual innovation and adoption; focus on customers and their wants
<!--SR:!2026-07-27,1,230-->
Sustainability proposal — benefit families (4)::Public statement of intent; meets customers' own supply-chain sustainability expectations (shapes their buying); restores competitive position vs rival (Breskko PLA = 30% of mix); consistency with the "sustainable manner" vision (avoids greenwash, protects ecosystem trust)
<!--SR:!2026-07-27,1,230-->
Sustainability proposal — risk families (3)::Cost to customers (PLA 25% dearer — worst for thin-margin high-volume users); up-front investment needs full financial appraisal/fresh capital; arbitrary targets (why 50%? why 4 years? — research the right level)
<!--SR:!2026-07-27,1,230-->
How to respond to a journalist's sustainability attack::Don't commit expediently under press deadline; deploy the existing five-pillar sustainability record; recommend proper Board debate with research
<!--SR:!2026-07-27,1,230-->
Why might Breskko's growth be linked to PLA?::Breskko promoted PLA for 12+ months to 30% of its sales mix while Kwirtmak fell 19% — if customers buy on environmental grounds, Breskko is growing at Kwirtmak's expense; matching it restores competitiveness
<!--SR:!2026-07-27,1,230-->
Reasons to acquire vs reasons to dispose::Acquire — consolidate market, buy technology/skills/pipeline, speed to market. Dispose — better return on liquidated funds, strategic focus
<!--SR:!2026-07-27,1,230-->
