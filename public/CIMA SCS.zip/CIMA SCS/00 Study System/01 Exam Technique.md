# Exam technique — SCS

## Format
- 3 hours, 3 tasks (some split into sub-tasks), timings shown on screen per task.
- You are the **Senior Finance Manager** reporting to the Board — write to the person who asked (usually an email/briefing note to a director), professional tone, no bullet-spam: short paragraphs under headers.
- Marked against four competencies — roughly: **Technical** (financial/accounting knowledge), **Business** (strategy, markets), **People** (stakeholders, communication, ethics), **Leadership** (governance, risk, controls). Every sitting balances them, so never ignore the "soft" angle of a question.

## The scoring paragraph formula
**Point → Because (theory) → For Kwirtmak specifically (pre-seen/trigger fact) → So what (shareholder value / risk / share price / WACC / reputation).**
One idea per paragraph. 6–9 solid paragraphs per sub-task beats 15 shallow ones.

## Non-negotiables
1. **Obey the verb.** "Evaluate" = both sides + judgement. "Recommend" = pick one and justify. "Discuss" = explore implications. A recommendation section with no clear recommendation loses the judgement marks.
2. **Use every trigger paragraph.** Exam scenario text is never decoration — each fact is a hook for at least one point.
3. **Quote the pre-seen.** Names (Breskko, the E$, board members), numbers (margins, gearing, interest cover), values ("trusts its staff", halt-operations policy). Generic answers cap at a fail.
4. **Structure**: heading per requirement part → short intro sentence → point paragraphs → mini-conclusion/recommendation. Match headings to the requirement wording so the marker can map marks.
5. **Balance**: for any proposal give benefits AND drawbacks; for any risk give impact AND mitigation; then conclude.
6. **Time per section = marks per section.** Move on when time is up, even mid-sentence. Every task starts at zero — a brilliant Task 1 cannot rescue an unattempted Task 3.
7. **Plan for 3–5 minutes** before typing each task: choose framework, list hooks from the trigger, jot the pre-seen links.

## Default frameworks by question smell
| Question smell | Reach for |
|---|---|
| "Evaluate this proposal / strategy / acquisition" | SAF (+ SWOT hooks, risk, stakeholders) |
| "Assess the impact on stakeholders" | Mendelow power/interest |
| "Analyse the environment / external factors" | PESTLE, Porter's Five Forces |
| "Respond to currency / economic news" | Transaction–Translation–Economic risk + hedging menu |
| "How should we finance X / raise money" | Debt vs equity, WACC, gearing, interest cover, capital-structure considerations |
| "Value this business / what price" | Net assets → DVM → DCF → P/E → + synergy, + negotiation discounts |
| "Dividend question" | 4 policy types + stability, growth plans, signalling, clientele |
| "Risks of X + manage them" | Identify (register: likelihood × impact) → TARA responses |
| "Internal control weaknesses" | DAMPSOAP |
| "Cyber/IT risk" | Strategic, Economic, Availability, Security, Compliance, Performance |
| "Ethical issue" | CIMA code: Integrity, Objectivity, Prof. Competence & due care, Confidentiality, Prof. Behaviour → then respond: disclose, empathise, communicate, compensate, remediate |
| "Should internal audit look at this / audit approach" | IA types (system, risk-based, substantive, compliance, management, PCR) + independence |
| "Board appointment / governance" | Nomination committee, NED independence, board balance, committees |
| "Sustainability challenge" | Kwirtmak's existing sustainability record + brand/investor/regulatory angles |

## Every conclusion can touch
Shareholder wealth · share price · WACC/cost of capital · risk profile · brand/reputation (premium, innovative, sustainable) · staff morale · the numbers trend (falling revenue & margin means cash discipline matters).
