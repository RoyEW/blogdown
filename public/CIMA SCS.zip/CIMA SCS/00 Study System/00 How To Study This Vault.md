# How to study this vault

## What the SCS exam actually rewards
The Strategic Case Study is **not** a knowledge exam. Marks are awarded for **applying** a small set of frameworks to the pre-seen (Kwirtmak) in the context of new trigger information, writing as a Senior Finance Manager advising the board. Every scoring paragraph has the same DNA:

> **Point → Because (theory/framework) → Which means for Kwirtmak (pre-seen/trigger fact) → So what (impact on shareholders, share price, WACC, risk, reputation)**

That means there are only three things to learn, and this vault is organised around exactly them:

1. **Frameworks & theory** — the ~20 models that answer every question (folder `10 Topic Notes`)
2. **Pre-seen ammunition** — Kwirtmak facts, ratios and issues you must be able to quote from memory (note `20 Pre-seen/Kwirtmak Key Facts`)
3. **Answer patterns** — the reusable arguments that model answers deploy again and again regardless of scenario (folder `30 Answer Bank`)

Flashcards (folder `40 Flashcards`) drill all three so you can *recall* them under time pressure. The Question Bank (`50 Question Bank`) proves coverage: every mock task and workbook question is indexed there with the framework + points needed to answer it — if you can sketch a bullet plan for each entry, you are exam-ready.

## The study method (repeat in cycles)

**Phase 1 — Load the toolkit (days 1–3)**
- Read each note in `10 Topic Notes` once, actively: for every framework ask *"which Kwirtmak issue would I apply this to?"*
- Start the flashcard decks the same day. Do ALL due cards daily — 15–25 min. Recall beats re-reading.

**Phase 2 — Load the ammunition (days 2–4, overlaps)**
- Learn `Kwirtmak Key Facts` cold: the ratios (revenue −19%, operating margin 50.6% vs 56.4%, ROCE 34% vs 52%, gearing ~40%, interest cover ~10.9, dividend payout 53% vs Breskko 70%), the board structure, the values, the SWOT.
- These are what turn a generic answer into a passing answer. Flashcard deck `40 Flashcards/Pre-seen` drills them.

**Phase 3 — Pattern practice (days 4 onward, the core loop)**
For each entry in the `50 Question Bank`:
1. Cover the answer. Read only the trigger + requirement.
2. In 3–4 minutes, write a **bullet plan**: framework chosen, 6–8 points, each with a pre-seen link and a "so what".
3. Uncover the model answer summary. Tick points you got, highlight points you missed.
4. Missed points that feel reusable → they're already in `30 Answer Bank`; re-read that note.
5. Once per topic area, write ONE answer out in full prose against the clock (45 min per task section) — writing speed and structure are half the battle.

**Phase 4 — Simulate (final week)**
- One full 3-hour mock under exam conditions using the Question Bank entries you've least practised.
- After marking, feed every missed point back into flashcards.

## Daily routine (≈60–90 min)
| Slot | Activity |
|---|---|
| 15–25 min | Flashcards — all due cards, all decks |
| 30–45 min | 2–3 Question Bank entries as bullet plans (Phase 3 loop) |
| 15 min | Re-read the one Answer Bank note you were weakest on |

## Exam technique rules (drilled in `01 Exam Technique`)
- Answer the requirement **verb** (evaluate / recommend / discuss) — a "recommend" with no recommendation caps your marks.
- Use the trigger material: every exam paragraph exists to be used. If you haven't referenced it, you've missed points.
- Headers matching the requirement, mini-conclusion/recommendation per section.
- Time discipline: marks are per section; never overrun a section, a 60-minute task gets 60 minutes.
- Always close the loop to **shareholder value**: share price, WACC, risk, reputation, sustainability.

## Flashcards — setup
Install the community plugin **"Spaced Repetition"** (Settings → Community plugins → Browse → search "Spaced Repetition" by st3v3nmw → Install → Enable). Decks are tagged `#flashcards/...` per topic. Card format is `Question::Answer` (single colon-pair, one line) — readable as plain markdown even without the plugin. Review daily via the plugin's flashcard button; it schedules repeats automatically.
