# 🎓 CIMA SCS — Kwirtmak study vault

**Start here → [[00 How To Study This Vault]]** · Exam rules → [[01 Exam Technique]]

## Daily loop
1. **Flashcards** (15–25 min, all due cards) — install the *Spaced Repetition* community plugin, then use its review mode
2. **2–3 Question Bank entries** as bullet plans — cover, plan, reveal, compare
3. **Re-read** the topic/playbook note you were weakest on

## 10 · Topic notes (the toolkit)
- [[A - Business Strategy]]
- [[B - Business Ecosystem & Environment]]
- [[C - Financing Strategies]]
- [[D - Risk Management & Ethics]]
- [[E - Internal Controls & Governance]]

## 20 · Pre-seen (the ammunition)
- [[Kwirtmak Key Facts]]
- [[Kwirtmak Financial Analysis]]
- [[Kwirtmak SWOT & Likely Exam Themes]]

## 30 · Answer bank (the skeletons)
- [[Answer Playbooks]] — 16 reusable answer skeletons + universal closers (final-week cram sheet)

## 40 · Flashcards (the drill)
- [[Flashcards - Pre-seen Facts]] (~57 cards)
- [[Flashcards - A Strategy]] (~29)
- [[Flashcards - B Ecosystem]] (~37)
- [[Flashcards - C Financing]] (~36)
- [[Flashcards - D Risk & Ethics]] (~31)
- [[Flashcards - E Controls & Governance]] (~31)
- [[Flashcards - Exam Technique]] (~17)

## 50 · Question bank (the proof) — every exam-style & practice question
- [[QB - Mock Exam A]] — currency/economic risk · beta & board · scenario planning & ransomware
- [[QB - Mock Exam B]] — Northland R&D centre · political risk · Mendelow · N$ borrowing · bribery ethics · anti-bribery audit
- [[QB - Mock Exam C]] — medical facility investment · KPIs · share-price/EMH · interest-rate risk · governance breach · withholding-info ethics
- [[QB - Mock Exam D]] — Titan Cycles: SAF acquisition · 30% stake valuation · in-house R&D · board ethics (built from your own attempt, ⭐ = enrichments)
- [[QB - Practice Workbook Tasks]] — A1 A2 B1 B2 C1 C2 D1 D2 E1 E2 + 7 familiarisation exercises

Legacy class notes: [[SCS]] · [[SCS Mock Exam D]] (originals, superseded by the notes above)

## Coverage check (every topic that appears across all 4 mocks + workbook)
SAF & investments ✓ · acquisitions & post-deal ✓ · MVV consistency ✓ · sustainability ✓ · digital ✓ · PESTLE/Mendelow/scenario planning ✓ · political risk ✓ · KPIs/balanced scorecard ✓ · currency (all 3 types + hedging) ✓ · interest-rate & CapEx-freeze ✓ · sources of finance/rights issues/foreign borrowing ✓ · dividend policy ✓ · valuations & hostile bids ✓ · EMH/share price/beta/WACC ✓ · risk registers/TARA/KRIs ✓ · cyber & ransomware ✓ · CIMA ethics + bribery ✓ · DAMPSOAP/internal controls ✓ · internal audit (all types + forensics) ✓ · governance/boards/committees ✓
