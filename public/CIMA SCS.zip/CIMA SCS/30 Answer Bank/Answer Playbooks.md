# Answer playbooks — reusable skeletons by question type

The condensed "have ready to go" sheets. Each is the skeleton the model answers actually used; hang scenario facts on it. Full detail lives in the topic notes; drill recall via the flashcard decks.

## 1. Evaluate a strategy / investment / proposal (SAF or For–Against)
1. Materiality anchor: compare cost to total assets (E$3,789m) / revenue (E$2,320m)
2. Suitability: mission/vision fit · competence fit ("reduces risk of strategic failure") · addresses the strategic problem (falling revenue vs Breskko)
3. Acceptability: shareholder returns & risk (beta 2.3, depressed share price ≈E$50) · other stakeholders' reactions
4. Feasibility: cash E$136.2m + debt headroom (gearing 39.1%, interest cover 10.9x) · skills · legal
5. Standard against-points: financial exposure/gearing · execution & lead-time risk (outflows before revenue; market shifts in the window) · new-competency/compliance risk (reputation if it fails) · timing vs declining performance · raises beta
6. Counter your own points ("However, true of any project…")
7. Close: **"a full financial appraisal must be conducted before any final decision"** + recommendation

## 2. Acquisition (see [[A - Business Strategy]] for full lists)
For: fit/reputation · related diversification · workforce/skills · pipeline adds value day one · growth segment · synergies · distressed-seller price. Against: lender scepticism → due diligence · destroy the asset you're buying (employee-owners) · bidding war/overpaying · management distraction · wait-for-insolvency alternative. Post-deal: IT integration (no IT Director) · staff equity/motivation (share-for-share, but own staff aggrieved) · redundancy fears → messaging · cash drain (consideration ≠ investment; must also fund target's debt).

## 3. Business valuation / purchase price
Net assets (floor) → replacement cost (what a bidder saves; exposes asset-stripping) → DVM (nil if no dividends — use to negotiate down) → DCF (most robust; R&D pipeline; caveat: beta 2.3 → high WACC; forecasting risk) → P/E on **normalised** 3–5-yr earnings (never depressed current profit) → + synergies, − minority-stake discount, − distressed-seller discount. Recommend a range + negotiation strategy + due diligence.

## 4. Share price / market announcement (EMH first)
Price = PV of expected future cash flows (semi-strong EMH). Reaction drivers: perceived NPV · materiality without appraisal · risk perception (beta 2.3, regulator) · funding method (debt + rising rates) · looks impulsive after a 6% fall. Protect: delay until appraisal/funding certain · investor/analyst briefing on existing strengths · confidentiality vs disclosure trade-off (Breskko copies) · absolute honesty (potential ≠ guaranteed revenue).

## 5. Debt vs equity / raise finance
Pecking order (retained earnings → debt → equity). Debt: quick, tax shield, repayable / adds risk, interest drains cash, covenants. Equity: permanent / dilution, costly, weak share price makes it unattractive. Balance to minimise WACC; currency-match debt to assets/revenues; evidence: gearing 39.1% vs Breskko 29.9%, interest cover 10.9x falling, 8% fixed. Rights issue: discount, failure risk, TERP/EPS dilution, bailout signalling → deep discount + underwriting + IR campaign. Foreign-currency loan: local goodwill, security, tax shield, political ally / FX risk on a cost centre (no natural hedge), IFE unreliable in emerging markets, covenants.

## 6. Dividend policy
Types (constant, % of profits, residual, zero) → assess against: profit stability · growth plans · **signalling** (cut = panic; maintain = stability) · **clientele** (income investors sell — in a bid, to the bidder) · cash needs. Hostile-bid rule: survival first, maintain the dividend, fund strategy another way. Contrast: Breskko ~70% payout (confidence) vs Kwirtmak 53% (prudence/R&D retention).

## 7. Currency risk
Classify first: **transaction** (invoices — forwards, futures, options, money-market, swaps, leading/lagging, invoice in E$) · **translation** (consolidation paper losses — E$44.3m reserve; matching possible but **don't hedge**: non-cash; manage investor relations instead) · **economic** (long-term competitiveness — **do mitigate**: operational hedging via overseas factories + value-based pricing on total cost of ownership; never a price war). Understanding-the-risk points: customer self-hedging, price inelasticity of mission-critical products, 90-country fragmentation, high GP margin (64.3%) weakens the cost-side natural hedge, unpredictable competitor response.

## 8. Interest-rate rise
Four buckets: debt cost (compute: 8% implied; stress-test new debt; gearing chain 64%→159%) · customer demand (their CapEx is financed) · currency (rates↑ → E$↑ → exports dear) · WACC/NPV flip. Responses: fix rates (bonds/swaps) · phase capex · customer leasing (CapEx→OpEx; watch working capital) · natural hedging · monitor indicators · lender relationships.

## 9. Scenario planning / treasury contingency
Per scenario: impact + why material (quantify) → leading indicators to monitor → short-term liquidity (sensitivity cash-flow forecasts; worst-case overdraft) → medium-term structural response (repricing via Ouyang Qi; fixed/variable mix) → pre-arranged relationships (banks, consultants on retainer). IT disruption: hot backup site (real-time mirror, geographically remote — "not the outskirts of Capital City", bank-connected) + communication plan + realistic restoration forecasts.

## 10. Risk register / new risk debate
Register fields: description & impact · likelihood × impact ratings · overall rating · dates · residual risk · owner (+ KRIs, risk appetite, net vs gross). "Should it have been on the register?": foreseeable strategic risk vs (external act, quantification difficulty, trust-culture cognitive bias, net-risk assumption, no board IT expertise). Then TARA the responses and design controls.

## 11. Cyber / ransomware
Six categories (strategic, economic, availability, security, compliance, performance) each with a control. Ransom: don't pay (no guarantee, repeat target, criminals' incentives, residual malware, governance signal, director accountability) — acknowledge and rebut the "hacker reputation" counter. Rival attacked = free diagnostic.

## 12. Ethics
One header per CIMA principle (+ threat category, Mock B style): define → apply to the person's own quoted words → consequence (legal, reputational, share price). Killer lines: omission = lying by omission if material · commercial nervousness = conflict of interest · shareholder interest never justifies misleading on safety-critical matters · hoping to fix it later ≠ excuse · counterparty's failings **increase** your burden · motive irrelevant under bribery law. Respond: proactive disclosure ("radical honesty" before the press), empathy, communicate with victims/regulator, compensate, remediate.

## 13. Governance breach / board questions
Unauthorised action: Matters Reserved for the Board · time pressure no excuse · bypassed NED/CFO oversight · sunk-cost bias · fiduciary duty · values are no defence (trust ≠ unregulated authority). Fixes: bonus sanction, (weighed) resignation, authority matrix + dual signatures, hard ERP controls, emergency subcommittee with 24h ratification. New director: advantages (tone at top, specialist voice, investor reassurance, lower cost of equity) vs (board balance 5:4, knock-on NED hires, blurred accountability, wrong diagnosis — information flow not capability) → propose the cheaper third option (reporting lines to Audit/Risk Committee) or **both** an executive AND a NED. Appointments = Nomination Committee's call; assess role, independence, skills balance, time, personality/challenge culture.

## 14. Internal audit
Deploy: competence & independence → map procedures → assess design adequacy → test operation → report. Investigation: widen search → preserve evidence (read-only logs) → urgent prelim report → sceptical interviews vs digital footprints → root cause (system vs culture/bonus design) → fact-check with CFO → fixes + 6-month follow-up. Tests: compliance (exception reports, near-limit clusters, PO sequencing, access rights) vs substantive (supplier bank matching, stock-to-record, email forensics, data mining). Independence: report to Audit Committee; self-review threat; IA ≠ police force (blame culture). Anti-bribery programme: see [[E - Internal Controls & Governance]].

## 15. Stakeholders (Mendelow)
Rate interest and power **separately with scenario justification** → classify → state the management strategy (engage / keep informed) and what it means for the decision. Power is contextual: unions/collective action (short-lived if site closes anyway); government power depends on other in-country interests; potential employees ≈ always low power; quasi-government bodies with grants = high power. Other governments are watching.

## 16. Sustainability response
Deploy Kwirtmak's 5-pillar record (governance/halt-operations · additive efficiency · localisation · 32% energy cut · regulator engagement) + benefits/risks of the new commitment + challenge arbitrary targets + don't be rushed by journalists (respond with the record; debate properly with research).

## Universal closers (the "so what" bank)
Shareholder wealth · share price ↔ WACC ↔ cost of capital · risk profile/beta · premium-innovator-sustainable brand · staff morale & retention · dividend maintenance · falling revenue/margin means cash discipline · "full financial appraisal before any final decision."
