### topics that might come up
- currency risk with operating over multiple countries
- Potential whistleblower issue regarding the policy that every employee feel empowered to halt operations if they see that htey are not being sustainable -> how would they actually be able to manage this risk? Woulf they tryt to silence the whistleblower, come at financial cost
- Do the financial ratios for the company and the competitor as there may be some issues
	- Share price is down, revenue is down, operating costs haven't come down as you'd expect,
	- May htey have been under pressure to cut discretionary spending instead of cost of sales thus short-termism, i.e., cutting R&D, loss to reputation as a leading innovator, having an impact on the investor perspective and further lowering the share prince, do they need a new strategy?
- Potential to reach into new markets for application usch as the sports market with carbon fibre, enginerring challenges? R&D? Sufficient capital to fund growht? 
- For dental work, potential to get the green light to be able to sell new printers to dental practices
- 

Senior finance manager -> report to board of directors, more about governance and strategy -> foicus on stakeholders

Research - have these ready to go
- SAF
- Porters strategies (Differentiator)
- DAMPSOAP
- Impact on WACC and risk, therefore shareprice
- Competittor is growing, maybe dividen policy better?
- Financial gearing - could raise more debt
	- Cash is available but equity cost
- Links with governemnt (Madda, Non-exec chair, Ada, sionior independent director)
- Values of Kwirtmak, customer need innovation, create wealth and success, overdelivers on promises, trusts its staff, staff are team players
	- All staff are empowered to halt operations, too much freedom? Do employees actually action this? what are the incentives to actually halt operations, it's probably not enough to give them the freedom to halt operations without the incentive to do so as they depend on Kwirtmak operations for jobs, maybe this retains employees that are risk-seekers who care less about sustainability although Kwirtmak enjoys the benefits of being known as a sustainable organisation with this policy. 
- Financial ratios - revenue down ~19%, operating profit has dropped 6%, maybe they do not have a cost control culture where costs also drop in line with reduced revenues, Fixed costs have not dropped in line with lower revenues, thus ROCE falling from 52% to 34%
- Kwirtmak will need to investigate if the fall in sales are part of a wider economic trend or if Breskko is finding success with more innovative products or better marketing thus taking more of a market share over Kwirtmak
- Kwirtmak is more highly geared than Breskko thus has a higher degree of financial risk, a key concern for the board given the drop in profits
- Long-term borrowings with a 8% interest rate suggests fixed long-term borrowing costs thus protecting both companies from short-term interest rate volatility, giving them certainty of their finance costs,
- An interest cover of 10.9 is still reasonably good and suggests more debt can be taken on as it will still be repaid, but the fall from the previous year suggests that this has the potential to greatly increase the exposure to interest rate risk as the trajectory is a bad signal to investors who may perceive this as a significant increase in risk. 
- Equity finance and dividend policy
	- paid out 53% of prodit in dividend compared to 70% for Breskko, this may have been because Breskko is prohecting confidence in its ability to generate future cash flow, whilst Kwirtmak may be cautious to investigfate the fall in market share and operating profit, Both companies seem to want to attract long-term and stable investors. Kwirtmak may be wanting to invest the profits back into R&D for future growth
- SWOT
	- Strengths
		- Diverse product range
		- Market reputation and position
		- Global manufacturing and sales
		- Customer loyalty with the offer of materials
		- Strong technical leadership
	- Weaknesses
		- Declining financial performance
		- High market sensitivity
		- Dependence on third-party suppliers
		- High cost of products, untapped market with more price sensitive commercial entities
	- Opportunities 
		- Medical and dental sector expansion - once EHS approves materials, there is a growth opportunity with dental implants, heart valves, and artificial limbs
		- Advanced materials increased demand - high-strength, light-weight, 
		- Sustainability leadership - Reduced material waste, local production, recyclabnle plastics
		- Bespoke commercial applications - jewellery and aerospace, rapid production of spare bespoke parts reducing the need for investory space costs
	- Threats
		- Intense competition, very similar local competitor, one of 8 major manufacturers 
		- Economic and global volatility, global trade exposes Kwirtmak to economic trends, interest rates and inflation, currency risks, supplier costs and custoemr demand
		- Regulatory and legal risks - significant exposure to health and safety and environmental legislation, could lead to heavy penalties
		- Technological obsolescence, rapid changes in CAD software and 3D printing, requires high-cost investment into R&D to remain competitive
- Strategy and sustainability
	- Operations director has specific repsonsibility for sustainability and reports to the board regularly
	- Environmental metrics - actiuvely wortks to reduce energy consumnption of its prijnters , PLA reduction of 32% 
	- Promotes local printing and reudction of carbon footprint and material waste
	- 

### Main core activities
- Develop business strategy
	- Stakeholders, how toi grow, how to differentiate and sell
- Evaluate the business ecosystem and business envbiuronemnt
- recommend financing strategies
	- Business valuateion, debt vs equity, share for share policy, 
- evaluate and mitigate risk -> ethics, goivernmance 
- recommend and maintain a sound control environment




- Get the senior NEDs to focus on connectiuons and find out about potential changes in legislation or lobby on behalf of the business
- Executive director for IT
- Who looks after sustainability? Perhaps exuctive direector has too much repsonsibility to focus on iondividual
- huge risk if products are not up to standard, damage to brand who focus on high quality products 

### Core activities
**Core activity A** business strategy
- value chain analysis
- portfolio analysis
- SAF framework (sustainability, acceptable (return, stakeholders), feasible)

Main methods of corporate re-shaping
- internal/organic growth
- external growth
- join development
- disposal (sell parts or the whole of the business)
- Reasons for acquiring (consolidating the market, get technology etc)
- reasons for disposal (bettern return on the liquidated funds)
**Technology disruptions**
- AI
- Clou7d and mobile computing
- IoT
- Big data
- Blockchain (property rights and publications)
- Data visualisation and analysis (hotpots, highlight areas of focus to extract value or maximise impact of efforts)
- 3D printing (printing medicine, clothes, or food)
- process automation

Impacts of digital technologies
- business model
- structure
- people - social media creators with the skills, graphic artists
- Processes
- allow better offerings to customers
- engagement - customised experiences for customers,

Respondiung to threwts to digital technologies
- hyperawareness
- perpetual innovation and adoption
- focus on the customers and their wants

Example question on digital strategy (introducing an app)
SAF (suitability, acceptability, feasibility)
**Suitability**, can increase sales, shifts towards healthier options
- but lack of expertise in creating apps and managing a social media campain or bid data analysis
**Acceptability**, customers may like with discounts and engagement, shops gets more sales, government may welcome the positive social impacts and reduced consumption of sugar
- but customers may resent the intrusion, shops may resent time taken in purchasing the products and verifying and processing the discounts,
- may not be a financial success, expecsive to develop and maintain without clear financial benefits, 
- risks with data collection of customers,
- other food makers may rival it and reduce its usefulness
**Feasibility** - bar codes available,
- no expertise with developing apps
**Conclusion**
A very basic app and not a digital strategy thus unlikely to have major impact on sales or behavious but should be a worthwhile and cheap way to test the engagement of customers and gather initial signs of a full strategy working in practice

Example questions
- evaluate strategic proposal (SAF, have SWOT, risk, and stakeholder analysis ready to go)
- Evaluation of acquisiotion (where is the synergy, what benefits are looking to be aquired, nationalisation, custural clashes, where the money going to some from, sources of finance, due diligence)
- Evaluation of divestment, flotation, outsourcing, MBO, disposal, change management 


### Core activity B ~(Ecosystem)
stakeholder mapping (identifying, medelow's power/interest matrix)
Pestle analysis for identifying environment 
Porters 5 forces (entrants, buyers, suppliers, substitutes)
Scenario plannig -> drivers of the future/megatrends [[scenario planning answer]]
- Growth of cities, social media, AI, misinformation
- Demographics, expectations, tastes, obesity rates, 


CSFs (critical success factors) KPIs and risks 
KPIs should be smart, 
- specific - exact what is being measures 
- measureable - objective
- attainable - 
- relevent - metric rising or falling impacting the CSF
- time bound

economic and political risks
chang eis minimum wages, tarriff changes,
how to manage risks - reduce impact, reduce unlikelyhood, diversify, 
currency risks -> **special focus**
- economic currency risks (home currency appreciates so goods sold internationally become uncompetitive, competition from cheaper imports)
transaction risks - volatility of currencies means more costly intermediary goods purchased leading to higher costs, mismatch of revenue and costs, and sales side where we receive less of our own currency by selling in a foreign currency
translation risks - assets and laibilities are reported in foreign currencies, which can make it look like the value of the company is going up and down, which has no impact on the actual value of the business as it's just a paper gain/loss but may still spook investors and shape their opinion

Responses to currency risks
- operate in domestic currency - eliminates transaction and translation risks, but creates higher exposure to economic risks
- time invoices and payments with currencyu changes
	- tricky to plan, and tricky to plan cash flow
- real hedging - manufactur within the country we're selling into, but may increase political risks
- foreign money market accounts, borrow money in foreign currency
- forward exchgange contracts - get banks to manage the borrowing and sellings of different currencies, but may be costly with a bad rate,
- currency futures - perfect hedge agaiunst risks although we eliminate any upside gain
- currency options - the option to execute a currency future which allows the gains to be realised if it's favourable although will come at a premium
- swap agreement, find someone doing the exact opposite transaction - counterparty risk

### Core activity C - financing strategies
-   recommend suitable sources of finance
	- Profits, investments by shareholders
	- Short-term capital
		- bank overdraft, expensive but flexible
		- commercial bills, like overdrafts but IOUs 
		- debt factoring
		- term loans, corporate bonds, 
	- Mezzinine finance - convertable loans 
	- Asset leasing, selling then borrowing back
	- **Considerations in capital structure**
			- Business risk and security
			- Flexibility
			- Tax impacts
			- Currency issues -> try to raise debt in the currency that the assets will be used in
			- market sentiment, market might be down so it may be difficult to raise money
			- right balance of debt/quity to minimise the WACC
-   recommend dividend policy
	- If we pay dividend then we can't retain earnings
	- **4 different types of policy**
		- pay a fixed amounbt - unflexible, expected return to investors, tells them what cash they're going toi get, may make it obvious that we're in trouble though if we aren't able to pay the fixed amount
		- A fixed percentage of profits can make it so that investors are very interested in the profit of the business but may lead to short-termism
		- Investor what is needed back into the business for growth and what else is left then give direct to shareholders
	- When setting policy (look at pre-seen) 
		- How stable is the profit? if unstable then move to percentage of the profit,
		- What are the growth plans, if growth then don't want to pay too much dividends
		- Signalling effect -> changing policy may signal to investors what is happening in the business
		- trying to save cash, or trying to bribe investors to save the board, 
		- clientelle approach -> what type of investor do you want? risk seeking ones, or stable investors - if you change policy thgen the investors may look elsewhere and sell
-   recommend and apply business valuation models.
	- lowest valuation is net assets (no cinsideration to brand, staff, revenue generating potential), firms tend to trade for around 5x its net assets
	- dividend valuation method (present value of its dividends over time) ignores share price going up
	- Present value of cash flows (assumes perfect knowledge, difficult to forecast)
	- Earnings/PE method - comparitive company P/E ratios can be used to judge the toal value
	- potential synergies (allows a higher purchase price as the funds may be returnd in the form of synergy valuation)
- Efficient market hypothesis
	- Shares are fairly priced as knowkledge is known in the market about its future cash flows
			- Weak - stock price reflects only stockholder information
			- semi-strong - all public informatuikn is incorporated
			- strong
- Factors influenbcing share prince (Common exam question)
	- market expectations of future free cash flow
	- assessment of risk, share prince and cost of capital
	- dividend policy, higher dividend will bhring cash to shareholder so shares would be more (dividend irrelevance hypothesis, limits growth so potentially no value)
	- speculationa nd rumours (they may act quick before doing calculations)
	- systemic risks
- A question regarding a change in share price
	- Efficient market hypoitheis - change with economic factors
	- unexpected announcement - incomplete information and speculation, initial panic, increase costs of goods
	- [[Share price suggested answer]]
	- Common questions include #
		- methods of financing - types
		- need to know assets and capital and share price of Kwikmart
		- what is the time period of borrowings
		- Benefits of debt vs equity in fianncing
			- debt is quicker, tax credits, can be paid back,
				- increases risks, and you need cash to pay the interests, deprice cash flow, increases risks, 
				- quity is permament, can't pay it back, dillution, lose voting power, a mixture of the two to WACC
			- Ipacts of share price of events on the firm, efficient market hypothesis, 
		- Factors affecting cost of capital
			- debt - general interest rates
			- capitalk leverage - beta coefficient, risks sstemic and non-systemic 
		- How toi value and acuisition or disposal
			- 5 methods of valuation plus nbegotion
		- considerations in changing dividend policy

### Core activity B Risks
Intenral controls (DAMPSOAP)
- division of responsiblities
- arithmetiuc and accounting
- management
- personel - standardised testing, references
- superviison - audited 
- organisation - strucutre, procedures, processes
- authorisation and responsiubiluty (senior signing off)
- physical (protextion

**Tara** - transfer, avoid, reduce, accept

### Cyber risks
strategic - no systems for IT, fallen behond the times
- maintain  senior management awareness - CTO
Economic - spending monety on big data but not learning anything useful, or dead money on poor systsem
- shouldn't make decisions based on what is cool for the IT department, but should be the responsibility of the accountant to quantify and identify the deliverables
Availability - if systems go down or crash, DDOS
- test any new systems, distribute applications and database systems across regions to ensure availaibility of services if say one data region goes offline
Securioty - hacking, losing data, poor data integrity, 
modifications causing loss of data
- password, encryption, response systems, managing communications and checking exploits,
compliance - not following regulation so we get shut down
- internal audit, chief legal officer keeping up to date with legislation
performance - slow systems making people unhappy, 
- steering groups, outsource with SLAs

### Example question regarding misclassification fo risk
Overview
- define the risk register and how risk is calculated
- Arguments in mitigation - how was the risk arrived at?
	- Decision is without precident,
	- regulation is not yet inevitable
	- Already got 4 risks at a high level, potential for overloading attention on risks, although the sugar tax is not 
- Conclusion
	- Did the relations with the governemnt not yield any clues, were these not communicated back to the risk register? Were press articles downplayed? is there an issue with the risk culture with little awareness of risk? 
	- Risk register needs to be updated. 

Common question include
- Risk identificaiton
	- Risk register - harzard, 
- Risk management
	- DAMPSOAP - TARA - culture
- Cyber risk identificaiton
	- Strategic, economic, performance, security
- Cyber risk controls - have some ready
- Combine with other subjects - SAF analysis,
	- Reducing risk may lower WACC and boost share price

### Ethics
- professional behaviour - 
	- laws and regulations, not discredit the profession, 
- integrity, straightfoard and honest
- professional competence and due care
- Confidentiality - not sharing business information or using business information for personal gain
- Objectivity - avoid bias and do due dilligence without subjectivity, and personal interests

**Responses to ethical dilemmas**
- Transparency and disclosure
- Express empath and awareness of the harm
- communicate with victims and regulator
- compensating actions
- remedial action - make clear what steps have been taken to fix the issue 

[[Ethics example question]]

**common questions**
- engineer a problem that could breach the ethical code
- Ethical advise - advise of the ethical problems
- Strategic evalusation SAF evaluation - risk and reputational risk, share price may be marked down thus raising WACC and lowering share price

# Core activity E - internal controls
Internal audit 
- definition - independent of design and processes, investigates and reports to management
- Are they truly independent as they depend on management for jobs?
- Maybe there can be an audit commitee on the board to not be subject to maangement?
- Can they have an audit team that goes to branch to brach, system to system, that are strangers who don't have good friends with the branches to audit them for independence
- May be outsoured - independent, 

Standards
- proper organisation structure - typically NEDS who are separate from the executive
- Proper management - what are the major material risks, reviewed anually and submitted for approved
- Proper standards - ethical code - analyse, evaulate to give a qualified opinion and communicate these findings to the system owner

Types of audit 
- System based auditing -  is there an appropriate system? is the system working? what are the limitations of the system, how could it be improved? The auditor does not improve the system but simply reports on findings
- Risk based internal auditing - placed resources in areas of audit of places with the highest inherent risk
- substantive procedures audit approach - if something breaks down in internal control such as using unlicenced software then focus on the areas with the greatest materiaility
- compliance audit - statutory requirements, explain what the things are, accreditation standards, breaks given, 
- social and environment audits
- management audits - are managers given targets to hit, importance of independence of auditors - how do they make decisions, do they delegate appropriately and enough, are they compeotent, do the communicate effectively and timely? What information do they use to base their decisions
- Post completion review - an audit function will look at the project after it is finish - learn lessons and see if project management can be improved afterawrds

Simple step by step to deploying internal audit
- Are the staff competent with the relevant skills to audit? Do tyhey have the knowledge and competence? is  it a normal course of business activity?
- Indepeendence - 
- Research and record existing proicedures and ystsemns, mapping
- assess adequacy of existing systems, what's gone wrong, what are the limitations, how could it be improved? Maybe compare with the industry practices
- Assess operation of exisitng sytems - real metrics can be analysed instead, checking outputs themselves to ensure the system is working correctly 
- Communicate findings to management 

Corporate governance
- definition - the board of directors and other stakeholders
- responsibilities of the board of directors
- principle agent problem - issues of board conduct - directors may work in their interests - directors can set their own pay - maybne this should be set by a remuneration committee, nominatation committee
	- risk committee
- Operation of the board - culture, EDs doing and NEDs monitoring, 50/50 split, Decisions reserved for the board
	- Strong independent elemtn in the board who can stand up and challenge the CEO
- principles of corporate governenance 

Exacm task- would is be appropriate to ask the internal audit team to investigate, and key controls we can introduce 
- No staff screening, any staff could access and alter social media accounts of users, potential for customer data to be extracted and leaked
[[Internal controls example question]]

**Common questions**
- how to conduct an internal audit - steps - risk-based and substantiber transactive approach
- Suitability of using IA for issues, insider trading, DD for buying a company
- Recommending improvements to corporate governmance, ethics and challenge the boss
- Assessing suitability of potential appointees to a board - remember that it is a nomination committee's decision and not a CFO's decision, what role are they going to play, they are going to do something not just advise, how indeopendent are they, what the impact on the current board or impact on the culture
- other subjects - cyber risks, corporate governmentce, sustainability


# Workbook Practice Questions
### A1 - business strategies - aquisition
SAF framework
- Pros
	- Potential for expertise and experience of staff imediately onboarded who can advise and guide production of printers specifically for advanced materials with carbon fibre
	- The production chain and expertise could ensure that Kwirtmak is first to market with the new range of products using advanced materials thus tapping into more of the market for these products as demand rises, thus giving it an edge of Briskko.
	- **Reputation of CFP can be absorbed into Kwirtmak, and the acquisition could further enhance Kwqirtkmaks brand image of innovation and high quality products**
	- Current employees are highly motivated and loyal, as well as highly skilled which is an attrictive offer for Kwirtmak, provided these can stay happy once working for Kwirtmak. Working for a larger organisation may give them more experiences and opportunities which they may like. Opportunity for both groups of employees to learn from each other. 
	- With the orders already in the pipeline at CFP, it could be the case that CFP starts to add to the value of Kwirtmak almost immediately, asusming that orders are fulfilled to customer satisfaction. This could have the impact of increasing share price and assuring shareholders that shareholder wealth is being restored. 
	- The acquisiotion may be suitable to shareholders and the board who are seeing the rise in demand for carbon fibre products so would like to see a sharp entry and investment into this area of business activity, thus keeping Kwirtmak on the frontier of innovation, even if it purchases the ability to do so. 
	- Strong technological knowledge within Kwirtmak should be able to understand the capability of CFP and learn from them regarding technological processes, perhaps generating a synergy once the purcahse has gone ahead. 
	- It may be that the bank do not simply understand the 3D printing market, especially with how it is more risky than the overall market. Kwirtmak could leverage its established position in the market, business activity, and size to assure banks and investors that adding CFP to its portfolio could generate a boost in confidence of this asset thus making it a very unique opportunity for Kwirtmak. 
	- The loan facility incorporated into Kwirtmak increasing its borrowings is still within reasonable limits, thus making it suitable for acquisition. 
	- It may be that due to the uncertainty over the lending facilities to CFP, the CEO may be looking to sell this quickly so may be willing to accept a lower price for the company thus bringing return to Kwirtmak's shareholders. 
	- There may be safeguards applied with a higher offerring from Kwirtmak to alleviate the concerns regarding the distressed sale of CFP for CFP shareholders, if it believes that the value for synergy will be great. 
- Cons
	- More research will need to be undertaken to fully understand what products and materials CFP offers to customers, they say they realise the potential for carbon fibre technology but what technical skills and abilities does the company already offer in this area? Potential for buying a work in progress rather than an establish production chain and route to market, it may be of little benefit above the current skills that Kwirtmak already have or could easily invest into. 
	- The timeliness of the deciison needing to be made due to the potential interest from Breskko may lead to lack of due dilligence being carried out, thus creating a loss to current shareholders and making them unhappy leading to higher WACC and lower share price of Kwirtmak. There are multiple things that need to be consdiered prior to the purchase, and with the competiution, it may be that Kwirtmak is incentivised to overpay for the company making a positive return to shareholders less llikely. 
	- The distressed sale of CFP may alienate shareholders of CFP and make them unhappy and as most of these are employees of CFP, it may lead to a lack of morale. 
	- Internal controls present in CFP - the company has only been around for a short amount of time, their internal controls will need to be evaluated to ensure that they are consistently producing high quality products and it isn't just short-term success that they've found. A lack in quality could have huge rammifications on the brand image of Kwirtmak, as it will damage their image of a brand that produces high quality good, this may worry investors and lead to a lower share price thus raising financing costs with the WACC. 
	- Increased debt into the Kwirtmak as the loan needs to be paid off within 6 months, this has opportunity cost as the funds going into the purcahse of CFP could have been used to invest in this area of research ourselves or onto other profitable areas under our control so we can be sure to its quality. 
	- Kwirtmak lacks a head of IT, so IT systems across the two entities coiuld be incompatible thus making it difficult to integrate the busienss completely into Kwirtmak limiting it's ability to generate synergetic value. A head of IT could review the two systyems to see if they are compatible prior, although CFP could still operate as a silo entity within Kwirtmak. 
- I would recommend a plan to investigate the internal controls of CFP to ensure it can continue to produce high-quality products as we only have hearsay of their reputation, as well as evaluate their unique offering of the production of printers using advanced materials as this is unclear from the discussion that David had. 
- An acquisition of this nature has the potential to take up a lot of time and resources away from management, thus a risk that core operations of both buyer and seller start to sugger due to management being distracted. We should be careful of such dangers. 
- P**ost acwuisition issuies include**
- Lack of morale of employees of CFP as they are shareholders, and they believe it was a distressed sale, although they may be greatful that their investment and jobs were saved by Kwirtmak, communication regarding the sale should be key. it should be worth considering how CFP fits into the sustainaibklity frameowkr of Kwirtmak as this doesn'#t sppear to have been explored yet, products may be good and use advanced materials giving access to a new market, but may be very energy intensive and have weak suplpy chains, this environemnt will need to be explored. 
- Cultural differences between the organoisations
- Integration of IT systsems, will take time to make tghem compatible, and we lack a head of IT department, but could leverage the one from CFP if they have one and they should understand their systems well to integrate the systems, although they make lack awareness of Kwirtmak's systems and have little oversight and control from the group's perspective which may pose a risk. 
- Employees will no longer have shares in the company - they may no longer be as motivated to perform so well without the ownership stake. The may also leave for another 3D printing business and take their skills and experience elsewhere which is a risk. 
- Kwirtmak could consider a share for share deal to ensure that the employees continue to have ownership in the entity that they work for to keep them motivated and focussed but this may alienate current employees who may not have been afforded the opportunity. 
- Staff at the target company may be fearful of losing their jobs once the takeover has been compelted, so communication will need to be considered highlighting that the takeover would be saving jobs as well as offering potential opportunities within a larger organisation, especially as growth is being considered. 

### A2 - business proposition for sustainable materials
Environemntal sustainability is a global trend where investors and consumers are more intersted in, using biodegradable materials and promoting the use of these materials is important to ensure plastics and microplastics don't end up in the environment for long periods of time causing harm. The effect of companies promoting non-degradable materials is significant as enviromentally conscious investors may look to avoid investing in these companies. 

The benefits of the proposal
- Solidifying the brand image of quirkmak as an entity that is a force for good for the environement, in that is is conscious of its impact and actively works for the benefit of the environemnt where it can whilst producing good quality products and services. 
- This may attract more investors to Kwirtmak as there may be investors that are more conscious of the envuironemnt and wouldn't otherwise invest without the commitment to encourage the use of non-degradable plastics
- Increase in investors may lead to a more sought after shareholding, thus leading to a higher share price and lower WACC of the business, allowing it to work more efficiently and more room for funding options
- The adoption and encouragement of using PLA compatible printers may encourage innovation within this area as there appears to be a need to bring costs down. Current work in this area appears to have been done by Breskko and with little competition, they may have been applying a higher premium on these products with a higher margin, i.e., a premium for the enviromentally friendly good. Kwitmak may benefit from selling into this area, or at least ensuyring that is it keeping up with Breskko and limiting its market dominance. 
- It may be that overall sales may increase as customers may be more focussed on buying printers using a degradable material, it could explain how Bresko had success this year by increasing its market share of sales compared to Kwirtmak. We could actually be falling behind precisely because we haven't been offering and marketing PLA compatible printers, and adopting this approach could help to improve/restore our competitive position. 
- Customers may be wanting to improve the sustainability of their own supply chains, and may just not be aware of PLA materials being more beneficial to the environment. Simply making these products available and marketing them could increase sales and uptake of this technology and minimise the potential for Kwirtmak falling being its competitors on issues of sustainabilkity. 
- The sales volume is driven by the customers, customers who are more sensitive on price can continue to purchase printers that use non-degradable plastics, thus being able to segment the market and satisfy both customers. 
- Reacting quickly to the press release with a firm committment can show to shareholders and to consumers that it is willing to be transparent and respond appropriately to criticisms and be able to pivot to improve its sustainability, thus protecting its image as an entity that cares for the enviuroment. This could limit the impact of the negative news that's going to be published in the article. 
- One of Kwirtmak's stated vision is to promote success in a sustainable manner, and not acting on this information from the article has the potential to generate distrust in Kwirtmak as it could be argued it is not operating under its published values and vision statements, and not considering its impact on the ecosystem for which it depends. 
The drawbacks of the proposal
- The cost of these printers that use PLA (ddegradable palstics) is 25% more expensive currently, this may discourage sales volume as the printers are alrready expensive for consumers, thus leading to lower revenues and overall profit.
- Encouraging the use of degradable plastics could highlight to customers the drawbacks of the current offerings of Kwirtmak with its printers using non-degradable plastics, thus imapcting its brand image in the short-term. There is the potential for negative press releases in this area damaging to Kwirtmak so the strategy and communication should be carefully considered. 
- Marketing costs. 
- The campaign to drive up sales of printers that use PLA in itself may be costly to plan and implement itself with little financial gain to be had, this may aliente current shareholders who believe in maximising revenue at the expense of CSR and the enviroenmtn potentially leading to a lower shareprice and higher cost of capital. 
- The development of a new range of printers is expensive and it is unclear if this is a growth area for the business for financial gain. 
- With share price down and profit margins dowbn, the board cannot risk to venture into a new strategy without clear understanding of the financial impact on the business. The impact on sales abnd profit should be considered before undertaking this challenge. 
- The targets of 50% of sales being PLA compatible printers and within 4 years seems to be arbitrariliy vhosen. why have these specific targets been chosen and would be be detroying value if we aggressively tried to achieve these? Is there a more optimum target? Perhaps the targets may be too harsh or not ambitious enough, these should be explored rather than simply targetting what sounds nice and reasonable. 
Recommendation 

The current sustainability approach of Kwirtmak
- Kwirtmak could highlight the below sustainable practices to show that it is operating in a sustainable manner. 
	- 3D printing has inherent benefits to the environment and its ecosystem
		- Production is conducted close to where the products will be used, lowering transport costs and carbon footprint
		- Unique products in small supply can be created ensuring rapid use and limiting storage space, thus not needing to use storage areas limiting the financial cost or stage and the carbon footprint of these areas. 
		- Kwirtmak currently offers PLA compatible printers, but sales are driven by customers, so it could argue that it simply reflects the tastes of customers rather than simply only offerring good that have potential to cause damage to the enviroment. 
		- As printing is done layer by layer in exact quantities, there is very little material wastage for produciong good via 3D printing compareed to traditional methods that produce waste. 
		- Many plastics used in Kwirtmak's printers can be recycled into new filament 
		- It could be argued that by virtue of the industry that Kwirtmak decided to operate in is helping to contriobute to sustainable manufacturing. 
	- Kwirtmak has integrated sustainability into its highest level of decision mking at the board level, as the operations director has specific oversight of sustainability issues and must report on them at every routine board meeting. 
	- The company allso maintains a dedicated committee, the risk and CSR committee which is specifically tasked with monitoring sustainability issues on behalf of the board. 
	- Kwirkmat also reduced energy costs of its PLA produced good by 32% through technical adjustments to nozzle temperatures and layert thickness, showcasing it's vision and committment to sustainability, as well as cost advantages to the customer./ 
	- There is a demonstrative committment to sustainability with regards to staff as well. All staff are trained in enviuronemnty issues and are empowered to halt operations immediately if they identify serious envuironment concerns such as axcessive emissions. 
	- Collectively, the above demonstrate the committment to sustainability in the way that thje company is managed.
	- Regulatory engagement - close relationshiups with lawmakers and regulatory bodies through its legal department ensures that any health and safety and environmental legislation is adheared to, and Kwirtmak can assist with shaping realistic targets for  regulations helping to achieve sustainability and demonstrating its committment to this area. 


### Practice question core activity B
**B2** - SAF framework, shutting down a plant
Suitability of closing down the site
suitability means the appropriateness of the action taken to shareholders and to the business. 
- It is expected that the other factories will be able to absorb 80% of the capacity that the Wexland factory currently outputs, which can allow it to continue to fulfil the majority of its current orders, thus saving a lot of resources from costs going into the Wexland factory. 
- Closing the facotry now avoid the CapEx due in 2 years. 
- Growth is not expected to increase with Injet printers so diverting resources away from these and icnreasing operational efficiency at other factories could be an excellent proposal to icnrease efficiency and operating profit for the company. 
		- Compared to Breskko, operating costs have not been decreased much at all compared to the loss in revenue for this year, which could suggest that the Kwirtmak is not responding quick enough to control its costs, or has a poor cost cultures. 
		- It may also be that the revenue decreasing is a natural fluctuiation or due to other factors that should be investigated, and shutting down a factory may be in haste. 
- Is the analysis that the other factories being able to fulfil 80% of current output accurate? They may run into other difficulties unforseen as why weren't they already working at the higher capacity? 
- The inkjet printers are still popular with customers although not a growing sector, with only 80% of the current output workload being absorbed by the other factories, there may be issues fulfilling orders with delays thus having a knock-on effect to customers as they wouldn't be able to receive printers in a timely fashion. They may also look elsewhere and look to Breskko who can fulfil orders quicker thus taking more market share awway from Kwirtmak. 
Accepotability
- The proposal to close the factory has huge implications on the workforce in Wexland and is of interest to the Wexlandian government who would liek to retain these jobs considering it may already be under pressure with its high unemployment rate. 
- The closure of the factory could have huge remifications for the local community in Wexland and it would put a significant number of people out of work. 
- The governemnt of Wexland may look unfavourable on Kwirtmak and make it more difficult to trade in the country or put costs and barriers on trade consdiering the decision for Kwirtmak to pull its manufacturing from Wexland. 
- The proposal may be acceptable to shareholders as it would help to reduce its costs in time of low market share of revenue and its depressed share price. The share price and lower operating profit margin could be because it has not reacted quickly enough to market fluctuations and controlling its costs. By closing the factory and making the other factories more efficient, it can save of running and labour costs, thus increasing overall business efficiency and should in theory increase share price which can make shareholders happy. 
- By increasing the share price of the business, Kwirtmak could lower its cost of capital and thus make overall business operations more efficient. This could allow it more freedom to invest resources into growth areas such as printers using advanced materials like carbon fibre. 
- Current factory workers in other areas may lose morale on the news that a factory has been closed in Wexland. They may be fearful of their own jobs, so communication is key to ensure that they are comfortable that their own jobs are safe. 
- It is also important to consider the workload and increased expectations on the factory workers at the other sites, as it could lead to more difficult targets, burnout and frustration among staff now that they have to achieve a higher level of production with little increase in inventives. Perhaps some of the savings should go into rewarding the factory workers outseide of Wexland to mitigate against this. 
- Conclude - does appear to be acceptable, 
Feasibility 
- There may be legislation in Wexland limiting the ability for Kwirtmak to close the factory ojn short notice. They may require proof of the business proposition or may decline 
- The significant workforce currently employeed at the site may require redundancy pay under legislation in Wexland, and this could be very costly for Kwirkmat and disrupt cashflow in the short-term which could pose a risk as it may be limited in investing in other high growth areas with the cash that could have been avaialble.  
- Kwitmak currently has enough cash on-hand however to cover redundancy pay for these payouts if required. 
- Kwirkmat could also generate cash from the sale of the site, assuming that it owns the premises of the factory. 

**Evalluate the power and interesst of the two main stakeholder groups**
Employees at the factory are currently in a high unemployment area so may struggle to find other work and may strongly dfepend on the factory, this could seriously negatively impact their lives and even if not required, it may mitigate the impact to these meployees by offering a settlement or redundancy payout based on their lengths of service to the company.
Current employees at the factory do not appear to have much power individually as a stakeholder as 80% of their output is expected to be absorbed by other factories, although some 20% of output could still see them holding some influence as Kwirtmak wouldn't be able to achieve this extra output without them. The trade-off and impact on the relaible source of revvenue should be quantified and analysed to determine the power of the employees in this area. 
If employees are unionised and they do hear about the decuision to close the factory then they may have significant power to disrupt the supply chain and possibly bring national attention to teh matter thus damaging the trusted brand image of Kwirtmak as being sustainabkle and trusted. This may simply be a short-term cost however should be managed and communication should be managed carefully. Their power appears to low to medium so should simply be kept informed on the process. 
- The government of Wexland may be keen to keep the factory open for the local people as it is currently expereincing high unemployment and possible pressure to get more people into employment, so the closure of the site may come as bad news to them.
- The strength of employment laws should be considered in Wexland as large payouts may be necessary to comply with legislation if Kwirtmak wanted to maintain favourable relations with the government of Wexland. 
- The power of the government is strong as they could retaliate by limiting or putting in barriers to trading and selling in Wexland. As this is a high unemployment country, it could be argued that the sales from Wexland may be low however. This should be quantified and considered before a decision can be made. 
- The government can't insist that the factory stays open however, as they can't force Kwirkmat to continue trading/manufacturing in the country. 

Currency risks and macroeconomic changes
How the board should respond to collapse in CapEx from major industrial customers
- The board should be prepared to focus on the more reliable customers such as healthcare and dental who do not seem to be as impacted on the reudction of CapEx. This shift should take the form of changing what products are produced and the marketing involved. The board should not pivot completely as it should be in a position to fulfil orders for the industrial customers should the market for these products return in short notice. 
- The board should consider the costs involved and ensure that these are monitored and controlled as we've already seen a loss in revenue thjis year without much of a reduction in costs, thus leading to lower operating profit margin. Perhaps the board should consider closing factorys 
- The collapse in capital expensditure will no doubt have an impact on revenue, we do not know what this impact might be however. An analysis should be conducted among the current customer base to determine the magnitude of the imapct, i..e, how many customers currently fall into this category impacted and what is their volume of purchases? 
- The impact analysis can inform what cost and level of cost-cutting measures should be undertaken. 
- Can move to a lease model to bypass the CapEx restrictions, and turn the use of machines into an operating cost for our customers rather than capex. This can ensure we retain sales volume whilst keeping the costs flexible and short-term for our customers which may be more suitable in times of fluctuating interest rates and unvertainty. This will also have the benefit of generating predictable sales and cash flow for Kwirtmak. We shoulld be mindful of our working capital however as we have large upfront costs in manufacturing whilst only receiving a steady stream of revenue from the leases. Our cash would need to be monitored to ensure that it can absorb the pressure now put on the working capital of the business. 
- We can move focus on aggressivley selling materials for use in the printers and more advanced materials, as it is still a business area that we can profit from during the freeze in CapEx. We can also provide maintenance packages to assist customers with their aging printers and ensure these get repaired and possibly improved whilst making a margin on the service. This could be an addiitonal source of revenue not otherwise focused on. 
- We could offer addiitonal hardware retrofitting to customers 
**Evaluate the impact of the appreciating E$ on translation and economic currency risks and recommend whether the board should attempt to mitigate these**
	- The risk of translation currency risk is an issue where financial figures are generated in a foreign currency and then converted to a domestic currency for use in financial statements. This can have the risk of generating paper losses or gains suggesting a loss or gain in value of assets or entities within a portfoilio without any underlying changes in the value of the assets themselves. With the appreciating value of the E$, as group financial statements are prepared and the transactions and balance sheet in consolidated in the domestic currency, it may appear that the current exhange rate show that the revenue and value of assets are lower as the E has been appreciating against the foreign currencies. This has the risk of it appearing that overseas operations are less profitable than they are so judement on these assets should be rushed. 
	- This can be mitigated against by ensuring that each cost and sale is recorded in the E in overseas busienss to help mitigate against transaction risk. Overseas transactions could also be conducted in the E to help avoid this risk altogether if this is possible, although may not be feasible. 
	- The board should attempt to use the strong E to purchase more supplies for use in its printers, and the cost-saving be analysed and comapred to storage costs as there may be a way to capitalise on the temporary strong E and shore-up inventory, although overinvestment in inventory is a risk identified in the risk register so this should be considered carefully. 
	- Domestic borrowing doesn't appear to be impacted, so if E has any foreign loans, it could help to convert some E into the foregn currencies to make better use of the arbitrage and cut its liabilities. 
	- There is the issue with an appreciating E as it makes the products of Kwirtmak more costly and less attractive to overseas buyers. 
	- **Impact of the appreciating E$ on currency risks The global disparity in interest rates, with Ennland's rates remaining relatively stable while foreign rates rise, has caused a 15% appreciation of the E$ against a basket of currencies in the countries where we operate. As a business with our head office and largest factory in Ennland, but with three factories located overseas and a global export market, this currency shift presents two distinct risks: translation risk and economic risk. Translation Risk Translation risk is an accounting exposure. It occurs when a multinational co**mpany has assets, liabilities, or subsidiary profits denominated in foreign currencies. At the end of each financial year, these foreign balances must be translated back into the parent company’s home currency (the E$) to prepare the consolidated financial statements. Because the E$ has strengthened by 15%, the local currencies where Kwirtmak’s three overseas factories are situated have effectively weakened. When we translate the value of the net assets of those foreign subsidiaries and their retained profits back into E$, they will equal a significantly lower value. This will result in an unrealised accounting loss on consolidation, reducing the reported group equity. Kwirtmak is already experiencing this pressure; in the consolidated statement of changes in equity for the year ended 31 March 2026, we recorded a currency loss of E$ 44.3 million within our Currency reserve. Given the recent 15% appreciation of the E$, we should expect a substantially larger unrealised loss in the upcoming financial year. Recommendation on mitigation The Board could theoretically mitigate this translation risk by employing a strategy of matching foreign assets with foreign liabilities. If we were to fund our three overseas factories using debt denominated in their respective local currencies, the risk would be hedged. Any translation loss on the value of the factory assets would be perfectly offset by a translation gain on the foreign liabilities, as the foreign debt would become cheaper to repay when translated into the stronger E$. However, I recommend that the Board does not attempt to actively mitigate this translation risk. Translation exposure is purely a non-cash, unrealised accounting adjustment; it does not directly impact our daily cash flows. Attempting to hedge this Chapter 5 62 using real cash, for instance, by purchasing costly forward foreign exchange contracts, would be an inefficient use of funds. Also, the administrative and financial costs of restructuring our current E$ 1,350 million in long-term borrowings into foreign-denominated debt are not commercially justifiable. Instead, we should proactively manage investor relations, using our annual report narratives to transparently explain to shareholders that the reduction in group equity is driven by macroeconomic translation mechanics, rather than poor operational performance. Economic Risk Economic currency risk refers to the long-term impact of exchange rate movements on the present value of a company's future cash flows and its overall global competitiveness. Unlike transaction risk, which deals with short-term, specific invoices, economic risk is a strategic issue. The appreciating E$ is a severe economic threat to Kwirtmak. A significant portion of our manufacturing, R&D, and administrative cost base is based at our head office and largest factory in Ennland, meaning these costs are incurred in the strong E$. However, we generate global sales, with a large amount paid for in depreciating local currencies. Consequently, our 3D printers and materials have become considerably more expensive for our foreign buyers. We face a tricky commercial decision. If we maintain our current E$ pricing, our exports will become uncompetitive, exacerbating the CapEx freeze and accelerating our loss of market share. While our closest rival, Breskko, is also based in Ennland and likely faces similar E$ cost pressures, we will become highly vulnerable to local competitors situated in weaker-currency jurisdictions who can aggressively undercut us. Alternatively, if we discount our local prices in foreign markets to remain competitive and protect sales volumes, we will severely reduce our already falling operating profit margins, which currently is 50.6%, down from 56.4% in 2025. On a more positive note, Kwirtmak relies heavily on third-party suppliers for materials and parts. A strong E$ means that importing these raw materials from overseas suddenly becomes cheaper, which will lower our material costs and provide a natural, partial offset to the margin decline caused by pricing pressures. Recommendation on mitigation The Board should take immediate action to mitigate economic risk. However, because economic risk represents a long-term shift in global pricing dynamics, it is very difficult to hedge using standard financial derivatives. The Treasury Department cannot simply purchase forwards or futures to hedge our entire global position indefinitely. Therefore, we must rely on operational hedging and strategic, valuebased pricing. Core Activity B 63 Firstly, we must utilise operational hedging by leveraging our existing global footprint. Kwirtmak operates three factories overseas. The Operations Director should explore shifting a greater proportion of our manufacturing and raw material sourcing away from Ennland and towards these three foreign locations. By incurring our manufacturing costs (such as local labour, rent, and materials) in the same weaker foreign currencies that our customers are paying with, we create a natural hedge. This helps aligns our cost base with our revenue base, protecting profit margins. Secondly, we must adopt a strategy of value-based pricing rather than discounting. Engaging in a price war will permanently damage our premium brand equity. Kwirtmak has a strong reputation for high-quality products, complex printing capabilities (such as laser melting and material jetting technologies), and excellent technical advice. Instead of competing on the initial purchase price, our Marketing Director should change our messaging to emphasise the long-term value and lower "total cost of ownership" of our machines. By heavily promoting sustainability metrics—such as the 32% reduction in energy consumption for PLA printing, or the reduced material waste inherent in our additive manufacturing processes, we can justify to foreign buyers that Kwirtmak machines are ultimately cheaper to run over their lifespan. This will allow us to maintain our premium E$ pricing globally, defending our operating profit margins despite the hostile exchange rate environment.


# Online class 2
Share price -> link to business valuation 
business valuation
Net assets
dividends, earnings based

5 risks -> also think about upside risk

Recommend responses to sustainability issues -> brand new topic, mostly like to come up



---- 
[[SCS Mock Exam D]]


3. 