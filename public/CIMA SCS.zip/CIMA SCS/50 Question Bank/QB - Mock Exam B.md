# QB — Mock Exam B (Kaplan, May/Aug 2026)

Scenario arc: CTO Dr Said Abouchdak proposes a dedicated **R&D Centre of Excellence in Northland** (neighbouring developing economy, N$) → site selection (Eastville vs Westville) and N$ funding question → a politician demands E$50m university funding to release building permission (bribery/ethics + internal audit). All three task requests come from Agata Paluch (CFO); you are the Senior Finance Manager.

| Core activity | A | B | C | D | E | Total |
|---|---|---|---|---|---|---|
| Task 1 | 20 | 13 | | | | 33 |
| Task 2 | | 13 | 20 | | | 33 |
| Task 3 | | | | 17 | 17 | 34 |
| **Total** | **20** | **26** | **20** | **17** | **17** | **100** |

---

## Task 1a — Centre of Excellence vs mission/vision/values (~36 min · 20 marks · Core Activity A)

**Trigger:** Board minute attached. Dr Said Abouchdak (CTO) argues that cutting R&D spend over the last 12 months was a mistake and partly caused the low share price. He proposes a new facility wholly dedicated to R&D — a "Centre of Excellence" — in neighbouring Northland, recruiting the best engineers and citing new 3D printing opportunities in healthcare and sports.

**Requirement:** *"Firstly, evaluate the argument that establishing a Centre of Excellence for Research & Development (R&D) in Northland would be consistent with Kwirtmak's mission, vision and values."* (sub-task a = 60%)

> [!question]- Reveal answer plan
> **Framework:** Mission / Vision / Values (MVV) analysis — each statement dissected phrase by phrase; each of the 5 values in turn. No other framework. Marking: Mission trait max 7, Vision trait max 7, Values trait max 6; L3 = "Evaluates argument with consistency" (explicitly link back to consistency with the statement).
>
> **Plan:**
> *Mission — "to transform its customers through innovation in design and production":*
> - R&D-dedicated centre consistent with mission — Kwirtmak is a tech company in a fast-paced, constantly changing industry — what customers want today will differ greatly from what 3D-printing customers want in the near future.
> - "Transform its customers" could mean Kwirtmak *shapes* what customers want; perceived needs adapt once customers see what Kwirtmak can offer — if R&D creates printers with much greater capability than rivals such as Breskko, Kwirtmak could shape the whole 3D printer market — "very much in line" with the mission.
> - "Innovation" implies giving customers *unique* offerings — only achievable through concentrated R&D effort — committing investment is consistent with the mission.
>
> *Vision — "to be the leading provider of additive manufacturing solutions across industries, to be achieved in a sustainable manner":*
> - "Leading provider" = market leader (highest revenues) — Kwirtmak is currently NOT achieving its vision: 2026 revenue 18.8% lower than prior year and Breskko overtook Kwirtmak in reported sales.
> - Committed R&D spend consistent with restoring the vision — customers have recently chosen competitors' products; new products (improvements on existing designs, or new areas such as new input materials) would restore revenue growth — a dedicated centre is a *public commitment* to higher, more targeted R&D spend.
> - "In a sustainable manner" — two interpretations: (1) next-gen printers more sustainable in how they function (customer benefit), or (2) Kwirtmak's own operations become more sustainable — either way all parties benefit: customers enhance their own sustainability credentials; Kwirtmak differentiates as the leading 3D manufacturer on sustainability of operations.
> - Interim conclusion: "The proposal is therefore entirely consistent with the sense of vision."
>
> *Values — all 5 in turn:*
> - "Kwirtmak creates wealth and success" — benefits multiple stakeholders, not just shareholders: employees (job security if company grows), customers (machines better meeting needs → improved output and presumably profits), suppliers (greater sales volumes); for shareholders wealth = higher profits and rising equity value — short-term wealth may actually *decrease* due to investment costs, but this is a strategic, long-term proposal — consistent.
> - "Innovations are driven by customer need" — fully consistent ONLY IF the research keeps customer needs at its core — always possible to innovate ever more sophisticated products, but if characteristics aren't ones customers actually want, the spend has little value (caveat).
> - "Overdelivers on its promises to customers" — open to interpretation (delivering new product quicker than expected; functionality the customer wasn't anticipating or didn't know they could use) — the centre has the *potential* to be consistent, but must keep focus on what customers actually want.
> - "Trusts its staff" + "staff are team players" (together) — the Centre is just a new division within the Group with the same staff expectations as everywhere else — consistent "but not in any new or unique way" (honest, nuanced evaluation).
>
> **Conclusion/recommendation:** Proposal is consistent with stated mission, vision and values "and is recommended for further Board discussion."
>
> **L3 hooks (facts/numbers to cite):** mission/vision/values quoted verbatim, 2026 revenue 18.8% lower than prior year, Breskko overtook Kwirtmak in reported sales, low share price, R&D spend cut over last 12 months, fast-paced 3D printing industry, healthcare and sports opportunities

## Task 1b — Political risk impact of the R&D Centre (~24 min · 13 marks · Core Activity B)

**Trigger:** Same board minute: the proposed Centre would sit in Northland, a developing economy keen on inward investment, with two strong Engineering universities, the same time zone as Ennland, a government with low approval ratings and an election due the year after next.

**Requirement:** *"Secondly, evaluate the impact that the R&D Centre would have on the political risks associated with operating in Northland."* (sub-task b = 40%)

> [!question]- Reveal answer plan
> **Framework:** Political risk categories — government change/policy risk, expropriation/ownership risk, forced technology transfer, mitigation via corporate citizenship, cross-border/transfer risk. Structured as 4 headed impacts (marking grid rewards 3: 5+4+4); L3 = "Evaluates impact with justification."
>
> **Plan:**
> - **Potential government change** — current government has low approval and an election is due the year after next — Kwirtmak negotiates/invests under one regime but likely opens and operates under another; current government is keen to attract FDI (possible state support to fund construction) BUT an incoming populist/protectionist opposition might view state grants as an "unfair corporate handout" — risks: aggressive policy reversals, retrospective taxation, demands to repay funding.
> - **Vulnerability of physical and intellectual assets** — the best engineers working on products/materials at the industry forefront (incl. lucrative healthcare and sports 3D printing) means highly valuable proprietary IP sits in a developing economy — an *ownership risk*: weaker legal protections for foreign firms; a future struggling government could expropriate physical assets; more importantly for a tech firm, mandate *forced technology transfers* — sharing cutting-edge software/hardware designs with domestic Northlandian companies as a mandatory "cost of doing business".
> - **Mitigation through strategic 'good corporate citizenship'** (counter-argument — the centre could REDUCE the risk profile) — Northland has two universities with excellent Engineering reputations; working with them and providing highly skilled, well-paid jobs for local graduates embeds Kwirtmak in the local/national economy; several tech companies are already establishing facilities in Northland so Kwirtmak joins a broader modernisation trend; the current government would heavily publicise the investment to boost poor approval; even a new, less business-friendly government would be unlikely to disrupt a facility visibly championing local education, preventing engineer "brain drain" and creating domestic wealth.
> - **Proximity, time zones and cross-border operations** — Northland neighbours Ennland and shares its time zone — excellent for real-time collaboration with head office — but the physical border brings distinct political risks: if the election creates civil unrest, diplomatic disputes or stricter border controls, key personnel, sensitive raw materials or newly developed 3D printer prototypes could be blocked from moving freely — effectively isolating the R&D centre and halting innovation.
>
> **Conclusion/recommendation:** Balanced evaluation — the Centre raises some political risks (regime change, IP/expropriation, border exposure) but can actively reduce the risk profile via good corporate citizenship.
>
> **L3 hooks (facts/numbers to cite):** low government approval ratings, election due year after next, developing economy keen on inward investment, two universities with strong Engineering faculties, same time zone as Ennland, tech companies already establishing facilities there, healthcare and sports 3D printing

---

## Task 2a — Stakeholder power & interest (~24 min · 13 marks · Core Activity B)

**Trigger:** One month later. Kristina Eder (Operations Director) has researched two sites: Eastville (affluent, near larger university and second-largest city, near a technology park, derelict buildings need demolition) and Westville (economic blackspot, high unemployment, 230 miles from Head Office near the Ennland border, regional airport with flights to Capital City, undeveloped land — construction can start immediately). The Northland Chambers of Commerce rep said grants may be available for Westville only, and hinted planning goes more smoothly if investors raise funds in local currency (N$). Estimated cost: E$800m.

**Requirement:** *"Firstly, evaluate the power and interest of the three main stakeholder groups who will be affected by the new R&D Centre of Excellence's location and design, as discussed in Kristina's email."* (sub-task a = 40%)

> [!question]- Reveal answer plan
> **Framework:** Mendelow's power/interest matrix (implicit — high/low interest, high/low power, "key player", "keep informed" language without naming Mendelow). Marking: 3 stakeholders (5+4+4); L3 = "Discusses stakeholder impact on decisions with justification."
>
> **Plan:**
> *Northland Chambers of Commerce:*
> - Framing: the Chambers are effectively the trade representatives of the Northland government — the analysis applies just as well to the government itself.
> - Interest = HIGH — inward investment benefits the local economy financially at local and national level; Chambers exist to promote business interests; more employers = more jobs for local people; indirect employment benefit via increased supply chains.
> - Power = HIGH — they can offer grant assistance towards investment costs if Kwirtmak chooses Westville, an economic blackspot — investing there reduces local unemployment and improves living standards; if other international companies see Kwirtmak invest successfully in Westville they may follow, further boosting the local economy.
> - Classification: **key player** — Kwirtmak should *engage* with this stakeholder over precisely where to locate the Centre.
>
> *Potential employees:*
> - Interest = HIGH in both locations (chance of employment with a global technology organisation; income plus career and significant advancement, in Northland and beyond) — but interest differs by location: HIGHER in Westville than Eastville — Westville is an economic blackspot with high unemployment so desire/competition for positions will be intense; Eastville already has high employment, good living standards and a technology park, so unsuccessful applicants can find other local jobs.
> - Power = LOW in both locations — no collective power (unlike an existing unionised workforce); they are *potential* not current employees, so no bargaining power when applying.
> - Classification: **keep informed** (about job vacancies) but they will not determine Kwirtmak's investment strategy.
>
> *Universities:*
> - Interest = HIGH — a new employer improves graduate employment prospects, making degrees more attractive to prospective students; a new tech company also makes introducing new courses more attractive (university and employer aims aligned: graduates with the right job-market skills); potential for greater applied research — collaboration with 3D printer manufacturers can advance technology via sharing talent and knowledge.
> - Power = MEDIUM-TO-LOW — the final location decision depends on many factors, not just the presence of local institutions.
> - Classification: keep informed of developments in Kwirtmak's thinking, but not allowed to influence it to a great degree.
>
> **Conclusion/recommendation:** Classify and set an engagement strategy per stakeholder: engage the Chambers (key player); keep potential employees and universities informed.
>
> **Kaplan tutorial note (verbatim):** "the question asked for an evaluation of the 3 main stakeholders but without defining who they were. It is therefore possible to choose other stakeholders that are deemed relevant to the decision on where to locate the new centre." — where a question leaves categories undefined, any sensible, justified selection scores.
>
> **L3 hooks (facts/numbers to cite):** Westville "economic blackspot" with high unemployment, grants for Westville only, Eastville affluent with technology park and larger university, 230 miles from Head Office, regional airport with regular flights to Capital City, E$800m estimated cost, Kwirtmak = global technology organisation

## Task 2b — Borrowing E$800m in N$ from a Northlandian bank (~36 min · 20 marks · Core Activity C)

**Trigger:** Same email from Kristina. The Chambers of Commerce rep hinted that planning goes more smoothly when investors raise funds in local currency (N$). The Centre's estimated cost is E$800m ("based on the cost of our most recent factory"). The CFO wants the funding route evaluated.

**Requirement:** *"Secondly, evaluate the arguments for and against funding the cost of building the Centre of Excellence by borrowing the required E$800 million in N$ from a Northlandian bank."* (sub-task b = 60%)

> [!question]- Reveal answer plan
> **Framework:** Debt-financing evaluation (cost of debt, security, tax shield); currency/economic risk (transaction/economic FX exposure of a foreign-currency loan); International Fisher Effect (cited then critiqued); debt covenants; political risk mitigation via local financing. Marking: 4 arguments (5 marks each); L3 = "Evaluates argument with justification."
>
> **Plan:**
> *Advantages:*
> - **Local support** — the Chambers rep explicitly hinted planning goes much more smoothly when funds are raised in N$ — borrowing locally likely makes local and national government more supportive, easing planning permission and building permits; whichever site is chosen (Eastville needs derelict buildings demolished; Westville can start immediately), rapid planning permission is critical; raising E$800m through Northland's domestic financial system injects capital into their local market — significant goodwill with authorities and regulators, potentially accelerating project timelines.
> - **Debt security and the cost of debt** — E$800m is a large capital outlay; a Northlandian bank is more likely to accept the physical R&D facility and underlying land as loan security — an Ennlandian bank would view foreign property in a developing economy as riskier security (legal complexities of cross-border foreclosure) and charge a higher interest rate. Debt is also fundamentally cheaper than equity; interest on the N$ loan is tax-deductible — if Kwirtmak generates taxable profits in Northland, interest acts as a valuable tax shield reducing local tax liabilities — more valuable the higher the tax rate; compare tax rates in Northland vs Ennland and other countries of operation.
> - **Political protection** — the current government has low approval and an election is coming — borrowing E$800m from a domestic Northlandian bank "effectively recruits that bank as a powerful political ally": if a new, less business-friendly government attempts to expropriate the facility or impose punitive retrospective taxes, Kwirtmak could threaten to default on the large N$ loan; to protect itself from a significant write-off the bank would likely lobby the government on Kwirtmak's behalf — a layer of protection against extreme government action.
>
> *Disadvantages:*
> - **FX risk — flagged as "the most significant disadvantage"** — an R&D centre is mainly a *cost centre*: it will not generate local N$ sales revenues, so Kwirtmak must continuously convert E$ (or other currencies) into N$ to fund the centre and service interest and principal — if the N$ strengthens significantly against the E$, the true cost of servicing the loan reduces Kwirtmak's profitability — partially offset if Kwirtmak later makes sales in Northland. Theory caveat: the International Fisher Effect suggests higher interest rates are eventually offset by currency depreciation, but "relying on this theory in a developing economy is incredibly dangerous" — emerging-market currencies can experience sudden, violent volatility that theoretical models fail to predict.
> - **Debt covenants** — because Northland is a developing economy with upcoming political uncertainty, a local bank lending such a large sum will likely impose strict covenants to protect itself — e.g. restricting Kwirtmak's ability to pay dividends, or requiring high levels of local liquidity — restricting Kwirtmak's *global* financial flexibility.
>
> **Conclusion/recommendation:** Balanced for/against — name which disadvantage is "the most significant" (FX exposure of a cost centre with no natural hedge) and why.
>
> **L3 hooks (facts/numbers to cite):** E$800m ("based on the cost of our most recent factory"), N$ local currency, Chambers rep's hint on N$ funding, Eastville derelict buildings vs Westville immediate start, developing economy, upcoming election, low government approval, International Fisher Effect

---

## Task 3a — Ethics of funding the university department (~30 min · 17 marks · Core Activity D)

**Trigger:** Six months later. Kwirtmak bought land in Eastville (building permission was obtained *before* purchase), but construction can't start: a prominent Northlandian politician has ordered officials to withdraw building permission unless Kwirtmak funds a new E$50m Technology & Design Department at the local University. Embassy staff advise the politician is not seeking personal gain (he wants to enhance the University's international reputation), but warn bribe requests are relatively common for foreign companies in Northland, that bribery is illegal and should be refused — though refusal can delay the project. Budgeted Centre cost: E$800m.

**Requirement:** *"Firstly, evaluate the ethical implications of Kwirtmak agreeing to fund the new Department at Eastville University."* (sub-task a = 50%)

> [!question]- Reveal answer plan
> **Framework:** CIMA Code of Ethics — fundamental principles (Integrity, Objectivity, Professional Behaviour, Confidentiality/transparency, Professional Competence implied) mapped against threats (Self-Interest, Advocacy, Self-Review) + Public Interest duty + UK Bribery Act as legal benchmark. Each header pairs a principle with a threat. Marking: 4 implications (5+4+4+4); L1 = "Identifies principle", L3 = "Evaluates implication in relation to principle with justification" — marks hang off *naming the principle* then applying it.
>
> **Plan:**
> - **Overall framing** — the E$50m demand as a condition for building permission is a significant ethical challenge threatening core values — even though the Embassy suggests the politician seeks *social* benefit not personal gain, this is a clear "quid pro quo" threatening **Integrity** — it forces Kwirtmak to knowingly bypass official legal channels to "buy" a permit that was *already legally granted*.
> - **Integrity and Self-Interest threat** — be highly sceptical of the politician's motives; under the CIMA Code this creates a significant Self-Interest threat to the Board's reputation — participating in a corrupt process "even for a good cause" directly contradicts the company's value of being a "Trusted Provider".
> - **Objectivity and the Advocacy threat** — the politician's "coercion" (ordering officials to withdraw existing permissions) creates a significant Advocacy threat compromising Objectivity — Kwirtmak is pressured to fund and "promote" a third-party university project (essentially a political vanity goal) simply to secure a commercial permit already legally its own — professional judgment is no longer neutral or based on R&D requirements; the E$50m spend becomes political appeasement rather than a choice in shareholders' best financial interests — sets a dangerous precedent: future strategic decisions in Northland clouded by political pressure rather than objective business logic, undermining long-term reliability.
> - **Professional Behaviour and legal risk** — Kwirtmak must comply with the strictest laws, "notably the UK Bribery Act standard or similar" — under such legislation the "social" nature of the payment is irrelevant; the *intent to influence a public official to gain a commercial advantage* is a corporate offence — hiding a E$50m "donation" within the E$800m construction budget would be a *secondary breach*: misrepresenting financial data to auditors and investors.
> - **Confidentiality and Transparency** — ethical duty to be transparent with shareholders — any such payment would need disclosure as a separate line item, which would draw negative attention and damage the "Precision" promised to investors.
> - **Internal Oversight — Self-Review threat** — if the Board bypasses official legal channels now to "solve" the permit issue, Internal Audit can never objectively review the project's financial integrity later — "the Board would be auditing a process they knowingly compromised."
> - **Public Interest duty and shareholder impact** — duty to uphold the rule of law; succumbing would leave a permanent "stain" on the brand and could further depress the already-low share price — long-term damage to reputation and investor trust "would far outweigh the temporary strategic benefits of the new R&D facility."
>
> **Conclusion/recommendation:** Refuse the payment — it is bribery regardless of motive; long-term reputational and legal damage outweighs the short-term strategic benefit of the Centre.
>
> **CAUTION:** This Kaplan model answer cites the values "Trusted Provider" and "Precision" — these do NOT match the five values quoted verbatim in the Task 1 answer (apparent Kaplan drafting inconsistency). In the real exam, cite the actual pre-seen values.
>
> **L3 hooks (facts/numbers to cite):** E$50m demand, E$800m Centre budget, permission obtained *before* land purchase then withdrawn, Embassy advice (no personal gain; bribe requests common; bribery illegal — refuse but expect delay), UK Bribery Act, "quid pro quo", already-low share price

## Task 3b — Internal Audit work on possible bribery (~30 min · 17 marks · Core Activity E)

**Trigger:** Same scenario: given the Embassy's warning that bribe requests are common in Northland and a senior manager is based there to supervise building operations on the E$800m project, the CFO wants to know what Internal Audit could do to establish whether bribes are being paid.

**Requirement:** *"Secondly, recommend, with reasons, the work that Kwirtmak's Internal Audit Department could undertake in order to establish whether bribes are being paid to facilitate the construction of the Centre of Excellence."* (sub-task b = 50%)

> [!question]- Reveal answer plan
> **Framework:** Internal audit methodology sequence — risk assessment/control environment → substantive/forensic testing → data analytics → whistleblowing → reporting line to Audit Committee (anti-bribery audit programme). Marking: 4 recommendations (5+4+4+4); L3 = "Recommends work with reasons and justification."
>
> **Plan:**
> - **1. Risk assessment and internal control review** — before substantive testing, IA should perform a high-level risk assessment of Northlandian operations — review the "tone at the top" and control environment established by the Northland-based senior manager; evaluate whether corporate anti-bribery policies have been clearly communicated to local staff and contractors — a weak control environment or lack of local oversight significantly increases the inherent risk of bribery, requiring more extensive sample testing of transactions.
> - **2. Forensic review of third-party intermediaries** — comprehensively review all payments to "associated persons" (local Northlandian consultants, legal advisors, planning agents) — in high-risk jurisdictions bribes are frequently disguised as "success fees" or "consultancy charges" paid to intermediaries claiming to facilitate government relations or "smooth over" planning — verify third parties underwent rigorous due diligence, a valid contract exists for their services, and fees are commensurate with actual work performed.
> - **3. Physical-to-financial reconciliation of construction costs** — with a E$800m budget there is a risk funds are diverted to fund illicit payments — conduct on-site visits to Eastville to reconcile physical building progress against contractor invoices — this "substantive testing" identifies "ghost employees" or "inflated material costs" used to generate cash for bribes — verifying materials and labour paid for are actually on site assures the budget is used for its intended purpose.
> - **4. Audit of facilitation payments and local expenditure** — detailed testing of the senior manager's local accounts and petty cash records in Northland — although Embassy staff warned bribery is common, small "facilitation payments" to low-level officials (utility connections, customs clearance) are prohibited under home-country legislation such as the UK Bribery Act — ensure all local expenditure is supported by official, government-stamped receipts and investigate "sundry"/"miscellaneous" expenses lacking documentation.
> - **5. Data analytics and trend analysis** — apply data analytics to the E$800m project budget — look for patterns of "round sum" payments, duplicate invoices, or payments made just below the senior manager's authorisation limit.
> - **6. Whistleblowing channel effectiveness** — verify the confidential whistleblowing hotline is accessible and effectively communicated to Northland-based employees and contractors — conduct confidential interviews with local staff to determine whether there has been pressure to make improper payments — a vital "early warning system" for reporting unethical behaviour or extortion attempts by local politicians without fear of retaliation.
>
> **Conclusion/recommendation:** Findings must be reported directly to the **Audit Committee** — ensures the Board is fully aware of the ethical and legal risks in Northland, allowing a strategic response if bribery is identified.
>
> **L3 hooks (facts/numbers to cite):** E$800m project budget, senior manager based in Northland supervising building operations, Embassy warning that bribe requests are common, UK Bribery Act (facilitation payments prohibited), Eastville site, authorisation limits, whistleblowing hotline

---

## Technique takeaways from this mock

- **Format:** Tasks 1 and 2 are emails (To/From/Subject block, opening line restating the request: "As requested, this email will evaluate…"). Task 3 responds to a verbal request but is still an email with headed sections. Always mirror the format asked for in the trigger.
- **Signposted structure:** one bold header per sub-task, then sub-headers naming each framework element (Mission/Vision/Values; Advantages/Disadvantages; principle-plus-threat pairings; numbered IA recommendations). Grids are trait-based — discrete, clearly-labelled points map directly onto traits.
- **Depth over breadth:** up to 5 marks per point at Level 3 ("with justification"). 3–4 *developed* points per sub-task beat many shallow ones. Justification = tying the claim to a specific pre-seen number, quote or scenario fact (18.8% revenue fall, Breskko overtaking, E$800m, "economic blackspot", "quid pro quo").
- **Quote the source material:** the answers repeatedly quote the mission/vision/values verbatim and quote scenario phrases in inverted commas — visibly anchoring evaluation to the case.
- **Balanced evaluation:** every sub-task shows both sides — even the "consistency" question flags caveats ("consistent ONLY IF customer needs stay at the core"; "consistent but not in any new or unique way"), and the political-risk answer includes a risk-*reducing* impact (good corporate citizenship). "However…" pivots appear in nearly every section.
- **Conclusions/recommendations:** Task 1a ends with an explicit Conclusion header and recommendation ("recommended for further Board discussion"); the Mendelow answer ends each stakeholder with a strategy classification (engage / keep informed); recommendations are specific and actioned ("delay", "engage", "report to the Audit Committee").
- **Time/weight discipline:** sub-task weightings (60/40, 40/60, 50/50) dictate word count and mark allocation — the longer answer always sits with the higher weighting.
- **Ethics answers:** always name the CIMA fundamental principle AND the threat category, then apply to the facts, then give the consequence (legal, reputational, share price). Level 1 is just naming the principle — the marks are in application.
- **Open stakeholder selection:** Kaplan's tutorial note confirms stakeholder selection was open — where a question leaves categories undefined, any sensible, justified selection scores.
- **Level descriptor ladder (all traits):** L1 identify → L2 evaluate/discuss/explain → L3 evaluate with justification. Never leave a point at identification.
