# QB — Mock Exam C (Kaplan, May 2026)

Kwirtmak mock: 3 sections × 1 task × 60 min. Storyline — EHS medical 3D-printing opportunity (E$2bn sterile facility, E$10bn market), press-release/share-price and interest-rate risk, then a governance breach (unauthorised E$400m contract) and an ethics breach (withheld prototype failures from the EHS).
Core-activity mark split:

| | A | B | C | D | E | Total |
|---|---|---|---|---|---|---|
| Task 1 | 20 | 13 | | | | 33 |
| Task 2 | | 13 | 20 | | | 33 |
| Task 3 | | | | 17 | 17 | 34 |
| **Total** | 20 | 26 | 20 | 17 | 17 | 100 |

---

## Task 1a — Evaluate investment in new medical production facility (~36 min · 20 marks · Core Activity A)

**Trigger:** Email from CEO Dr David Wallace with Board minutes. NE Chair Madda Fedele learned from the Ennland Minister for Health that the EHS will approve new 3D printing applications within 12 months (patient-specific surgical guides, 1:1 organ replicas for surgical rehearsal, patient-matched implants). Entry requires a new fully sterile dedicated facility costing up to E$2bn taking 18 months to build; domestic suppliers get preference; the Ennland medical 3D printer market could be worth E$10bn in 5 years. Fedele urges investing ASAP for first-mover advantage; CFO Agata Paluch worries about metrics/KPIs for a high-risk investment.

**Requirement:** *"Firstly, evaluate the arguments for and against investing in a new production facility in Ennland, dedicated wholly to making 3D printers for the medical profession."* (Email in response to Dr David Wallace's requests.)

> [!question]- Reveal answer plan
> **Framework:** Arguments for/against (balanced evaluation); alignment with mission & vision; strategic fit with competences (implicit suitability/feasibility of SAF); risk framing (systematic risk/beta).
>
> **Plan:**
>
> *Arguments FOR:*
> - Market growth and scale — projected E$10bn Ennland medical market in 5 years vs Kwirtmak's total 2026 Group revenue of E$2.32bn, so this single sector could dwarf current operations — no exclusivity expected, but significant chance to enhance revenues, margins and share price; shareholders want reassurance the Board can restore growth in company value.
> - First-mover advantage — investing immediately establishes the brand and secures EHS approvals early, creating barriers to entry for rivals like Breskko — all rivals face the same 18-month sterile-facility build for EHS approval, so the sooner Kwirtmak starts, the greater the chance of entering first (revenues not enjoyed until ~18 months regardless).
> - Ennland location / government preference — Minister indicated local suppliers more likely to win approval as they contribute to the local economy — stable, long-term government-backed health contract revenues; leverage Board members' government links: Madda Fedele (ex-government administrator, already proved her value with this tip-off) and Dr Ada Rothenberg (three government advisory committees) — experience of "the movements of government" aids winning healthcare contracts.
> - Mission and vision alignment — mission "to transform customers through innovation in design and production" and vision "to be the leading provider of additive manufacturing solutions across industries" — medical-sector buyers (government and private) are the "customers" of the mission; being first to market fits the vision.
> - Fit with existing skill set — existing reputation for precision and technical advice is a natural fit for surgical guides and implants requiring sub-millimetre accuracy — even though the new dedicated factory differs significantly from the four existing facilities, staff already have the skills, reducing the risk of strategic failure.
>
> *Arguments AGAINST:*
> - Massive financial exposure — up to E$2bn cost vs total assets of only E$3.79bn and E$1.35bn non-current borrowings already carried — new capital needed and the current share price makes debt more probable than equity → risk of over-leveraging / too-high gearing; a full financial appraisal must precede any final decision.
> - Execution and lead-time risk — 18-month build means a long period of cash outflows before any revenue; market conditions or medical technology could shift in the window (new machine designs or raw materials before/soon after launch). Counter: true of any 3D printer application, so not itself a reason not to proceed — the Board should monitor market developments and adapt designs/plans.
> - Specialised operational requirements — a "fully sterile" environment is a new competency — higher operating costs and regulatory non-compliance risk causing "mission-critical failures"; time needed to understand legislation and train staff; compliance is a critical success factor — a hygiene failure could irreparably damage reputation before a decent return is generated. Counter: Kwirtmak already operates in mission-critical areas (e.g. aerospace), so it has experience identifying and acquiring required skills, even if not sterile-manufacturing expertise itself.
> - Recent performance trends — revenue fell from E$2.86bn (2025) to E$2.32bn (2026) with declining profits — committing to a high-risk venture during declining performance may be viewed negatively by the stock market if announced badly → employ PR experts to draft the Stock Exchange and Press announcement to maximise favourable market reaction.
> - High systematic risk — beta already 2.3, indicating high sensitivity to market movements — this massive investment will likely increase the risk profile further, especially before returns become visible → phrase any decision to invest extremely carefully.
>
> **Conclusion/recommendation:** Balanced evaluation; always close with "a full financial appraisal will need to be conducted before any final decision".
>
> **L3 hooks (facts/numbers to cite):** E$10bn market in 5 years, E$2bn cost, 18-month build, 2026 revenue E$2.32bn (2025: E$2.86bn), total assets E$3.79bn, borrowings E$1.35bn, beta 2.3, mission/vision quotes, Fedele's and Rothenberg's government links, Breskko as rival, aerospace mission-critical experience, four existing facilities.

## Task 1b — Recommend KPIs for the new facility (~24 min · 13 marks · Core Activity B)

**Trigger:** Same email — CFO Agata Paluch is concerned about how a high-risk investment of this scale would be monitored, so the CEO also wants suggested performance metrics for the proposed medical facility.

**Requirement:** *"Secondly, recommend, with reasons, the Key Performance Indicators that should be adopted for the new production facility."*

> [!question]- Reveal answer plan
> **Framework:** Balanced Scorecard — 2 KPIs under each of the 4 perspectives, "as a means of providing a broad perspective", monitoring not only the immediate financial risks but also operational and regulatory requirements. (Examiner: framework not mandatory, but it "can add breadth".)
>
> **Plan:**
>
> *Financial:*
> - ROCE per project — given the E$2bn outlay, returns must exceed the cost of capital — finance costs are already E$108m; revenue growth interests shareholders but revenues must be turned into profits.
> - Net profit margin by product line — medical printers need higher specifications to be fit for purpose — prices on these superior machines must offset the sterile facility's high operating costs.
>
> *Customer:*
> - Market share in the Ennland health sector — monitors success capturing the projected E$10bn market and leveraging first-mover status — also indicates ability to meet healthcare customers' needs and hence chances of expanding into healthcare in other countries.
> - Customer retention / repeat purchase rate — Kwirtmak relies on selling both printers AND compatible materials — tracking retention ensures medical customers stay within the Kwirtmak ecosystem.
>
> *Internal business process:*
> - Sterility compliance pass rate — proportion of items meeting stringent quality requirements — facility must be "fully sterile"; a rigorous metric for 100% compliance with health standards avoids "mission-critical failures".
> - Manufacturing lead time (CAD-to-print) — the medical sector values speed for urgent treatments — tracks efficiency converting medical scans into physical parts.
>
> *Learning and growth:*
> - Average time to EHS certification — cannot sell until EHS experts approve materials — measures the R&D team's ability to navigate the regulatory landscape and turn designs into revenue quickly.
> - % of staff trained in bio-medical standards — entering the medical sector is a new competency — tracking training in sterile operations mitigates the risk of defective output.
>
> **Conclusion/recommendation:** Attach a reason to every KPI; scorecard headings structure the answer.
>
> **L3 hooks (facts/numbers to cite):** E$2bn outlay, E$108m finance costs, E$10bn market, printers + compatible materials ecosystem, "fully sterile" requirement, EHS approval process, new-competency training need.

---

## Task 2a — Press release implications for share price + protection (~36 min · 20 marks · Core Activity C)

**Trigger:** One day later, email from CFO Agata Paluch. Board unanimously agreed to investigate further. Attached Ennland Daily article: Bank of Ennland under pressure to raise interest rates to combat inflation (Middle East unrest; soaring oil & gas, agriculture, food costs); Monetary Policy Committee meets in a week. Kwirtmak's share price has fallen 6% since the year end to E$47, so any fresh capital would be long-term debt (fresh equity inappropriate). The CEO wants to announce the medical investment to the Ennland Stock Market ASAP to restore shareholder confidence; the CFO is more cautious.

**Requirement:** *"Firstly, evaluate the implications of the proposed Press Release about the medical expansion for Kwirtmak's share price, and recommend, with reasons, how Kwirtmak might protect its share price in the short term."*

> [!question]- Reveal answer plan
> **Framework:** Efficient Market Hypothesis / semi-strong market efficiency; NPV signalling; investor relations / market communication.
>
> **Plan:**
>
> *Implications:*
> - EMH baseline — under the EMH the share price reflects the PV of expected future cash flows — if the market perceives the facility as positive-NPV the price should theoretically rise; the announcement signals targeting a lucrative sector (E$10bn in Ennland within 5 years) and aggressive pursuit of first-mover advantage.
> - Market assessment of NPV — the market reacts on whether it believes the facility is truly positive-NPV — if unconvinced of viability or Kwirtmak's ability to succeed, the share price will fall.
> - Size of the investment — E$2bn is highly material, more than half of total assets of E$3,789.1m — announcing such expenditure without a robust, detailed financial and strategic appraisal may concern institutional investors.
> - Perception of risk — beta already very high at 2.3 (shares volatile and sensitive to market changes); EHS requires rigorous approval processes — a vague or uncosted announcement may be read as a high-risk, impulsive reaction to the recent 6% share-price drop rather than a considered strategy.
> - Funding concerns — the market factors in financing — announcing a E$2bn debt-funded project just as the Bank of Ennland signals imminent rate hikes makes investors immediately expect higher gearing, increased financial risk and more expensive interest costs.
>
> *Protection recommendations (short term)* — overarching principle: give the market credible, verifiable information that reassures participants:
> - Delay the press release — hold off until a comprehensive financial and strategic evaluation is complete and funding secured — prematurely announcing a large, expensive 18-month project creates cash-flow uncertainty that could push the price down further.
> - Focus on existing strengths — arrange a briefing for investors, financial journalists and investment analysts highlighting strong existing operations in aerospace and automotive — reminding the market of reliable current revenue streams and technical advantages stabilises confidence.
> - Maintain commercial confidentiality — trade-off between supporting the share price and preserving commercial secrets — Breskko sells a very similar product range and could attempt to enter the medical market if intentions are signalled too early.
> - Ensure honesty and integrity — all market communications must be honest and accurate, e.g. must NOT present the E$10bn potential market value as guaranteed future revenue — dishonesty/exaggeration undermines Board credibility and causes long-term share-price damage.
>
> **Conclusion/recommendation:** State EMH theory first, then apply; balance the positive signal against labelled negatives; each recommendation needs a because-clause.
>
> **L3 hooks (facts/numbers to cite):** Share price E$47 down 6%, beta 2.3, E$2bn vs total assets E$3,789.1m, E$10bn market, Bank of Ennland rate-rise pressure, 18-month build, Breskko's similar product range, aerospace/automotive strengths.

## Task 2b — Economic risks of interest rate changes + responses (~24 min · 13 marks · Core Activity B)

**Trigger:** Same email — the Bank of Ennland is expected to raise interest rates to fight inflation, just as Kwirtmak contemplates borrowing to fund the E$2bn facility (fresh equity ruled out by the depressed E$47 share price). The CFO wants the wider economic exposure assessed.

**Requirement:** *"Secondly, evaluate the potential economic risks to Kwirtmak of a change in interest rates and recommend possible responses."*

> [!question]- Reveal answer plan
> **Framework:** Economic risk analysis (cost of debt/gearing, demand, FX, WACC/NPV); interest-rate hedging (fixed-rate bonds, interest rate swaps); natural hedging; TARA-style risk-then-response structure.
>
> **Plan:**
>
> *Risks:*
> - Increased cost of servicing debt / gearing — share price depressed at E$47 makes equity unattractive, forcing reliance on long-term borrowing — **calculation chain:** current long-term borrowings E$1,350m vs equity E$2,106.3m = gearing ≈ 64% (Breskko: 42.7%); +E$2bn borrowing → total debt E$3,350m → gearing ≈ 159% ("very aggressive"); current implied interest rate ≈ 8% (E$108m interest on E$1,350m debt); if debt rises to E$3,350m and rates rise to say 10%, interest costs jump to E$335m — an increase of 210% — significantly squeezing net profit margins and threatening ability to maintain the dividend payout. (Balance: hoped the medical expansion compensates.)
> - Suppression of customer demand — higher rates make borrowing expensive and cool the broader economy — commercial 3D printers are major capital expenditures; if aerospace, automotive and consumer electronics clients cannot secure affordable financing they defer equipment upgrades/prototype development → reduced Kwirtmak sales volumes.
> - Exchange rate exposure — central bank rate rises typically strengthen the currency (attracts foreign capital seeking higher yields) — Kwirtmak has three overseas factories and trades globally; a stronger E$ makes Ennland-made printers and materials dearer to foreign buyers in local-currency terms → less competitive internationally; overseas rivals capture market share (economic/transaction FX risk).
> - Impact on project viability (NPV) — rising rates increase WACC — a higher discount rate applied to the medical facility's projected cash flows lowers its NPV; a currently profitable project could become unviable.
>
> *Recommended responses:*
> - Interest rate hedging — secure fixed-rate corporate bonds for the new facility now rather than variable-rate loans; use interest rate swaps to convert existing floating-rate debt to fixed — certainty over future finance costs.
> - Phase the capital expenditure — build in modular stages over a longer period rather than committing E$2bn upfront — delays debt drawdown; reassess the macro environment at each stage; halt expansion if borrowing costs become unsustainable or EHS demand fails to materialise. Caveat: the clean sterile environment requirement may make a modular build unviable.
> - Customer leasing and financing options — offer monthly leasing for 3D printers — removes clients' need for upfront bank financing, maintains sales volumes, creates predictable recurring revenue during uncertainty.
> - Monitor currency impacts / leverage global footprint — if the E$ becomes too strong, shift some standard extrusion printer production to the three overseas factories — matches foreign-currency costs with foreign-currency revenues, a natural hedge against E$ volatility.
>
> **Conclusion/recommendation:** Evaluate each risk, then recommend a matched response; simple arithmetic with a stated assumption ("say, 10%") earns justification credit; add feasibility caveats to your own recommendations.
>
> **L3 hooks (facts/numbers to cite):** Borrowings E$1,350m, equity E$2,106.3m, gearing ≈ 64% vs Breskko 42.7%, post-borrowing gearing ≈ 159%, finance costs E$108m → implied rate ≈ 8%, sensitised interest E$335m at 10% (+210%), share price E$47, dividend payout, three overseas factories, aerospace/automotive/consumer-electronics customer base.

---

## Task 3a — Governance implications of unauthorised E$400m commitment + control environment (~30 min · 17 marks · Core Activities D/E)

**Trigger:** Two weeks later, urgent email from the CFO before the Board meeting to finalise the investment. An Audit Committee internal disclosure report reveals: (1) CTO Dr Said Abouchdak — told by the primary supplier of high-precision laser components that its next production run was almost fully reserved by a competitor, and unable to reach travelling Board members — signed a binding E$400m purchase order without Board approval, believing it consistent with Kwirtmak's mission, vision and values; the contract requires an immediate E$200m (50%) payment which Kwirtmak lacks liquidity for and must borrow amid volatile interest rates (may increase overall cost of capital). (2) Operations Director Kristina Eder, negotiating "preferred partner" status with the EHS Finance Director, withheld that the new printer prototype failed three consecutive sterilisation-consistency beta tests.

**Requirement:** *"Firstly, evaluate the governance implications of the decision to commit Kwirtmak to the equipment contract, and recommend improvements to the control environment."* (Briefing paper for the Board.)

> [!question]- Reveal answer plan
> **Framework:** Corporate governance — matters reserved for the Board, delegated authority limits, fiduciary duty, role of NEDs/CFO oversight; sunk-cost bias; mission/vision/values as (invalid) justification; control environment design (authority thresholds, dual signatories, hard system controls, emergency decision policy, remuneration sanctions).
>
> **Plan:**
>
> *Governance implications:*
> - Exceeded authority — Said signed a binding E$400m purchase order without Board permission — strategic investments of this magnitude should be classified as "Matters Reserved for the Board", requiring collective debate and approval.
> - Travel excuse inadequate — professional diligence dictates he should have rejected the supplier's offer unless he could negotiate a window of time sufficient to consult colleagues.
> - Bypassed oversight — acting unilaterally bypassed the professional scepticism of the Non-Executive Directors and the financial oversight of the CFO.
> - Pre-empted the Board vote / sunk-cost bias — the Board has not yet formally voted on the Ennland facility; Said effectively committed 20% of the projected E$2bn investment prematurely, creating a "sunk cost" bias that forces the Board's hand — withdrawing now would likely bring severe legal and financial penalties.
> - Necessity of the equipment questionable — if the Board scales back or delays the project, Kwirtmak is left with E$400m of specialised inventory idle for years, tying up capital and reducing operational efficiency.
> - Fiduciary duty breached — Said's technical enthusiasm superseded his fiduciary duty to protect the company's liquidity and to ensure all major assets are required before procurement.
> - Mission/vision/values defence rejected — "creating wealth and success" and driving innovation do not justify an unauthorised E$400m purchase; the benefit of the technology to the medical profession exists regardless of whether components were bought yesterday or via a Board-approved channel later — "opportunity" is no excuse for a governance breach.
> - Values actually breached — not a "team player" (circumvented normal Board activities; failed to consult the finance function on the E$200m cash deposit); misinterpreted "Kwirtmak trusts its staff" — "operational trust" is not "unregulated authority"; trust means operating within delegated limits; acting alone shows lack of trust in the Board's collective decision-making and sets a poor organisational example.
>
> *Control environment recommendations:*
> - Remuneration sanction — NE Chair Madda Fedele should recommend to the Remuneration Committee that Said's reckless behaviour be reflected in his performance-related bonus.
> - Consider requesting resignation — probably excessive given his technical expertise, but it must be clear that no director may act this way; signal to all senior management that recurrence brings severe consequences.
> - Formal Authority policy with financial thresholds — e.g. any contract exceeding E$50m requires a formal Board resolution and dual-signatory verification from the CEO and CFO.
> - Hard controls in procurement systems — prevent a single signature from binding the company.
> - Emergency Decision-Making Policy (via Audit Committee) — empower a subcommittee (Chair, CEO, CFO) to take time-sensitive decisions subject to full-Board ratification within 24 hours — balances "trust" with accountability, directly answering the "components would be lost to a rival" time-pressure scenario.
>
> **Conclusion/recommendation:** Implications first, then an explicit "Recommendations for improvements to the control environment" section with concrete, quantified fixes (E$50m threshold, dual signatures, 24-hour ratification).
>
> **L3 hooks (facts/numbers to cite):** E$400m = 20% of E$2bn project, E$200m (50%) immediate payment, liquidity shortfall + borrowing amid volatile rates, values quotes ("Kwirtmak trusts its staff", "team players", "creates wealth and success"), Matters Reserved for the Board, NED scepticism/CFO oversight, Madda Fedele as NE Chair.

## Task 3b — Ethical implications of withholding prototype failures from the EHS (~30 min · 17 marks · Core Activities D/E)

**Trigger:** Same disclosure report — Operations Director Kristina Eder, negotiating "preferred partner" status with the EHS Finance Director, chose not to disclose that the new printer prototype failed three consecutive sterilisation-consistency beta tests, arguing prototype failures are normal development and "not something a client's Finance Director would need to know", and admitting she was "nervous" full transparency would cause the EHS to pull out.

**Requirement:** *"Secondly, evaluate the ethical implications of the decision to withhold information from the EHS regarding the prototype testing failures."*

> [!question]- Reveal answer plan
> **Framework:** CIMA Code of Ethics fundamental principles — Integrity, Objectivity, Professional Behaviour, Professional Competence (applied to the counterparty); conflict of interest analysis; safety-critical/materiality reasoning.
>
> **Plan:**
> - Breach of Integrity — integrity requires being straightforward and honest in all professional and business relationships — non-disclosure of the beta-testing sterilisation failures is effectively lying by omission; she should have explained the technical challenges clearly regardless of commercial fallout; medical equipment requires absolute reliability; leaving the EHS Finance Director confused about the prototype's readiness means Kwirtmak obtained a dishonest advantage; her "did not need to know" argument is invalid because the information is highly material to a "preferred partner" agreement.
> - Breach of Objectivity / conflict of interest — she admitted being "nervous" that transparency would cause the EHS to pull out — clear conflict between Kwirtmak's commercial interests and the ethical requirement for transparency; she had a duty to remain objective and present reports truthfully but let the desire to secure the contract override neutrality; the "acting in shareholders' interest" defence does not apply when it involves misleading a client on a safety-critical issue like medical sterilisation.
> - Breach of Professional Behaviour + clinical risk — the principle requires directors to avoid actions that discredit the company — sterilisation failure is safety-critical in the medical sector; if Kwirtmak proceeds and equipment fails in clinical use, the revelation that failures were hidden would irreparably damage reputation and expose the company to severe legal liability, negligence claims and regulatory sanctions; a lie is not acceptable merely because the director hopes the problem will be fixed before final launch.
> - Counterparty's Professional Competence (balancing point) — arguably the EHS Finance Director breached their own duty of professional competence by failing to seek independent technical verification/due diligence given the high stakes of medical procurement — HOWEVER this does not justify Kristina's deception; the counterparty's lack of technical expertise placed a HIGHER ethical burden on her to be transparent, and her dishonesty actively encouraged their misunderstanding — a fundamental violation of professional ethics.
>
> **Conclusion/recommendation:** One header per fundamental principle: state the principle's definition → apply to Kristina's specific words/actions → consequence; the fourth point flips perspective to the counterparty then rebuts it — classic L3 evaluation with justification.
>
> **L3 hooks (facts/numbers to cite):** Three consecutive failed sterilisation-consistency beta tests, "preferred partner" status, direct trigger quotes ("nervous", "did not need to know"), safety-critical medical context, negligence/regulatory liability, EHS Finance Director's own due-diligence failure.

---

## Technique takeaways from this mock

- **Match the requested format exactly** — Tasks 1 and 2 are emails (To/From/Subject, one-sentence scope-setting intro restating both requests, sign-off offering further analysis); Task 3 is a briefing note (Prepared by/For/Subject).
- **Mirror the sub-task wording in headers** and weight word count to the % time split given (60/40 or 50/50).
- **Every point = claim + justification + pre-seen/trigger fact or number** — that link is the L2→L3 jump in every marking grid; embed pre-seen numbers throughout.
- **Score L3 by adding a counter-view to your own argument** ("However…", "Having said this…") — e.g. lead-time risk "is true of any project and so not of itself a reason not to proceed".
- **Enumerate arguments** ("Firstly… Secondly… Thirdly… Furthermore… Finally") under headed "Arguments For" / "Arguments Against" sections.
- **State the theory anchor FIRST, then apply it** — Task 2a defines EMH before evaluating; marking grid even awards L1 for defining market efficiency.
- **Simple arithmetic from pre-seen financials scores** — gearing, implied interest rate, % changes with a stated assumption ("say, 10%"); estimates are acceptable and earn justification credit.
- **Balanced Scorecard adds breadth to KPI questions** — examiner explicitly praised 2 KPIs per perspective; not mandatory, but a framework broadens coverage; attach a reason to every KPI.
- **Recommendations as labelled bullets, each with a because-clause**, concrete and quantified where possible (E$50m threshold, dual signatures, 24-hour ratification); add feasibility caveats to your own recommendations (modular build may not suit a sterile facility).
- **Ethics answers: one header per CIMA fundamental principle** — define → apply to the person's specific words/actions (quote the trigger: "nervous", "did not need to know", "opportunity too good to miss") → consequence; consider the counterparty's duties for balance, then rebut the mitigation.
- **Depth beats breadth** — marking grids reward 2–4 distinct, well-justified points per trait, not a long undeveloped list.
