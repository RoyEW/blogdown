---
tags: [scs/question-bank, kwirtmak, practice-workbook]
source: "Kaplan SCS Practice Workbook (Kwirtmak, May & Aug 2026)"
---

# QB — Practice Workbook Tasks

**How to use:** Cover the answer. Read only the **Trigger** and **Requirement**. Write your own bullet plan (5 min planning per 60-min task). Then reveal the model plan and mark yourself on: framework choice, breadth of points, and L3 hooks (pre-seen facts/numbers cited). The 20-question familiarisation quiz lives in flashcards, not here.

---

# Part 1 — Ten 60-minute exam tasks

## Task A1 — Proposed acquisition of CFP (60 min · Core Activity A)

**Trigger:** Email from Agata Paluch (CFO) forwarding a memo from Dr David Wallace (CEO). CFP is a small, private, employee-owned 3D printing company (4 years old) specialising in carbon-fibre 3D printers for medium-sized companies, with an excellent reputation and a long order pipeline. It is funded partly by staff share purchases but mainly by an Ennland National Bank loan due in 6 months; the bank won't renew, other banks have refused, and CFP lacks cash — default risk. CEO Jamie Lu is open to takeover offers, and Breskko executives have been seen talking to her.

**Requirement:** (a) Evaluate the arguments both for and against the proposed acquisition of CFP [60%]; (b) Identify, with reasons, the problems that could emerge post-acquisition [40%]

> [!question]- Reveal answer plan
> **Framework:** Acquisition evaluation (for/against); post-acquisition integration issues; valuation discipline
>
> **(a) Plan — FOR:**
> - Reputation fit — CFP's excellent design/supply reputation brings skills and capacity to meet client demand — fits Kwirtmak's own technical-advice reputation, so the deal doesn't endanger Kwirtmak's reputation.
> - Related (not unrelated) diversification — Kwirtmak has 30+ years in the 3D printer market, so it understands CFP's issues — lower risk of deal failure.
> - Workforce asset — strong, loyal, motivated workforce (from employee ownership) is a key asset if maintained — group scale offers staff mutual learning and opportunities.
> - Order pipeline — if the strong pipeline is fulfilled to expectation and profitably, CFP adds value from day one — could lift Kwirtmak's share price and reassure shareholders that wealth is being restored.
> - Growth segment — carbon fibre (light + strong) is used in Kwirtmak's core markets (aeronautics, automotive) and new ones (sporting goods) — satisfies existing demand and widens the customer portfolio.
> - Sales synergies — CFP's medium-sized clients may grow into larger Kwirtmak-type printers — cross-selling from group knowledge.
> - Timing/negotiating power — Jamie is keen to sell and the 6-month loan deadline means CFP can't hold out for a high price — Kwirtmak may get very good value.
>
> **(a) Plan — AGAINST:**
> - Banks' refusal to lend signals pessimism despite reputation/pipeline — ask why (has Kwirtmak seen banks misunderstand 3D printing?) — full due diligence on CFP's historic and forecast cash flows needed before any offer.
> - Staff motivation/loyalty stems from ownership — a takeover removes the equity stake — motivation falls, turnover rises.
> - Valuation risk / bidding war — Jamie has likely approached others including Breskko — rival bids push the agreed price up — must not overpay; keep sight of value.
> - Management distraction — protracted takeovers consume management time — core operations of both buyer and seller can suffer.
> - Alternative: wait for insolvency (bank petition within 6 months) and buy far cheaper than as a going concern — but risk a rival completes a deal first.
>
> **(b) Plan — Post-acquisition problems:**
> - Generic: IT/system integration is long and arduous — systems differ — management needs complete, accurate management information from CFP's system, which is of unknown quality.
> - Deal-specific: staff lose shares in their employer — motivation falls / staff leave to rival 3D-printer or engineering/tech firms.
> - Mitigation: a share-for-share exchange keeps CFP staff with equity in the group — but Kwirtmak's own staff, who have no share scheme, may feel aggrieved.
> - Redundancy fear — target staff pre-emptively job-hunt — send a public message: no redundancy threat, job security actually improves as the insolvency threat disappears, and growth means career advancement.
> - Cash drain — purchase money goes to the selling shareholders (Jamie Lu/staff), not into CFP — Kwirtmak must additionally fund the bank-loan repayment — is E$136m cash enough or is fresh capital needed?
> - Possible relief — CFP's bank may extend the facility once a larger owner stands behind it; Kwirtmak's bank may lend against a parent-company guarantee.
> - (Workbook quirk: the solution says "Jenny Li" once — an inconsistency for "Jamie Lu".)
>
> **Conclusion/recommendation:** No firm recommendation — the balance requires full due diligence (especially on why banks refused to lend) before any offer; disciplined valuation is essential given a probable rival bid from Breskko.
>
> **L3 hooks (facts/numbers to cite):** 6-month loan deadline, E$136.2m cash at 31.3.26, 30+ years in the market (founded 1992), reputation for technical advice, Breskko as rival bidder, carbon fibre in aeronautics/automotive/sporting goods, employee ownership

## Task A2 — PLA sustainability strategy (60 min · Core Activity A)

**Trigger:** Email from Kristina Eder (Operations Director) plus a file note of a call from Jonas Brittsen, an Ennland Telegraph journalist. Claims: Kwirtmak's plastic input is largely non-biodegradable; PLA-compatible machines are only 3% of relevant machines; PLA is 25% dearer so is not encouraged; Breskko has promoted PLA for 12+ months and it is now 30% of its sales mix. Kristina confirms the Kwirtmak figures are accurate and proposes a strategy shift; the journalist wants an official response within 48 hours pre-publication.

**Requirement:** (a) Evaluate the proposal that Kwirtmak aim for PLA-input printers to make up half of plastic-printer revenues within 4 years [50%]; (b) Recommend, with reasons, arguments Kwirtmak might use to claim it operates sustainably [50%]

> [!question]- Reveal answer plan
> **Framework:** Benefits/risks evaluation; sustainability claims structure (governance, resource efficiency, localisation, continuous improvement, regulatory engagement); vision alignment
>
> **(a) Plan — Benefits:**
> - Public statement of sustainability intent — the dangers of traditional plastic are well-documented — committing to PLA is environmentally responsible behaviour; cost shouldn't bar substitution.
> - Matches customer needs — customers face the same scrutiny and want suppliers to help their own sustainability goals — marketing PLA machines actively changes other businesses' buying/manufacturing behaviour (some customers may not know the option exists).
> - Route back to sales growth — Kwirtmak −19% revenue vs Breskko +10% — if Breskko's PLA push (30% of mix) is winning customers on environmental grounds, Breskko may be growing at Kwirtmak's expense — PLA restores competitive position.
> - Vision consistency — "leading provider…achieved in a sustainable manner" — ignoring the issue invites accusations of hollow ideals — lower ecosystem trust.
>
> **(a) Plan — Risks:**
> - Cost to customers — PLA is 25% dearer as an ongoing operating input (not Kwirtmak's cost) — naive to assume all customers accept higher unit costs, especially low-cost high-volume producers with thin margins.
> - Up-front investment — development, production, marketing costs — the E$136m cash is likely earmarked — may need fresh capital — full financial appraisal required; with falling margins and a depressed share price, the Board can't commit without confidence in returns.
> - Arbitrary targets — why 50% and why 4 years? — research feasibility so targets are neither too demanding nor unambitious.
>
> **(b) Plan — Sustainability arguments:**
> - Robust governance & oversight — the Operations Director has board-level sustainability oversight and reports at every routine Board meeting; a dedicated Risk and CSR Committee monitors sustainability; all staff are trained in environmental issues and empowered to halt operations on serious concerns (e.g. excessive emissions).
> - Inherent resource efficiency — additive layer-by-layer printing uses only the material required (vs subtractive waste); many plastics are recyclable into new filament (closed loop); design optimisation eliminates resource-heavy multi-part assembly; even if generic to 3D printing, Kwirtmak's chosen field advances sustainable production.
> - Reduced carbon footprint through localisation — print at point of use, so no transport emissions — e.g. airports print replacement parts on site, which also speeds repairs (no replacement aircraft ferried in).
> - Continuous operational improvement — 32% cut in PLA printing energy via nozzle temperature/layer thickness adjustments — environmental plus customer cost benefits — a proactive efficiency culture.
> - Regulatory engagement — the Legal Department ensures full compliance (H&S, environmental); Kwirtmak proactively engages governments/regulators to develop "realistic and effective" industry sustainability targets.
>
> **Conclusion/recommendation:** Preliminary recommendation — many benefits, but the Board should debate further with proper research into the 50%/4-year targets, not commit expediently because of the journalist's 48-hour deadline.
>
> **L3 hooks (facts/numbers to cite):** PLA 3% of machines, PLA 25% dearer, Breskko PLA 30% of sales mix over 12+ months, Kwirtmak revenue −19% vs Breskko +10%, E$136m cash, 32% PLA energy reduction, "sustainable manner" vision, staff empowered to halt operations, Risk and CSR Committee

## Task B1 — Wexland factory closure (60 min · Core Activity B)

**Trigger:** CFO email plus a Board minute. Axelrod Capital (a large shareholder) demands a plan to restore the share price and margins. The CEO wants to explore closing the Wexland factory: one of the oldest, its production line is due an upgrade in 2 years, it makes only extrusion printers (popular but the slowest-growing line), factory operating margin 46%, 750 staff. Wexland is a poor country with high unemployment; other sites can absorb only 80% of its output. The stakeholders most affected are employees and the Wexland government.

**Requirement:** (a) Evaluate the closure proposal on suitability, acceptability and feasibility (SAF) criteria [60%]; (b) Evaluate the power and interest of the two main stakeholder groups affected [40%]

> [!question]- Reveal answer plan
> **Framework:** SAF (Johnson & Scholes); Mendelow power/interest matrix ("keep informed"; "key players")
>
> **(a) Plan — Suitability:**
> - Define suitability — consistent with the company's position and strategic direction.
> - Suitable: aligns with restoring margins — extrusion is the slowest-growth line — moving away from older, less efficient sites supports the innovation mission.
> - Suitable: the factory needs an upgrade in 2 years — closing avoids that capex or frees the budget for better-returning projects.
> - Suitable: 80% of output absorbed elsewhere — a 20% volume loss is acceptable if resources are redirected to higher-growth technology (laser melting, SL). Conclusion: suitable.
>
> **(a) Plan — Acceptability:**
> - Define acceptability — consistent with stakeholder aims.
> - Acceptable to shareholders: Axelrod demands "clear strategic direction"; Wexland's 46% margin sits below the company's 50.6% (2026) — the factory suppresses group margin; closure helps restore toward 56.4% (2025).
> - Revenue dip from losing 20% of extrusion output — but extrusion printers are relatively low-value (small components, reasonable quality) — overall revenue impact not significant.
> - Counter: closing a major employer in a poor, high-unemployment country conflicts with the "sustainable manner" vision and "trust" value — reputational risk. On balance acceptable (the principal stakeholder is satisfied).
>
> **(a) Plan — Feasibility:**
> - Define feasibility — the organisation has the necessary resources.
> - Financially feasible: E$136.2m cash plus strong retained earnings — covers redundancy and relocation costs.
> - Logistically feasible: spare capacity confirmed by Kristina Eder — but the key operational risk is bringing the 80% online fast enough to avoid supply-chain disruption.
> - Legally feasible: must comply with Wexland employment law — failure is a major compliance risk given ethical-governance commitments. Conclusion: feasible.
>
> **(b) Plan — Employees:**
> - Interest — HIGH: 750 jobs in a high-unemployment, poor country — devastating; loss of income and poor re-employment prospects.
> - Power — LOW-TO-MEDIUM: individuals can't stop a board decision; unionisation/collective action (strike) raises power via production disruption and national/international attention — but only short-term since production is ceasing anyway; action may accelerate closure.
> - Classification — "keep informed" — manage with high empathy, clear communication, and redundancy packages to limit reputational damage.
>
> **(b) Plan — Wexland government:**
> - Interest — HIGH: unemployment worsens plus lost employment and corporate tax revenues.
> - Power — contextual: can complicate exit via legal challenges, environmental audits, withholding future licences; can sway public perception/buying if Kwirtmak has other Wexland interests; LOW if Wexland is manufacturing-only for Kwirtmak.
> - Classification — treat as "key players" — direct consultation on mitigation/transition plans — other host countries are watching how this is handled — protects global reputation.
>
> **Conclusion/recommendation:** All three SAF criteria are met — recommend the Board discusses the closure in further detail (not an unconditional go-ahead).
>
> **L3 hooks (facts/numbers to cite):** 750 staff, 46% factory margin vs 50.6% group (2026) and 56.4% (2025), 80% output absorbable / 20% lost, upgrade due in 2 years, E$136.2m cash, extrusion = slowest-growing line, Axelrod Capital demand, four factories (largest in Ennland)

## Task B2 — Economic problems and currency impact (60 min · Core Activity B)

**Trigger:** CFO email plus a treasury consultants' macroeconomic report. Foreign central banks have raised rates against inflation, causing a CapEx freeze in cyclical aerospace/automotive customers (extending machine lifecycles, spending only on operations/materials/maintenance); healthcare/medical devices are non-cyclical and still investing. Ennland rates are stable, so the E$ has appreciated 15% against a basket of currencies where Kwirtmak's three overseas factories and most export sales sit — translation losses on consolidation plus an economic competitiveness squeeze (hold E$ prices and lose share to Breskko et al., or discount and erode margins). (The report ends with a stray paragraph about Penland/Leothayre — an editorial error carried from another case; ignore it.)

**Requirement:** (a) Recommend, with reasons, how the Board should respond to the economic risk of a collapse in capital expenditure from major industrial customers [50%]; (b) Evaluate the impact of the appreciating E$ on Kwirtmak's translation and economic currency risks, and recommend whether the Board should attempt to mitigate these [50%]

> [!question]- Reveal answer plan
> **Framework:** Economic risk response; currency risk classification (translation/economic vs transaction); matching; operational hedging; value-based pricing
>
> **(a) Plan:**
> - Cause — higher borrowing costs raise customers' WACC — new high-value capital assets (Kwirtmak printers) become harder to justify — CapEx freeze in cyclical aerospace/automotive.
> - Pivot to non-cyclical sectors — healthcare/medical devices are insulated and still investing — medicine increasingly relies on precise 3D printing (subject to EHS approval) — Marketing should immediately reallocate resources/salespeople to healthcare, pharma and dental — inelastic demand offsets aerospace/automotive falls.
> - CapEx→OpEx models — customers can't raise debt for purchases — offer ≤12-month leases / machine-as-a-service (fixed monthly or usage-based fees) — OpEx bypasses customers' CapEx freezes and gives Kwirtmak recurring, predictable cash flows — BUT delays cash while upfront manufacturing costs are incurred — model the working capital; check E$136.2m cash plus debt facilities can absorb it without liquidity issues.
> - Maximise aftermarket/consumables/maintenance — clients extending machine lifecycles still have materials/maintenance budgets — customers already prefer Kwirtmak materials for compatibility — push long-term supply contracts, volume discounts for multi-year commitments, and maintenance/repair packages.
> - Sell software/hardware upgrades — premium software updates (CAD interface, speed, accuracy) let clients stretch machine life without new hardware — efficiency retrofits (e.g. the 32% PLA energy reduction) cut customer running costs — high-margin revenue for Kwirtmak.
>
> **(b) Plan — Translation risk:**
> - Definition — accounting exposure: foreign-currency net assets/subsidiary profits are translated to E$ at year end for consolidation.
> - Impact — E$ +15% means the overseas factories' local currencies weakened — net assets/retained profits translate to lower E$ values — an unrealised consolidation loss reduces group equity — already visible: the E$44.3m currency loss in the 2026 SOCIE currency reserve — expect a substantially larger loss next year.
> - Possible hedge — matching: fund the three overseas factories with local-currency debt — asset translation losses offset by liability translation gains.
> - Recommendation — do NOT mitigate — the loss is purely non-cash/unrealised with no daily cash-flow impact — hedging with real cash (costly forwards) is inefficient — restructuring the E$1,350m borrowings into foreign debt is not commercially justifiable — instead manage investor relations, explaining in the annual-report narrative that the equity reduction is translation mechanics, not poor performance.
>
> **(b) Plan — Economic risk:**
> - Definition — the long-term effect of exchange rates on the present value of future cash flows and global competitiveness — strategic, unlike short-term transaction risk on specific invoices.
> - Impact — the cost base (manufacturing, R&D, admin) is largely in strong E$; revenues are in depreciating currencies — exports become dearer — dilemma: hold E$ prices and be uncompetitive, accelerating share loss (Breskko, also Ennland-based, faces the same, but weak-currency local competitors can undercut); or discount and erode an operating margin already down to 50.6% from 56.4%.
> - Offset — the strong E$ makes imported materials/parts from third-party suppliers cheaper — a partial natural offset to margin decline.
> - Recommendation — DO mitigate immediately — but standard derivatives can't hedge an indefinite global position — use operational hedging: shift manufacturing/raw-material sourcing to the three overseas factories so costs are incurred in the same weak currencies as revenues — a natural hedge aligning the cost base with the revenue base, protecting margins.
> - Also value-based pricing, not discounting — a price war damages premium brand equity — sell the quality reputation, advanced capabilities (laser melting, material jetting), technical advice, and lower total cost of ownership (32% energy cut, less material waste) — defend premium E$ pricing and margins despite hostile FX.
>
> **Conclusion/recommendation:** Translation risk — do not hedge (unrealised, non-cash); manage via investor relations. Economic risk — mitigate immediately via operational hedging (overseas sourcing/production) and value-based pricing.
>
> **L3 hooks (facts/numbers to cite):** E$ +15% appreciation, three overseas factories, E$44.3m currency loss in 2026 SOCIE, E$1,350m borrowings, E$136.2m cash, margin 50.6% vs 56.4%, 32% PLA energy cut, EHS approval for medical use, consumables loyalty, Breskko Ennland-based

## Task C1 — Hostile bid from Breskko (60 min · Core Activity C)

**Trigger:** CFO email plus an Ennland Telegraph article. Breskko bypasses Kwirtmak's Board with a hostile direct cash offer to shareholders of E$55/share (~10% premium over the ≈E$50 trading price), citing Kwirtmak's decline (Breskko revenue E$3,016.0m vs Kwirtmak E$2,320.0m) and a "global champion" narrative. Analysts call it an opportunistic bid for Kwirtmak's asset base, patents and E$270m annual R&D output; the shares historically traded over E$400. The key battleground is Kwirtmak's loyal dividend clientele (E$432.2m payout, >50% of profits). The Board unanimously believes the bid undervalues long-term potential.

**Requirement:** (a) Recommend, with reasons, the business valuation models to prove E$55/share significantly undervalues Kwirtmak [50%]; (b) The CEO proposes doubling R&D funded by cutting the dividend (E$432.2m) to zero — evaluate the financial and strategic implications of a zero dividend mid-takeover-battle [50%]

> [!question]- Reveal answer plan
> **Framework:** DCF; asset/replacement-cost valuation; P/E on normalised earnings; pecking order theory; dividend signalling; clientele effect
>
> **(a) Plan:**
> - Context — the short-term market cap is sentiment/panic-driven, not fundamental value — the share price was far above E$55 (over E$100, historically E$400+) for much of the last 5 years — shift the narrative to intrinsic, maintainable and replacement value.
> - DCF (most robust) — Breskko is buying future cash flows from the E$270.0m annual R&D and patents — forecast free cash flows under a credible recovery plan (revenue back from E$2,320.0m toward past highs), discount at WACC — show per-share value >E$55 — caveat: beta 2.3 raises WACC — must show R&D cash generation beats even the high discount rate.
> - Asset-based / replacement cost — go beyond baseline NAV — E$2,551.3m PP&E plus E$497.2m other intangibles; proprietary software/patents are likely undervalued on the SFP but hugely costly for Breskko to replicate (R&D, patents, international factories from scratch) — exposes the bid as predatory asset-stripping bypassing barriers to entry — sets an absolute minimum "floor" value.
> - P/E on normalised earnings — a P/E on depressed current profit (E$810.6m) plays into Breskko's narrative — instead average 3–5 years' profits to smooth temporary macro shocks (revenue fell 2,856.6→2,320.0; operating profit 1,611.1→1,174.6), apply a strong industry multiple — historical E$400+ prices reinforce that E$55 is a mere 10% premium on a rock-bottom stock.
>
> **(b) Plan:**
> - Pecking order — retained earnings are the cheapest, least disruptive equity source — cutting the E$432.2m dividend fully covers the extra E$270.0m to double R&D, leaves an E$162.2m surplus to boost the E$136.2m bank balance, and avoids debt-servicing costs — financially highly feasible.
> - BUT internal cash-flow logic ignores the external market reaction during a hostile bid.
> - Signalling — dividend policy is the Board's most visible signal — last year's >50% payout despite falling profits signalled stability — a sudden cut to zero signals panic/financial distress — validates Breskko's "struggling rival in severe decline" claim — the share price falls below E$50 — makes E$55 look better.
> - Clientele — income-reliant investors (the "dividend clientele" analysts flag) lose their core investment criterion — they sell — the most willing buyer is Breskko at E$55 — cutting the dividend hands Breskko the shares needed for control.
>
> **Conclusion/recommendation:** R&D acceleration is valid long-term (Breskko E$3,016.0m vs our E$2,320.0m), but survival comes first — lose the battle and the R&D plans are irrelevant. Maintain the dividend to signal confidence and reward loyalty; fund R&D via alternatives: strategic debt restructuring, selling non-core assets, targeted innovation financing.
>
> **L3 hooks (facts/numbers to cite):** E$55/share offer (~10% premium over ≈E$50), historical E$400+ share price, beta 2.3, E$270.0m annual R&D, dividend E$432.2m (cover 1.9x, ~53% payout), profit E$810.6m, PP&E E$2,551.3m, other intangibles E$497.2m, revenue 2,856.6→2,320.0, operating profit 1,611.1→1,174.6, Breskko revenue E$3,016.0m, cash E$136.2m

## Task C2 — Ennland factory overhaul: rights issue & beta (60 min · Core Activity C)

**Trigger:** CFO email plus an Apex Management Consultants executive summary. The general industrial 3D printing market is saturated, so the Board wants to retool the main Ennland factory exclusively for high-margin laser-melting aerospace printers. Capex ≈ E$1.2 billion (robotics, clean rooms, proprietary software). Gearing is already high (borrowings E$1,350m vs equity E$2,106.3m), so no more debt — a large rights issue despite a heavily depressed share price. The consultants warn that aerospace is notoriously cyclical; a pure-play pivot cuts diversification, raises systematic risk, and pushes equity beta above 2.3, raising the cost of capital.

**Requirement:** (a) Identify and explain the challenges of a large rights issue with a heavily depressed share price, and recommend how to overcome them [50%]; (b) Explain the relevance of the consultants' warning that the aerospace focus will increase systematic risk and push equity beta above 2.3 [50%]

> [!question]- Reveal answer plan
> **Framework:** Rights issue mechanics (discount, TERP, underwriting, signalling); systematic risk/beta; operating gearing; CAPM; WACC/NPV link
>
> **(a) Plan — Challenges:**
> - Scale — E$1.2bn ≈ 57% of current total equity — a major ask while the share price is depressed.
> - Pricing/failure risk — rights must be priced at a discount — if the market price falls below the issue price during the offer, shareholders ignore the rights and buy in the market — the issue fails and there is no E$1.2bn — (arguably an already-low price makes further falls less likely, but this is not guaranteed).
> - Dilution/TERP — a low share price forces a large volume of deeply discounted shares — the price dilutes to TERP and future EPS is suppressed — total value should rise by the cash raised, but retail investors may misread TERP as a real value loss and sell, pushing the price down further.
> - Signalling/apathy — investors who just lost money may refuse another E$1.2bn — risk it reads as a desperate bailout despite the aerospace strategy.
>
> **(a) Plan — Fixes:**
> - Fix 1: significant discount — a safety cushion so the issue price stays below market even after a shock — accept the extra TERP/EPS dilution.
> - Fix 2: underwriting — investment banks guarantee take-up — fees are substantial for a highly volatile stock (an unavoidable insurance premium) — a deep discount lowers the underwriters' risk, making them likelier to agree.
> - Fix 3: positive signalling — a proactive investor-relations campaign: the retrofit enables premium pricing and substantially higher margins than the saturated industrial market — a strategic investment, not desperation.
>
> **(b) Plan:**
> - Systematic risk defined — unavoidable market-wide risk undiversifiable by shareholders (interest rates, inflation, cycles) — measured by beta; market beta = 1 — Kwirtmak's 2.3 is already highly volatile — combines business risk (tech/manufacturing) and financial risk (E$1,350m debt vs E$2,106.3m equity).
> - Business risk rises — aerospace is notoriously cyclical, sensitive to travel trends/economic shocks — stopping industrial printers at the largest factory strips diversification across automotive, consumer electronics and jewellery — corporate diversification doesn't directly matter to well-diversified shareholders, but a near pure-play locks future cash flows into aviation cyclicality — mitigating note: Ennland is one of four factories; the other three can still make general industrial printers.
> - Operating gearing rises — E$1.2bn of robotics/clean rooms/software means higher fixed overheads — profit volatility is amplified in downturns — asset beta and systematic risk go up.
> - CAPM/cost of equity — higher beta means risk-averse investors demand higher returns — the cost of equity rises automatically — if perceived before profits arrive, the already-low share price falls further as cash flows are discounted at the higher required return.
> - Appraisal relevance — NPV uses WACC — higher beta → higher cost of equity → higher WACC → lower NPV — "substantially higher margins" are not enough; cash flows must beat the higher discount rate — if premium pricing is fully offset by the higher cost of capital, NPV may be negative and the E$1.2bn destroys shareholder wealth.
>
> **Conclusion/recommendation:** The consultants' warning is directly relevant to the investment appraisal — the project must clear a higher WACC; deep discount + underwriting + proactive IR are needed for the rights issue to succeed.
>
> **L3 hooks (facts/numbers to cite):** E$1.2bn capex (≈57% of equity), borrowings E$1,350m vs equity E$2,106.3m, beta 2.3, share price ≈E$50 (depressed), four factories (Ennland largest), sectors: aerospace/automotive/consumer electronics/jewellery, laser melting = high-margin line

## Task D1 — Aerospace client IP security incident (60 min · Core Activity D)

**Trigger:** CFO email plus an Operations Director email. Network monitoring caught an unauthorised data-export attempt from a terminal on a high-capacity SL printer fabricating a confidential aerospace engine prototype. A third-party software-maintenance technician bypassed encryption during a routine update. The Ennland site manager had formally instructed staff last year to 'relax' digital security (protocols caused latency; the bypass was needed to 'overdeliver on promises'). The firewall prevented the export; an Ennland Daily journalist is asking staff about 'production shortcuts' — the story is about to break. Risk and CSR Committee emergency meeting Monday; the matter is confidential.

**Requirement:** (a) Evaluate the argument that the Board should have foreseen the negative publicity about CAD-file security management [30%]; (b) Evaluate arguments for and against asking Internal Audit to identify the specific individuals whose actions gave the technician access [35%]; (c) Evaluate the ethical arguments for and against disclosing this "prevented" breach to the affected aerospace client, considering the "trusted provider" vision [35%]

> [!question]- Reveal answer plan
> **Framework:** Board oversight / tone at the top; internal audit scope & independence (self-review threat); CIMA Code of Ethics (integrity, professional competence & due care, confidentiality, objectivity)
>
> **(a) Plan:**
> - The argument is valid — a fundamental gap in strategic oversight — the Board doesn't run daily operations but owns "tone at the top" and the strategic reputational risk of being a "trusted provider".
> - A site manager feeling authorised to formally 'relax' encryption is a failure of board-level oversight — the "overdeliver" culture without security boundaries empowered compromising security for local production gains.
> - CAD-file vulnerability is fundamental to the business model — aerospace clients' IP is their primary competitive advantage — reliance on third-party technicians on complex SL systems was an identifiable strategic risk requiring robust safeguards.
> - Even a firewall-"prevented" compromise is a mission-critical failure in customers' eyes.
> - Vague "trusting its staff" is not mitigation for mission-critical digital assets — no "trust but verify" framework — speed was prioritised over security — the governance gap is now a public scandal (Ennland Daily) — the vision is compromised; severe brand damage and possible loss of high-value contracts.
>
> **(b) Plan — FOR IA investigating individuals:**
> - IA knows the internal control framework and the SL software environment — efficient.
> - Already cleared for sensitive aerospace client data (unlike an external firm) — immediate start.
> - Pinpointing where/why protocols were bypassed identifies the exact policy changes and targeted training needed to prevent recurrence.
> - Accountability is deterrence — no consequences signals that protocols are optional under deadline pressure.
> - Establishes whether this was an isolated lapse (site manager) or a systemic compliance-monitoring failure.
>
> **(b) Plan — AGAINST:**
> - IA as a "police force" damages the core value of trusting staff — psychological safety of engineers — a blame culture where staff hide future errors/shortcuts.
> - Identifying individuals may exceed IA's proper scope — IA evaluates the adequacy of control systems, not forensic HR investigations.
> - An individual focus distracts the Risk and CSR Committee from the root cause — a systemic failure balancing production deadlines against risk appetite.
> - Self-review threat — if IA audited Ennland previously and missed the year-long relaxed protocols — independence compromised — risk of a defensive report protecting IA's own record.
>
> **(c) Plan — Ethics of disclosure:**
> - Framing — the firewall blocked the export, but the vulnerability from relaxed protocols is a material fact affecting the client's risk profile — balance reputation against the "trusted provider" vision.
> - Integrity — be straightforward and honest — non-disclosure is misleading assurance that standard protocols applied when they were relaxed for a year — must not be associated with information that omits reality.
> - Professional competence and due care — Kwirtmak failed due care by letting deadlines override encryption — due care now requires telling the client so it can protect the engine prototype's competitive advantage.
> - Confidentiality — doesn't justify hiding professional negligence endangering the client's primary asset — and the Ennland Daily is already investigating — hiding it ignores the high probability of public exposure.
> - Objectivity — judgment must not bend to fear of losing the contract — "no harm done" is flawed: the harm IS the compromise of the protective environment the client pays a premium for.
>
> **Conclusion/recommendation:** Disclose proactively, with IA-identified remedial actions — demonstrates the accountability of a genuine "trusted provider" — radical honesty before the press breaks the story may strengthen the partnership; brand protection never justifies ignoring ethics.
>
> **L3 hooks (facts/numbers to cite):** high-capacity SL printer, aerospace engine prototype, third-party maintenance technician, site manager's formal 'relax' instruction a year ago, "overdeliver on promises" value, "trusts its staff" value, firewall prevented export, Ennland Daily, Risk and CSR Committee, "trusted provider" vision

## Task D2 — Counterfeit medical implants (60 min · Core Activity D)

**Trigger:** CFO email plus an Ennland Daily article. A Kwirtmak high-capacity SL printer sold to an unverified third-party "research lab" was allegedly used to print counterfeit titanium hip and dental implants below safety standards. The sales team may have bypassed KYC vetting to hit aggressive "overdeliver" targets; sales speed was prioritised over CAD security and end-user verification. The hardware/materials are Kwirtmak-branded; #KwirtmakFakes is trending among healthcare providers; the EHS relationship is at risk.

**Requirement:** (a) Evaluate the argument that this incident (product misuse and counterfeiting) should have been recognised in the risk register with an effective mitigation strategy [50%]; (b) Recommend, with reasons, internal controls to prevent recurrence in vetting new customers and monitoring printer usage [50%]

> [!question]- Reveal answer plan
> **Framework:** Risk register / KRIs / risk appetite / net risk; balanced scorecard; internal controls (preventative/detective); KYC; governance (IT Director gap)
>
> **(a) Plan — FOR recognition in the register:**
> - High-impact technology — SL printers are precise to a tiny fraction of a millimetre — third-party "cloning" of proprietary medical designs was a foreseeable strategic risk, not hypothetical.
> - The register focused only on regulatory penalties for Kwirtmak's own factories — it missed that customer product-misuse is a massive threat to the "trusted provider" vision — #KwirtmakFakes tarnishes the perceived quality of genuine output — it should be a strategic reputation risk.
> - No Key Risk Indicators (KRIs) — the aggressive "overdeliver" sales culture was a lead indicator that vetting was being compromised for volume.
>
> **(a) Plan — Why it may have been omitted:**
> - External criminal act — hard to quantify/control once the printer is sold.
> - "Trusting staff/partners" values — cognitive bias — criminal counterfeiting by a research lab was deemed too remote for a principal risk.
> - Net-risk assessment — assumed existing quality hardware/software updates deterred fakes.
> - No IT Director on the Board — no technical expertise to explain how easily CAD interfaces could be exploited.
> - Assumed general Legal oversight covered all external liabilities — failed to distinguish compliance from targeted criminal misuse.
>
> **(a) Plan — Effective mitigation design:**
> - Move beyond passive legal monitoring — technical preventative controls: encrypted "handshakes" in CAD software so high-precision medical geometries print only with a secure digital certificate.
> - Establish KRIs flagging sales tactics that bypass KYC vetting.
> - The Board defines a clear risk appetite for third-party misuse — product misuse becomes a core pillar of product-development security, not just a legal footnote.
> - Balanced scorecard for marketing — commissions/success no longer volume-only — mandatory non-financial KPIs: vetting-documentation accuracy, completed end-use audits — "overdeliver" governed by mandatory ethical protocols aligned to the sustainability/trust vision.
>
> **(b) Plan — Internal controls:**
> - Enhanced customer due diligence — a centralised, independent vetting unit outside Marketing's reporting line — mandatory background checks verifying the physical existence and regulatory standing of labs/intermediaries — a "hard block": no despatch until an independent compliance officer signs off the end-user's identity — stops site managers relaxing standards for short-term promises; adds the professional scepticism the "team player" culture lacks.
> - Technical usage monitoring / digital handshakes — mandatory for all high-capacity machines — the printer verifies the CAD file's digital certificate with a secure Kwirtmak server before printing safety-critical geometries (e.g. implants) — auto-halt plus an alert to the Product Software Department on unverified/cloned designs — a preventative AND detective control against criminal repurposing.
> - Board-level IT Director — the absence leaves the Operations Director managing complex CAD/product-security risks — appoint an IT Director as strategic technical risk owner to challenge Marketing/Operations when speed trumps security — embeds "security-by-design" and protects the trusted-provider reputation.
> - Independent usage audits — random technical audits of customers running high-capacity SL printers — a "right to audit" clause in sales agreements (printer logs, material consumption) — detects irregularities (e.g. a lab consuming high volumes of medical-grade titanium resin with no medical certification) — reported to the Audit Committee, with clear consequences for violating ethical/safety standards.
>
> **Conclusion/recommendation:** The omission argument is largely valid — foreseeable, vision-critical risk with identifiable causes of omission; the fix combines register redesign (KRIs, risk appetite, scorecard) with layered preventative and detective controls plus a board-level IT Director.
>
> **L3 hooks (facts/numbers to cite):** high-capacity SL printer precision (fraction of a millimetre), titanium hip and dental implants, #KwirtmakFakes, no IT Director, "overdeliver on promises" and "trusts its staff" values, EHS approval relationship, KYC vetting, "trusted provider" vision

## Task E1 — MedTech audit: cybersecurity NED & mission oversight (60 min · Core Activity E)

**Trigger:** CFO email plus a board briefing note. MedTech Global (a major international healthcare provider) is in final negotiations for a long-term exclusive supply contract for 3D-printed surgical guides; its due diligence flags the Capital City University (CCU) pilot (high-capacity SL printers placed at CCU for R&D/training) as a 'governance blocker'. Findings: 'unvetted' medical parts printed at CCU for third-party commercial clients (a 'grey market' contradicting the 'trusted and safe provider' vision); Dr Wallace is a CCU PhD alumnus (can't objectively challenge lax lab security); Chair Madda Fedele sits on the CCU Senate and Audit Committee (fiduciary conflict); the board lacks 'Technical Constructive Challenge'. Fedele suggests urgently appointing an additional NED with a cybersecurity/digital-integrity background.

**Requirement:** (a) Evaluate the arguments for and against appointing an additional NED with a cybersecurity/digital integrity background [50%]; (b) Recommend, with reasons, the approach Kwirtmak's NEDs could take to ensure the company is managed in accordance with its mission and vision statements [50%]

> [!question]- Reveal answer plan
> **Framework:** Board composition/balance; familiarity threat; NED vs executive roles; committee machinery (Audit, Remuneration, Nomination); tone at the top
>
> **(a) Plan — FOR:**
> - Provides the independent technical 'constructive challenge' MedTech says is missing from board discussions.
> - Technical oversight is currently concentrated in Kristina Eder (manufacturing plus data security) amid the 'overdeliver' culture — risk that security is secondary to production targets — a specialist NED elevates data integrity to a core strategic risk.
> - Mitigates the CCU familiarity threats — Wallace (alumnus) and Fedele (CCU Senate fiduciary) may lack objectivity on CCU security failings — a NED with no CCU history provides unbiased 'fresh eyes' satisfying MedTech.
>
> **(a) Plan — AGAINST:**
> - Specialist-role risk — other directors treat digital risk as solely the new NED's job — governance is a collective board responsibility — the NED should instead catalyse whole-board digital literacy (including the Audit Committee).
> - A part-time NED can't fix the day-to-day management gaps that let 'unvetted' parts be printed at CCU — arguably a full-time executive (CTO-type) is needed for continuous hands-on custody of proprietary files.
> - But adding only an executive raises executives to five vs three NEDs — worsens board imbalance and weakens independent oversight.
>
> **(b) Plan — NED approach to mission/vision:**
> - Audit (and Risk) Committee — widen the remit beyond financial reporting to the 'Safe Provider' vision — after the CCU discovery, don't rely on executive assurances — mandate IA or third-party specialists to run unannounced site visits and technical inspections — objective independent verification that technology is used only for authorised R&D — prevents 'mission drift' from output pressure.
> - Remuneration Committee — the primary realignment tool — replace volume-only bonus targets with stretching non-financial KPIs (data-security accreditation, product integrity, ethical compliance) — link a significant share of long-term incentives to them — financial motivation to uphold 'safe' — the 'tone at the top' proof MedTech wants.
> - Board meetings / Nomination Committee — robust constructive challenge as a fiduciary duty on any deviation from mission — review the board skills matrix — a formal Board Training Programme so all directors (including NEDs) have the digital literacy to interpret technical audit reports — transparently report these governance enhancements in the Annual Report to reassure institutional investors.
>
> **Conclusion/recommendation:** Appoint BOTH a new executive CTO (daily security management) AND a cybersecurity NED (restores exec:NED balance plus independent oversight) — two senior salaries are justified by the commercial necessity of the MedTech contract — delivers hands-on management plus the oversight needed for the 'trusted and safe provider' reputation.
>
> **L3 hooks (facts/numbers to cite):** MedTech Global exclusive contract, CCU pilot with high-capacity SL printers, Wallace CCU PhD alumnus, Fedele on CCU Senate and Audit Committee, 'grey market' unvetted medical parts, 'trusted and safe provider' vision, Kristina Eder's dual manufacturing/data-security load, board imbalance (execs vs 3 NEDs)

## Task E2 — Procurement compliance failure & internal audit (60 min · Core Activity E)

**Trigger:** CFO email plus a Head of QA memo (Customer Complaint #882). A surgical guide shattered in a clinical environment; QA confirmed 'Industrial-Grade' resin was used instead of the approved 'Medical-Grade' (lower tensile strength). The Supplier Vetting Protocol requires sourcing exclusively from the Approved Supplier List (ASL); a Procurement Officer bypassed ERP mandatory blocks by splitting one large resin order into twelve smaller invoices manually coded as 'General Office Consumables' (sundry) — no ASL verification or 30-day quality audit. The Operations Director is responsible for procurement AND approved the 'Efficiency Bonus' (lowest cost-per-gram) now under scrutiny, so the Audit Committee is to take independent charge. Employment contracts contain an 'Ethical Integrity' clause; staff interviews reveal a 'meeting the numbers at any cost' culture and pressure to protect bonuses.

**Requirement:** (a) Explain the issues the Audit Committee should consider when commissioning a detailed compliance audit into procurement and supplier vetting, and the approach IA should take when undertaking and reporting its investigation [50%]; (b) Recommend specific IA tests to check staff compliance with vetting and security controls, and evaluate the argument that any staff member found in breach should face immediate disciplinary action and bonus clawbacks [50%]

> [!question]- Reveal answer plan
> **Framework:** Audit committee oversight; IA independence (self-review, reporting lines); compliance vs substantive testing; forensic techniques; discipline/clawback balance; remuneration governance
>
> **(a) Plan — Commissioning issues:**
> - Independence first — a self-review threat because the Operations Director approved the incentivising 'Efficiency Bonus' — IA must report directly to the NEDs, not via executive channels.
> - Materiality — given the 'Safe Provider' vision, ANY bypass of medical-grade vetting is material regardless of invoice value.
> - Management override — did the 'overdeliver' culture pressure senior management to ignore red flags on 'sundry' spending?
> - Resources/competence — consider a joint IA + QA investigation (forensic financial skills plus technical resin expertise); forensic specialists may be needed to untangle the twelve split invoices.
> - External stakeholders — decide when to notify external auditors / medical regulators to protect manufacturing licences.
> - Whistleblowing amnesty — encourage immediate disclosure of other 'off-contract' purchases.
> - Interim directive — quarantine all inventory from unvetted suppliers now to prevent further clinical failures.
> - Tone at the top — establish whether cost-saving pressure created a permissive environment for override.
>
> **(a) Plan — IA approach:**
> - Forensic, risk-based, advisory, and objective throughout.
> - Widen the search — check other departments/regions for 'office supply' accounts buying production materials without safety checks.
> - Preserve evidence — secure read-only access to system logs — an immutable record for disciplinary/legal proceedings.
> - Urgent timetable plus an immediate preliminary report — the Board can stop suspect materials before the full report.
> - Sceptical interviews — test verbal explanations against digital 'footprints' in the system.
> - Root-cause analysis — software flaw vs culture/bonus schemes encouraging risk-taking.
> - Fact-check findings with the CFO before finalising.
> - Final report — permanent system fixes (e.g. automatic blocks on payments to suppliers without a safety audit) plus a six-month follow-up to prove the fixes and cultural change work.
>
> **(b) Plan — IA tests:**
> - Compliance — system exception reporting: an ERP report of purchases without a mandatory ASL code — systemic failure vs just the twelve invoices.
> - Compliance — authorisation limit testing: find 'near-limit' transactions — multiple same-vendor invoices just below the manual office-supplies approval threshold — proves deliberate circumvention.
> - Compliance — purchase order sequencing: twelve rapid-succession orders to one supplier for one material = premeditated limit-dodging, not unrelated office needs.
> - Compliance — access rights audit: how could the Procurement Officer code production resin as 'General Office Consumables' with no alert or supervisor sign-off?
> - Substantive — supplier data matching: compare sundry-ledger bank details vs the ASL — detects back-door payments to unvetted suppliers avoiding the 30-day quality audit.
> - Substantive — physical stock-to-record verification: inspect warehouse resin, trace batch numbers to purchase paperwork — Industrial-Grade physically present vs Medical-Grade on record = undeniable bypass proof.
> - Substantive — digital forensic review: email logs/metadata keyword search ("split", "sundry", "bonus") — evidence of a coordinated plan prioritising 'lowest cost-per-gram' over 'Safe Provider'.
> - Substantive — data pattern analysis: data-mining for invoices clustered just under the automatic senior-oversight trigger — flags intentional spend-profiling under the ERP radar.
>
> **(b) Plan — Discipline/clawback evaluation:**
> - FOR action — the explicit 'Ethical Integrity' contract clause was breached — twelve-way order splitting was premeditated circumvention of ERP blocks — it directly caused a clinical product failure contradicting the 'trusted and safe provider' vision — in medical-grade manufacturing this is typically gross misconduct — a clear legal basis for dismissal.
> - Clawback technically justified — bonuses were earned under false pretences (cost savings only achieved by ignoring mandatory safety protocols).
> - Mitigating factors — a widespread 'meeting the numbers at any cost' culture; staff feared for their livelihoods; the Operations Director's incentive design created the conflict of interest — punishing juniors without fixing top-down pressure = scapegoating — unfair-dismissal legal risk; full clawback further damages already-pressured morale.
>
> **Conclusion/recommendation:** Balanced reform — (1) the Board/Remuneration Committee must review and sign off all future 'Efficiency Bonus' schemes (not one executive's discretion); (2) replace vague "trusting staff" with rigorous detailed policies making safety compliance a 'gatekeeper' for any financial reward; (3) a 'Safety Gate' mechanism — any ASL/quality bypass = automatic forfeiture of the entire department's bonus AND automatic formal disciplinary proceedings — safety is a non-negotiable condition of employment.
>
> **L3 hooks (facts/numbers to cite):** Complaint #882, Industrial-Grade vs Medical-Grade resin (tensile strength), twelve split invoices coded 'General Office Consumables', Approved Supplier List (ASL), 30-day quality audit, 'Efficiency Bonus' (lowest cost-per-gram), 'Ethical Integrity' clause, Operations Director owns procurement, 'meeting the numbers at any cost' culture

---

# Part 2 — Familiarisation exercises

## Exercise CH2-EX1 — Profit performance ratio analysis

**Requirement:** Use ratio analysis to assess the profit performance of Kwirtmak for 2026 and 2025, and compare it to that of Breskko. Write a brief commentary.

> [!question]- Reveal answer plan
> **Framework:** ROCE decomposition (ROCE = asset turnover × operating margin)
>
> **Calculations (E$m):**
> - Kwirtmak capital employed: 2026 = 1,350.0 + 2,106.3 = 3,456.3; 2025 = 1,350.0 + 1,772.2 = 3,122.2
> - Kwirtmak ROCE: 2026 = 1,174.6 / 3,456.3 = 34.0%; 2025 = 1,611.1 / 3,122.2 = 51.6%
> - Kwirtmak asset turnover: 2026 = 2,320.0 / 3,456.3 = 0.67x; 2025 = 2,856.6 / 3,122.2 = 0.91x
> - Kwirtmak operating margin: 50.6% (2026); 56.4% (2025)
> - Breskko capital employed: 2026 = 1,400.0 + 3,277.8 = 4,677.8; 2025 = 1,400.0 + 2,942.6 = 4,342.6
> - Breskko ROCE: 34.2% (2026); 33.9% (2025)
> - Breskko asset turnover: 0.64x (2026); 0.63x (2025)
> - Breskko operating margin: 53.1% (2026); 53.7% (2025)
>
> **Commentary points:**
> - Kwirtmak had a very challenging year — revenue fell 18.8% (2,856.6 → 2,320.0) — margin dropped 56.4% → 50.6%.
> - Margin squeeze — sales volume fell but fixed overheads were not cut at the same pace — R&D only trimmed 285.0 → 270.0 (and that spend is vital for future success).
> - Shrinking revenue plus rigid costs — ROCE fell sharply 51.6% → 34.0%.
> - Breskko grew revenue 9.9% to 3,016.0 — a worrying shift: Kwirtmak was larger in 2025 (2,856.6 vs 2,744.6), but Breskko has now firmly overtaken it in market size.
> - Breskko held its margin just over 53% and ROCE at ~34% in both years — its 2026 margin (53.1%) now comfortably beats Kwirtmak's (50.6%) — capturing sales while keeping excellent cost control.
> - Overall — Kwirtmak's 2025 superiority in margins/returns has collapsed to near-parity with Breskko; volatile sales demand is a recognised principal risk (pre-seen) — the Board (especially Marketing Director Ouyang Qi) must urgently establish whether the fall is global economics or Breskko stealing market share.

## Exercise CH2-EX2 — Long-term funding analysis

**Requirement:** Analyse and comment on the long-term funding (debt and equity finance) for both Kwirtmak and Breskko, using the SPL, SOCIE and SFP presented in the pre-seen on pages 17–20.

> [!question]- Reveal answer plan
> **Framework:** Gearing ratios; interest cover; dividend cover; signalling/clientele ideas
>
> **Calculations (E$m):**
> - Kwirtmak gearing D/E: 2026 = 1,350.0 / 2,106.3 = 64.1%; 2025 = 76.2%. D/(D+E): 39.1% (2026); 43.2% (2025)
> - Kwirtmak interest cover: 2026 = 1,174.6 / 108.0 = 10.9x; 2025 = 1,611.1 / 108.0 = 14.9x. Interest rate ≈ 108 / 1,350 = 8.0% both years. Dividend cover = 810.6 / 432.2 = 1.9x (no 2025 info)
> - Breskko gearing D/E: 2026 = 1,400.0 / 3,277.8 = 42.7%; 2025 = 47.6%. D/(D+E): 29.9% (2026); 32.2% (2025)
> - Breskko interest cover: 2026 = 1,600.2 / 112.0 = 14.3x; 2025 = 1,472.7 / 112.0 = 13.1x. Interest rate ≈ 112 / 1,400 = 8.0%. Dividend cover = 1,145.9 / 799.4 = 1.4x
>
> **Commentary points:**
> - Both firms kept identical borrowings across both years (Kwirtmak 1,350.0; Breskko 1,400.0) — gearing fell naturally as retained profits grew equity.
> - Kwirtmak is noticeably more geared (39.1% vs 29.9% on a D/(D+E) book basis) — higher financial risk — a key Board issue given the drop in operating profits.
> - Both pay an identical ~8.0% — likely long-term fixed-rate debt (bonds/fixed loans) — protects both from Ennland interest-rate volatility and gives cost certainty.
> - Kwirtmak interest cover fell 14.9x → 10.9x — a concerning trajectory, but 10.9x still means debt is serviced without difficulty (the concern is the direction, not the level); Breskko improved 13.1x → 14.3x as profits grew.
> - Dividends: Kwirtmak paid 432.2 (cover 1.9x, ~53% payout); Breskko paid 799.4 (cover 1.4x, ~70% payout).
> - No prior-year dividend data — the clientele effect suggests established listed firms have paid similar dividends before.
> - Breskko's higher payout may be deliberate market signalling of confidence in cash flows/market-share gains; Kwirtmak's conservatism may reflect retaining cash for R&D / a buffer while investigating declining sales.

## Exercise CH2-EX3 — Share price graph and beta

**Requirement:** Analyse and comment on the information presented on page 21 of the pre-seen (Kwirtmak share price graph and beta factor).

> [!question]- Reveal answer plan
> **Framework:** Beta; asset vs equity beta (F3 ungearing formula); CAPM concepts
>
> **Solution points:**
> - The share price has been highly volatile over 5 years — spikes briefly above E$400 and E$500 — now a severe decline to ≈E$50.
> - The fall aligns with the 2026 results (revenue −~19%; operating profit −E$436.5m) damaging investor confidence — investors also see Breskko growing to E$3,016.0m in the same period — the market fears loss of competitive edge/market share.
> - Beta = 2.3 with no comparator — the shares are 130% more volatile than the market average; beta measures systematic risk.
> - Presumed equity (geared) beta = business risk of 3D printing + financial risk of gearing.
> - Ungearing (assume book = market values; tax 24%; debt beta 0; F3 formula) — asset (ungeared) beta ≈ 1.55 — even without financial risk, the core 3D-printing operations carry much higher systematic risk than the market; gearing layers this up to 2.3.

## Exercise CH2-SWOT — SWOT of Kwirtmak

**Requirement:** Summarise what you know about the case by identifying the strengths, weaknesses, opportunities and threats of (or facing) Kwirtmak.

> [!question]- Reveal answer plan
> **Framework:** SWOT
>
> **Strengths:**
> - Diverse product range/expertise (all five printing technologies) — serves varied needs.
> - Established position and reputation — founded 1992, listed 2004, known for technical advice plus high quality.
> - Global manufacturing and sales — four factories (largest in Ennland), worldwide market — geographic diversification.
> - Customer loyalty and consumables revenue — customers buy Kwirtmak materials for compatibility/optimal output — steady revenue beyond machines.
> - Strong technical leadership — CEO Dr David Wallace and CTO Dr Said Abouchdak both hold relevant engineering PhDs.
>
> **Weaknesses:**
> - Declining financials — revenue 2,856.6 → 2,320.0; operating profit 1,611.1 → 1,174.6.
> - High beta of 2.3 — the stock is far more volatile than the market.
> - Heavy reliance on third-party suppliers — disruption/quality issues can halt operations or damage reputation.
> - High product cost — high-quality but expensive — limits appeal to price-sensitive segments.
>
> **Opportunities:**
> - Medical/dental expansion — implants, heart valves, limbs; a big growth market once materials are EHS-approved.
> - Carbon fibre / advanced materials — demand in automotive, aerospace, sporting goods — develop capable printers.
> - Sustainability leadership — less waste, local production, recyclable PLA — aligns with global trends.
> - Bespoke commercial applications — jewellery, aerospace one-offs, airport rapid repair parts reducing inventory needs.
>
> **Threats:**
> - Intense competition — one of eight majors; Breskko is Ennland-based with a very similar range.
> - Economic/global volatility — interest rates and inflation hit supplier costs and customer demand.
> - Regulatory/legal risk — H&S and environmental legislation; non-compliance = heavy penalties.
> - Technological obsolescence — rapid CAD/hardware change — continuous high-cost R&D needed.

## Exercise CH5-EX — PESTEL analysis of the 3D printer industry

**Requirement:** Conduct a PESTEL analysis on the 3D printer industry. (Core Activity B familiarisation.)

> [!question]- Reveal answer plan
> **Framework:** PESTEL
>
> **Solution points:**
> - Political: government business legislation (Chair Madda Fedele is an ex-government legislator); regulators developing sustainability targets — engage so targets are realistic/effective; H&S duty-of-care oversight on product operation/manufacturing safety.
> - Economic: exposure to global economic trends (foreign interest-rate rises fighting inflation); volatile sales demand — earnings variability plus inventory overinvestment; exchange-rate risk (global trade, E$ reporting — currency losses); 3D printing is cheaper for one-offs but dearer than mass production for identical parts.
> - Social: growing medical reliance (dental implants, heart valves, artificial limbs); customisation culture (bespoke jewellery etc.); skills shift to specialised engineering/CAD from manual fabrication.
> - Technological: rapid prototyping via CAD plus HD scanners; diverse printing technologies (extrusion, SL, laser melting, material jetting); material innovation (ABS, PLA, titanium, gold, ceramics, carbon fibre); integration challenge — constant updates to interface with leading CAD packages.
> - Environmental: sustainable production (less waste vs subtractive); reduced carbon footprint via localised printing (airports); recyclability of plastics (PLA/ABS often 80–100%); energy-efficiency focus (kWh/kg, nozzle-temperature adjustments).
> - Legal: product liability — mission-critical failures expose manufacturers legally; regulatory approvals (EHS approval before medical use); IP and compliance — legal departments needed so environmental/safety non-compliance doesn't bring penalties.

## Exercise CH7-EX — Risk register and additional risks

**Requirement:** Review Kwirtmak's Principal Risks on page 16. (1) If Kwirtmak were to produce a risk register, what additional information should be included? (2) What other risks does Kwirtmak face and how could they be mitigated? (Core Activity D familiarisation.)

> [!question]- Reveal answer plan
> **Framework:** Risk register fields; risk identification and mitigation
>
> **(1) Register fields to add:**
> - Risk description and impact — causes plus specific impact pathways (e.g. supply-chain disruption → production delays → dissatisfied customers).
> - Likelihood and impact ratings — e.g. 1–5 scales — for prioritisation and resource allocation.
> - Overall risk rating — a combined score — flags critical risks needing immediate attention vs monitor-over-time.
> - Date identified plus review dates — keeps risks relevant; mitigations updated as circumstances change.
> - Residual risk rating — post-mitigation exposure — decide if further action is needed.
> - Risk owner — named accountability plus a contact point — e.g. the Marketing Director owns sales-demand volatility; the Operations Director owns hardware-flaw risk.
>
> **(2) Additional risks and mitigations (non-exhaustive):**
> - Cybersecurity — complex software/CAD plus no IT Director — attacks, ransomware, IP theft — appoint an IT Director; firewalls/encryption; regular penetration testing.
> - Ethical/legal product misuse — printers could make weapons/counterfeits — strict KYC vetting; software safeguards restricting regulated items.
> - Reputational — mission-critical aerospace/automotive parts — rigorous factory QC; thorough software-update testing; transparent customer communication.
> - Technological obsolescence — new applications (carbon fibre, bioprinting) — continuous R&D; university tech partnerships — stay ahead of Breskko.
> - Supply-chain disruption — third-party parts/materials/spares — diversify suppliers; close vendor relationships; inventory buffers.
> - Regulatory change — evolving H&S/environmental law — the Legal Department monitors developments for full compliance.
> - Market competition — 8 majors including Breskko with higher revenues — customer-need innovation; overdeliver; superior technical advice.
> - Environmental/sustainability compliance — energy-intensive printing — energy-efficient processes (the 32% PLA cut); proactive regulator engagement on emissions.
> - Consumer preference shifts — volatile demand — earnings variability, inventory overinvestment — Marketing monitors trends, close major-customer relationships, capability updates.
> - Economic risks — foreign rate rises/inflation hit suppliers and customers — Treasury monitors indicators and recommends strategies; minimise operating costs.
> - Currency fluctuations — three overseas factories plus international customers — Treasury actively uses forward contracts, money market hedges, currency options.

## Exercise CH8-EX — Corporate governance evaluation

**Requirement:** Evaluate the corporate governance structure at Kwirtmak. (Assume Ennland governance guidance is principles-based, similar to the UK.) (Core Activity E familiarisation.)

> [!question]- Reveal answer plan
> **Framework:** UK-style principles-based code — board balance, audit committee composition, chair restrictions, committee structure, independence threats, skills gaps
>
> **Solution points:**
> - Listed since 2004 — a well-regulated environment — expected to adhere to a principles-based Code of Corporate Governance.
> - Executive strengths — CEO (PhD precision control, ex-CTO), Operations Director (chemical engineering; factories/quality/H&S/sustainability), CTO (PhD molten plastics; R&D), CFO (qualified accountant; reporting/treasury), Marketing Director (B2B sales career; marketing/PR/customer service); Chair Madda Fedele ex-senior government administrator (business legislation).
> - Director shareholdings (presumed) — align director and shareholder interests — reduce agency issues and monitoring costs.
> - Imbalance — 5 executives vs 3 independent NEDs (Rothenberg, Usta, Abersek) — guidance wants equal exec/non-exec numbers — weakens independent oversight and challenge.
> - Audit-committee gap — should be independent NEDs with at least one member of recent and relevant financial experience (ex-CFO/audit partner) — the NEDs are an economist, an academic and a tech entrepreneur — the CFO being an accountant doesn't fix the NED-side scrutiny gap.
> - Familiarity/independence threats — Wallace, Abouchdak and Usta share University of Central City ties; Wallace and Fedele share Capital City University ties — formal research projects with these universities could compromise oversight and risk confidentiality breaches.
> - Committees — Audit, Risk & CSR, Remuneration and Nomination exist BUT with identical membership (Fedele, Rothenberg, Usta, Abersek) — poor practice.
> - Chair issues — the Chair on the Audit Committee is against best practice; on the Remuneration Committee also discouraged unless independent on appointment.
> - Combined Risk & CSR Committee — given environmental scrutiny plus complex global supply-chain risks — insufficient time for either area.
> - Compliant — CEO/Chair roles separated (Wallace runs operations; Fedele runs the Board) — an effective balance of power.
> - Skills gaps — an IT/Cyber Director is urgently needed (software/CAD reliance — cyber/IP/ransomware exposure); a dedicated Chief Sustainability Officer (energy-intensive industry; currently bolted onto Operations); an HR Director (values-led, skills-dependent workforce; international employment-law compliance); a CRO/CCO (H&S/environmental penalty exposure; Legal is below board level); global supply-chain expertise (the Operations Director is a chemical engineer, not a logistics specialist).
> - Exam note — this board mirrors previous SCS pre-seens — expect the unseen to add problems (director departures, independence issues).
