# QB - Mock Exam D (Titan Cycles)

> [!warning] ⚠ Answer plans built from your own attempt (no Kaplan model answer exists for this mock); ⭐ = added enrichment points.

**Scenario spine:** Titan Cycles is a 4-year-old company that 3D-prints carbon-fibre components for the cycling industry. Its founder-CEO is passionate about cycling and is seeking investors because Titan is running low on cash. Titan holds a patent in Northland (global patent not yet granted) and is preferred supplier to professional cycling Team Alpha. Kwirtmak is considering acquiring Titan / buying 30% of its share capital, or alternatively developing 3D printers for the cycling industry in-house. Task 3 turns on governance: an email from Madda Fedele revealing pre-agreed board arrangements with Kwirtmak's largest shareholder.

---

## Task 1 — Evaluate acquisition of Titan Cycles (SAF + internal controls) (60 min · Core Activity A)

**Trigger:** Titan Cycles, a 3D printing company only 4 years old, specialises in printing premium carbon-fibre components at competitive cost and is preferred supplier to cycling Team Alpha. It holds a patent in Northland, though a global patent may not be granted, and its CEO is actively seeking investors — suggesting Titan is short of cash. Kwirtmak's board is considering acquiring the company.

**Requirement:** (a) Evaluate the proposed acquisition of Titan Cycles using the Suitability, Acceptability, Feasibility framework. (b) Discuss the internal controls Kwirtmak would need to put in place to make the acquisition a success.

> [!question]- Reveal answer plan
> **Framework:** Johnson, Scholes & Whittington — Suitability / Acceptability / Feasibility; then internal control environment (people, quality, IT, financial oversight).
>
> **Plan:**
>
> *Suitability*
> - Strategic fit of technology — Titan prints advanced carbon-fibre components; Kwirtmak understands 3D printing, so it could help scale the process, or even design new and better printers around the technology, creating a new revenue stream from customers wanting carbon-fibre products (pre-seen: Kwirtmak's core competence is 3D printers).
> - Capability gap filled — Kwirtmak does not yet have this materials technology, so acquiring Titan and absorbing its staff brings in knowledge and expertise it lacks.
> - Brand fit — Titan's high-quality premium components sit well with Kwirtmak's trusted, premium, innovator brand image; expansion here reinforces Kwirtmak's commitment to innovation and quality.
> - Caution on demand — the CEO's infectious passion for cycling may overstate demand; customers may be content with mass-produced tooled components, so demand for bespoke carbon-fibre manufacture may be lower than claimed. Only 4 years of trading — market awareness exists but contract book is unknown.
> - Conclusion: suitable — fits Kwirtmak's mission of high-quality products and commitment to innovation.
>
> *Acceptability*
> - Shareholder return risk — Kwirtmak's share price is depressed and revenue is falling (pre-seen: revenue E$2,320m, down 18.8%); the purchase consumes debt capacity or cash and distracts management from the core business, which shareholders may resent.
> - Counter — shareholders may welcome diversification into a patent-protected revenue stream that aligns naturally with Kwirtmak's goals.
> - Patent value is conditional — the Northland patent offers protected growth, but the global patent is uncertain: value the Northland market, then apply a probability weighting to the global market value.
> - Risk-culture red flag — Titan seeking investment suggests weak cost control; Kwirtmak itself has a falling operating margin, so acquiring a company with a similarly sub-par cost-control culture could look like a risky revenue bet instead of fixing costs.
> - Demand evidence — preferred-supplier status with Team Alpha shows real demand; Kwirtmak's marketing and innovation muscle could convert it into more.
> - ⭐ Quantify risk appetite formally — shareholders' required return should reflect Kwirtmak's high beta (2.3): a risky acquisition raises the return the market demands; consider stakeholder reaction mapping (Mendelow) for employees and Team Alpha too.
> - Conclusion: acceptable, provided internal controls are installed and risks mitigated.
>
> *Feasibility*
> - Financing capacity exists — interest cover ~10.9x and gearing ~39.1% leave headroom for some debt; cash of E$136.2m could fund all or part of the price.
> - Cost of funds — cash is not free: it carries an equity cost, so the required rate of return must be met; use a debt/equity mix consistent with optimising WACC.
> - Due diligence gap — value of Titan's potential contracts is uncertain; analyse the durability of the Team Alpha preferred-supplier relationship and the size of the bespoke carbon-fibre market before committing.
> - Management bandwidth — the acquisition could distract management at a time of low share price and falling market share, risking further erosion of the core business.
> - ⭐ Non-financial feasibility — does Kwirtmak have the integration skills and materials-science expertise to absorb Titan, and can it retain the key Titan people the deal depends on?
>
> *Internal controls needed*
> - Retention/HR controls — Titan's staff hold the carbon-fibre know-how; understand what motivates them, keep them post-acquisition (e.g. share-for-share offers to employee-shareholders) so knowledge transfers rather than walks.
> - Quality assurance controls — only the CEO's word attests to product quality; independently verify output quality, technical challenges and production waste; Titan's cash hunger may itself signal weak cost control over production.
> - IT integration controls — merging the two companies' IT is risky and Kwirtmak has **no IT Director** (pre-seen gap); appoint one before acquisition to own systems integration and to evaluate Titan's information-security posture, which is currently invisible to Kwirtmak.
> - Financial oversight — install strong reporting over the integrated entity with targets aligned to group goals; map Titan's financials (not yet seen) before completion.
> - ⭐ Formal due diligence programme (financial, legal/patent, commercial) and post-acquisition integration plan with board-level milestones — the classic control wrapper a model answer would name.
>
> **L3 hooks:** Kwirtmak's "trusts its staff" value vs. imposing controls on Titan's team; no IT Director on the board (recurring pre-seen weakness); falling revenue/share price makes shareholder patience the binding constraint; beta 2.3 = market already sees Kwirtmak as high-risk, so every new risk is amplified.

---

## Task 2.1 — Recommend approach to pricing 30% of Titan's share capital (30 min · Core Activity D)

**Trigger:** The proposal has narrowed: Kwirtmak can acquire only 30% of Titan Cycles' share capital — a minority stake. The board needs a basis for deciding what price would be acceptable to pay.

**Requirement:** Recommend, with reasons, the approach Kwirtmak should take to deciding an acceptable purchase price for 30% of Titan Cycles' share capital.

> [!question]- Reveal answer plan
> **Framework:** Business valuation methods (net assets, dividend-based, NPV/DCF of future cash flows) overlaid with minority-stake logic and negotiating position.
>
> **Plan:**
>
> *Nature of a 30% stake — value drivers before the arithmetic*
> - Influence is limited — 30% may not confer control; analyse Titan's ownership structure to see whether Kwirtmak becomes the largest shareholder able to influence strategy, or whether the CEO (or another holder) retains majority control and Kwirtmak cannot replace her or install a managing director.
> - Diagnose why Titan is unprofitable — 4 years without profit: is there a core flaw (no worthwhile end-market for the technology) or just normal start-up hurdles? The answer changes the price fundamentally.
> - Value of learning — even as a minority holder, Kwirtmak may learn carbon-fibre printing techniques applicable elsewhere; weigh that learning value into the price even without control. Negotiate board representation in the deal so knowledge-sharing and synergies can actually be extracted.
> - Synergies justify a premium in principle — but the achievable synergy is capped by minority status, so any premium should be capped too.
>
> *Valuation approaches*
> - Net assets — simple baseline from the financial statements; likely very low given heavy sunk investment and no returns, which favours Kwirtmak; also gives a floor: if the venture fails, assets could be sold to recover the investment.
> - Dividend valuation — **not appropriate**: Titan has never paid dividends because it has never made a profit; but tactically usable in negotiation to highlight investment risk and justify a lower price.
> - NPV of future cash flows — the most appropriate conceptually, but highly uncertain: no solid customer contracts; the Northland patent market must be sized, and the probability of a global patent grant assessed (use a patent-law expert), before forecast cash flows are credible. Recommend a full commercial analysis of contract sizes (incl. Team Alpha).
> - ⭐ P/E or revenue multiples of comparable listed 3D-printing/advanced-materials firms as a sanity cross-check — standard model-answer addition where the target is loss-making.
>
> *Adjustments and negotiation*
> - Minority discount — discount the pro-rata NPV value because Kwirtmak lacks control over strategy.
> - Distress leverage — Titan needs cash to avoid wasting investor capital, strengthening Kwirtmak's negotiating hand; press for a better price.
> - Competitive tension — unclear whether Breskko has been approached; if there is no rival bidder, there is no urgency, so an extended negotiation can be used to optimise the price.
> - ⭐ Recommend a **range**, not a point estimate: net assets as floor, risk-adjusted NPV (patent-probability-weighted, minority-discounted) as ceiling, with a walk-away price agreed by the board in advance.
>
> **L3 hooks:** Kwirtmak's E$136.2m cash means it can pay without new debt — but cash carries an equity cost; Breskko as the ever-present rival bidder; any DCF discount rate must reflect Kwirtmak's beta of 2.3 (high cost of equity) plus a further start-up risk premium for Titan.

---

## Task 2.2 — Evaluate in-house R&D into 3D printers for the cycling industry (30 min · Core Activity B)

**Trigger:** As an alternative (or complement) to investing in Titan, the board is considering starting its own in-house research into developing 3D printers aimed at the cycling industry — a market Kwirtmak does not currently serve and where Titan already holds a Northland patent.

**Requirement:** Evaluate the arguments for and against Kwirtmak starting in-house research into developing 3D printers for the cycling industry.

> [!question]- Reveal answer plan
> **Framework:** Balanced for/against evaluation (make-vs-buy on innovation), closed with a justified position.
>
> **Plan:**
>
> *Arguments for*
> - Full capture of returns — in-house research means Kwirtmak keeps all the profits rather than sharing them via a 30% minority stake in Titan.
> - Cost discipline — Kwirtmak can control R&D spend in line with its established R&D project governance; Titan, as an inexperienced company, may have overspent investor funds developing its technology, and buying it could mean paying for that inefficiency. In-house may be cheaper in the long run than Titan's asking price (compare the numbers).
> - Spillover benefits — the research could spawn new applications, Kwirtmak's own patents, licensing income, and sales into other markets (e.g. carbon fibre for medical prosthetics); hard to quantify but potentially valuable.
> - Capability building — in-house work deepens employees' skills and gives an integrated understanding of the technology, kept inside the company rather than outsourced at greater expense.
> - Existing R&D machine — Kwirtmak already has the R&D skills, goal-setting and cost-control experience for projects of this type (pre-seen: innovation is core to Kwirtmak).
>
> *Arguments against*
> - Significant upfront cost — market sizing and analysis take time and money, distract the Marketing Director, and the cash spent carries an equity cost; must be tested against alternative uses of funds.
> - Time to payback — in-house research is slow; with the share price already down, shareholders wary of management's strategy may not tolerate a long wait for returns.
> - Second-mover risk — Titan already has a head start; if Kwirtmak is late to market it may never recoup its costs (though Kwirtmak's scale and marketing muscle could still win share — a gamble).
> - No cycling-industry expertise — Kwirtmak doesn't operate in cycling and no board member appears to know the industry; partnering with Titan (whose CEO knows the market) would have de-risked this.
> - Duplication of effort — re-running research Titan has already done wastes cost and time versus buying in, potentially at a negotiated discount.
> - Opportunity cost — the project crowds out other R&D; rank all projects via capital budgeting (NPV against WACC) to confirm this is the best use of resources.
> - No route to market — Kwirtmak has no cycling-industry connections or knowledge of how to sell to it; building them costs marketing resource that may be better used elsewhere.
> - **Patent infringement risk** — the development may overlap Titan's Northland patent; legal and technical review of the patent landscape is needed to avoid producing technology Kwirtmak cannot legally sell.
> - ⭐ Balanced conclusion expected — e.g. the patent barrier plus lack of industry knowledge tilts against pure in-house R&D unless the Titan deal fails; a staged option (small feasibility study first) preserves flexibility.
>
> **L3 hooks:** Kwirtmak's brand rests on innovation, so "we don't do our own R&D here" jars culturally; falling revenue (−18.8%) means new growth engines are needed but cash discipline matters; Breskko could equally partner with Titan if Kwirtmak walks away — competitive-response angle.

---

## Task 3.1 — Ethical issues in Madda Fedele's email (30 min · Core Activity E)

**Trigger:** An email from Madda Fedele reveals that the composition of the post-deal board has effectively been pre-arranged: she has agreed board appointments in advance with Kwirtmak's largest shareholder, all but one of Titan's executive directors will be forced to step down with "generous" payoffs (to be set by the remuneration committee), and the CEO has personally guaranteed the NEDs their jobs — all before the nomination committee has assessed any candidates.

**Requirement:** Evaluate the ethical issues arising from the points made in Madda's email.

> [!question]- Reveal answer plan
> **Framework:** CIMA ethical principles (objectivity, integrity, professional behaviour) + governance principles (independence of board committees, fair treatment of shareholders).
>
> **Plan:**
> - Pre-empting the nomination committee — board changes have been suggested before the nomination committee has assessed nominees; this jeopardises the committee's independence and risks a less objective outcome, since more suitable candidates may never be considered.
> - Deal with the largest shareholder — agreeing appointments with the largest shareholder before the committee's assessment entrenches that shareholder's interests and gives no weight to smaller shareholders — unfair treatment that may alienate them (⭐ breaches the governance principle of equitable treatment of all shareholders).
> - Forcing out Titan's directors — removing all but one Titan executive discards experience and knowledge crucial to the new venture's success; it looks like a self-serving move by incumbents to protect their own board seats — this decision should be independently assessed by the nomination committee.
> - "Generous" payoffs — signalling generosity in advance risks spending significant shareholder wealth merely to smooth the transition, enriching individuals with no return to shareholders; correctly, the final level should be left to the remuneration committee to judge value for shareholders (⭐ payments for loss of office may also require shareholder approval/disclosure — rewards-for-failure optics).
> - CEO guaranteeing NED jobs — NEDs who owe their positions to the CEO become biased in his/her favour and can no longer be perceived as independent, corrupting the entire purpose of NEDs as independent challenge and guidance; suggests the chairman/CEO is seeking to dominate the board (⭐ classic breach of the independence criteria in governance codes; also blurs the CEO/chair power balance).
> - ⭐ Wrap with CIMA code labels: objectivity (committee independence compromised), integrity (secret side-deals), professional behaviour (conduct that discredits the profession/company if made public) — and note Madda putting this in writing creates reputational/legal exposure if leaked.
>
> **L3 hooks:** Kwirtmak's stated values include "trusts its staff" — back-room deals corrode that trust; depressed share price means governance scandals would hit an already fragile investor base; institutional investors and governance codes expect nomination decisions to be committee-led.

---

## Task 3.2 — Recommendations for the nomination committee (30 min · Core Activity E)

**Trigger:** Following the concerns raised by Madda's email, the nomination committee must now run a proper process to determine the composition of the merged group's board.

**Requirement:** Recommend the approach the nomination committee should take in selecting the board of the new group.

> [!question]- Reveal answer plan
> **Framework:** Nomination committee good practice — independence, skills matrix, board balance and dynamics, time commitment.
>
> **Plan:**
> - Independent NEDs — select NEDs with no specific allegiance to Kwirtmak or Titan, so they guide the business in shareholders' interests free of preference bias, rather than serving particular individuals' goals.
> - Skills and representation from both entities — build a board reflecting the skills, expertise and experience of both Kwirtmak and Titan, so both sub-entities are properly overseen and the merged group captures the expertise of each — strengthening its chance of success.
> - Board dynamics — consider personalities and existing relationships: long-standing colleagues may avoid challenging each other's ideas to protect relationships, at the expense of shareholder value; strategic options must be appraised independently and without bias.
> - Formal capability assessment — assess each potential executive and non-executive director's knowledge and experience so the board has decision-ready expertise across every business venture; beware promoting someone already carrying significant responsibilities who would be stretched too thin to perform either role well.
> - Counterweight to the chairman — the chairman's domineering conduct (attempting to pre-set the board) should be addressed by appointing members able to challenge ideas robustly; but balance this against cohesion — a perpetually conflicted board makes slow decisions, misses opportunities and responds too late to risk events.
> - Time commitment — evaluate candidates' current responsibilities to confirm they can commit the significant time a high-responsibility role demands, for both immediate decision-making and long-term value creation.
> - ⭐ Process recommendations a model answer would add: use objective criteria/skills matrix and consider external search consultants; disregard the pre-agreed slate and restart selection on merit; ensure at least half the board are independent NEDs (governance code norm); consider diversity of background and thought; report the appointment process transparently to shareholders to rebuild trust after the leaked arrangement.
> - ⭐ Specific gap to fill: the combined group still lacks an IT Director — the merger and systems-integration workload makes this appointment urgent.
>
> **L3 hooks:** No IT Director (pre-seen board gap) is a ready-made "who should be on the board" point; "trusts its staff" culture argues for a transparent, merit-based process; the largest shareholder's influence must be managed through proper channels (AGM votes), not private deals.
