# QB — Mock Exam A (Kaplan, May 2026 sitting)

Three 60-minute tasks, all answered as emails from the Senior Finance Manager to Agata Paluch (CFO). Themes: currency/economic risk, beta & board composition, scenario planning & ransomware.

| | A | B | C | D | E | Total |
|---|---|---|---|---|---|---|
| Task 1 | | 20 | | 13 | | 33 |
| Task 2 | | | 17 | | 17 | 34 |
| Task 3 | 20 | | | 13 | | 33 |
| **Total** | 20 | 20 | 17 | 26 | 17 | 100 |

---

## Task 1a — Challenges of understanding economic (currency) risk (~36 min · 20 marks · Core Activity B)

**Trigger:** CFO Agata Paluch shares an extract from this morning's Board minutes: she presented on economic risks from currency fluctuations and the Board wants her to expand on the issues arising. The minutes set out Kwirtmak's exposure profile — 41% of revenue from Westland aircraft manufacturers (W$), 6% car manufacturers, the remainder across 90 countries, 4 factories in 4 currencies, GP margin 64.3%, and 5 competitors of which only Breskko is Ennland-based.

**Requirement:** *"Firstly, identify and evaluate the challenges associated with understanding the economic risks faced by Kwirtmak in relation to currency fluctuations."*

> [!question]- Reveal answer plan
> **Framework:** Currency risk types — ECONOMIC exposure (long-term competitive/demand effect of FX, vs transaction/translation); implicit demand elasticity, natural hedging, competitor analysis. Structured around 4 sources of uncertainty (4 challenges × 5 marks).
>
> **Plan:**
> - Westland concentration is major but hard to quantify — if W$ weakens vs E$, effective purchase price rises for Westland customers — 41% of revenue from aircraft manufacturers in Westland (W$)
> - Impact hard to determine because customers may hedge themselves — Westland hosts two of the world's largest aircraft manufacturers; such multinationals may hedge their own economic risk, muting the effect on buying decisions
> - Demand may be price-inelastic — printers rapidly create aircraft spares at major airports to avoid hugely expensive downtime; reliability/speed/precision are absolute priorities, so moderate FX-driven price rises may not deter purchases
> - Remaining revenue highly fragmented, impossible to model precisely — monitoring/forecasting exposure across 90 economies and currency pairs is a huge analytical challenge — 6% cars + ~53% various industries in 90 countries
> - Customers may delay/cancel or substitute — printers are expensive capital investments; adverse FX makes them dearer in local currency, so customers defer or switch to cheaper lower-quality alternatives, making global cash flows unpredictable
> - Consumables pricing varies by customer type — larger multinationals may have fixed contract terms pricing materials in their home currencies, while smaller customers buy at prevailing market prices regardless of FX — recurring printing-material revenue
> - Competitor reaction unpredictable — 4 of 5 major competitors are based abroad with different home currencies/cost bases; if E$ strengthens they gain immediate competitive advantage — only Breskko is Ennland-based
> - Rivals' pricing response unknowable — hold local prices to undercut and win share, or raise prices slightly for margin while keeping a pricing edge; uncertainty reduces ability to forecast long-term competitive risk
> - Natural hedge exists but is complicated to assess — 4 factories, each in a different country/currency, spread production costs across currencies: partial natural hedge on the cost side
> - Natural hedge is weak because margins are high — GP margin 64.3% (y/e 31 Mar 2026) means production costs are small vs selling prices, so favourable cost-currency moves cannot meaningfully offset revenue lost to a strong E$
>
> **Conclusion/recommendation:** None required — organised under 4 challenge headers (Westland revenue concentration / Remaining fragmentation / Competitor reaction / Natural hedge mitigation).
>
> **L3 hooks (facts/numbers to cite):** 41% W$ aircraft revenue, two of the world's largest aircraft manufacturers in Westland, 6% car manufacturers, 90 countries, 4 factories in 4 currencies, GP margin 64.3%, 5 competitors (only Breskko in Ennland), spares-at-airports downtime avoidance

## Task 1b — Accept vs mitigate economic risk (~24 min · 13 marks · Core Activity D)

**Trigger:** Same Board-minutes trigger as 1a. Having explained the challenges of understanding currency-driven economic risk, the CFO now needs a balanced evaluation of whether Kwirtmak should simply live with these risks or actively mitigate them.

**Requirement:** *"Secondly, evaluate the arguments for and against accepting economic risks rather than mitigating them."*

> [!question]- Reveal answer plan
> **Framework:** TARA risk responses (contrast Accept vs Reduce), natural hedging, portfolio diversification, cost-benefit of hedging, beta/cost of equity.
>
> **Plan:**
> *For accepting:*
> - Profitability buffer — 64.3% GP margin gives substantial capacity to absorb E$ fluctuations without threatening operational viability
> - Hedging cost may exceed benefit — economic risk is inherently long-term and hard to quantify, so admin/transaction costs of complex financial hedging may outweigh perceived benefits
> - Existing natural hedge — 4 factories in different countries mean costs incurred in the same local currencies as regional sales, partially offsetting currency shifts and reducing need for expensive external instruments
> - Portfolio/geographic diversification — 6% car manufacturers in several countries + revenue spread across 90 countries acts as a natural portfolio hedge; adverse W$ moves may be offset elsewhere
> - Pragmatism — actively hedging 90 different currency correlations is vastly complex and costly; accepting some volatility is the most pragmatic approach
>
> *Against accepting (dangers):*
> - Competitive exposure vs Breskko/foreign rivals — if E$ stays strong while competitors' home currencies weaken, Kwirtmak may be structurally priced out of the Westland aircraft market (41% revenue concentration)
> - Acceptance relies on brand loyalty/technical superiority holding — if the market becomes price-sensitive, refusing operational mitigation (e.g. relocating production to Westland to match revenue currency) could cause permanent, unrecoverable market-share loss
>
> *For mitigating:*
> - Strategic stability + investor perception — beta of 2.3 (noted by Chair) indicates high volatility and higher cost of equity; strategic hedges such as matching currency of long-term debt to W$ revenue streams would reduce cash-flow volatility and lower the risk profile in investors' eyes
> - Pricing consistency as competitive advantage — mitigation allows more consistent pricing to major aircraft/car clients who value long-term cost certainty for budgeting
>
> *Against mitigating:*
> - Operational disruption — effective economic mitigation often needs structural change (moving factories, changing supply chains): high-cost, long-term, hard to reverse if currency trends shift
> - Loss of upside — locking in exchange rates/structures means missing favourable currency movements that would have improved margins
> - Strategic distraction — in a rapidly evolving industry, pursuit of currency stability must not reduce operational flexibility or distract from the core mission to "overdeliver" on technical innovation
>
> **Conclusion/recommendation:** Middle ground — high margins (64.3%) and 90-country diversification permit some acceptance, but total non-mitigation is unsustainable given beta 2.3 and Westland concentration. Avoid high-cost operational changes (factory relocation); use targeted FINANCIAL mitigation of the 41% W$ exposure (currency-matched debt) to stabilise cash flows, reassure investors, and protect the 'Trusted Provider' reputation with aircraft clients while keeping agility.
>
> **L3 hooks (facts/numbers to cite):** GP margin 64.3%, 4-factory footprint, 6% car revenue, 90 countries, 41% W$ concentration, beta 2.3, "overdeliver" mission wording, 'Trusted Provider' reputation

## Task 2a — Does currency risk affect the beta coefficient? (~30 min · 17 marks · Core Activity C)

**Trigger:** One week later, the CFO forwards an email from Madda Fedele, Non-Executive Chair. The Chair notes Kwirtmak's beta is 2.3 ("rather high") and wonders if it is attributable to currency risk, citing 41% of revenue in W$ and an E$44.3m loss on the currency reserve in y/e 31 March 2026. She also notes Treasury is strong and well-resourced and wonders whether more Board-level support is needed.

**Requirement:** *"Firstly, explain whether Kwirtmak's exposure to currency risks is likely to have an impact on the company's beta coefficient."*

> [!question]- Reveal answer plan
> **Framework:** CAPM/beta; systematic vs unsystematic risk; portfolio diversification; translation vs transaction vs economic exposure; efficient markets (prices driven by cash flows, not accounting entries).
>
> **Plan:**
> - Meaning of beta 2.3 — indicates very high systematic risk; shareholder returns significantly exposed to broad market movements (define the concept first)
> - Systematic risk cannot be diversified away — high-beta returns are driven by market-wide economic factors, so holding Kwirtmak makes any portfolio riskier than lower-beta alternatives
> - Currency exposure only affects beta if the whole market moves with those currencies — highly unlikely individual currency movements drive whole-market returns, because FX affects different businesses in different ways (41% W$ revenue)
> - Currency risk is unsystematic and diversifiable — a well-diversified portfolio contains securities reacting inversely to a given currency; e.g. pair Kwirtmak (suffers when E$ strengthens vs W$) with importer shares that benefit from a strong E$ — so high beta is NOT a direct function of currency exposure
> - Beta drivers are empirical, not logical — beta is computed from historic returns of Kwirtmak vs the Ennlandian stock exchange; 2.3 only shows returns are more volatile than the market, not the causes
> - Only an empirical study can settle it — compare currency exposures, betas and returns across a sample of multinationals with similar foreign footprints; no relationship found means the market is not rewarding shareholders for currency risk because it is easily diversifiable
> - The E$44.3m currency reserve loss = translation loss on consolidation of foreign operations — expected given worldwide sales and three overseas factories, each in its own currency; FX will inevitably move book values in consolidated statements
> - Translation losses are pure accounting entries, not realised cash flows — capital markets/share prices are driven by expected future cash flows, so translation losses should not affect share prices, market returns, or therefore beta
>
> **Conclusion/recommendation:** Currency exposure is unsystematic/diversifiable and translation losses are non-cash, so currency risk is unlikely to drive the 2.3 beta; only an empirical study could establish a link.
>
> **L3 hooks (facts/numbers to cite):** beta 2.3, 41% W$ revenue, E$44.3m currency reserve loss (y/e 31 Mar 2026), three overseas factories (4 total, each own currency), beta measured against the Ennlandian stock exchange

## Task 2b — Executive Director for treasury management (~30 min · 17 marks · Core Activity E)

**Trigger:** Same Chair email as 2a. Madda Fedele, noting the strong Treasury Department, floats whether treasury needs more Board-level support — i.e. appointing an executive director responsible for treasury management.

**Requirement:** *"Secondly, evaluate the advantages and disadvantages of expanding Kwirtmak's Board to include an executive director responsible for treasury management."*

> [!question]- Reveal answer plan
> **Framework:** Corporate governance code principles — board balance (EDs vs NEDs), independence, "constructive challenge", "tone at the top", role of Audit/Risk Committees, CFO remit/accountability.
>
> **Plan:**
> *Advantages:*
> - Elevates financial risk to strategic Board-level priority — the E$44.3m currency-reserve loss and 2.3 beta have signalled to the market that cash-flow volatility worries investors
> - "Tone at the top" reassures stakeholders — a dedicated director signals commitment to stabilising returns
> - Specialist at the table integrates treasury into every high-level decision — e.g. pricing strategies for aircraft clients and management of E$1.35bn borrowings
> - Could lower cost of equity — reduces the risk premium investors attach to the unhedged W$ exposure
>
> *Disadvantages:*
> - Board balance breach — board already skewed at 5 EDs vs 4 NEDs; a 6th ED further dilutes independence and weakens NEDs' ability to give "constructive challenge"
> - Costly knock-on hiring — restoring compliant balance would need at least 2 more NEDs; finding people with the right industry expertise and independence is high-cost and slow (months), leaving interim non-compliance and governance uncertainty
> - Fragmented leadership / blurred accountability — treasury is traditionally core to the CFO's remit; a separate director blurs lines of accountability (would undermine the CFO's authority — audience-aware point)
> - Wrong diagnosis — Treasury Department is already strong and well-resourced, so technical capability is not the problem; the real issue may be information flow to the Board, and a new director could just add costly bureaucracy without improving hedging outcomes (the Chair's own statement)
>
> **Conclusion/recommendation:** The appointment is a "disproportionate and governance-flawed response"; risks of unbalancing the Board and undermining the CFO's authority outweigh benefits. Better alternative: strengthen reporting lines between the Head of Treasury and the Audit or Risk Committees — gives the Chair/NEDs strategic transparency without the cost of expanding the executive team or hiring balancing NEDs.
>
> **L3 hooks (facts/numbers to cite):** E$44.3m currency-reserve loss, beta 2.3, E$1.35bn long-term borrowings, board of 5 EDs vs 4 NEDs (already imbalanced), Treasury strong and well-resourced, 41% W$ exposure

## Task 3a — Scenario planning: three treasury scenarios (~36 min · 20 marks · Core Activity A)

**Trigger:** One week later. The CFO brings a just-published Ennland Daily article: a ransomware attack disrupted rival Breskko's treasury systems, halting payment processing; Breskko says systems will be back within 24 hours and refuses to say whether it will pay the ransom. The CFO wants Treasury prepared for treasury risks.

**Requirement:** *"Firstly, using a scenario planning approach, recommend with reasons responses to each of the following scenarios: 1. The E$ strengthens against the W$, in which Kwirtmak invoices 41% of its revenues; 2. Interest rates in Ennland increase significantly. Kwirtmak has E$1.35 billion of variable rate borrowings; 3. The IT systems used by the Treasury Department to process payments has been disrupted."*

> [!question]- Reveal answer plan
> **Framework:** Scenario planning (worst-case modelling, contingency plans); cash-flow forecasting with FX sensitivity/what-if; interest-rate risk management (fixed vs variable mix, interest cover); business continuity/disaster recovery (hot backup site, communication plan, retained consultants). One header per scenario: impact → responses → justification.
>
> **Plan:**
> *Scenario 1 — E$ strengthens vs W$:*
> - Impact: W$ receipts unchanged in number but convert to far fewer E$ — significant hit to reporting-currency cash flows/profits (41% W$ invoicing)
> - Anticipate a maximum likely E$/W$ movement based on historical analysis (worst-case parameter)
> - Prepare regular cash-flow forecasts of W$-invoiced receipts, supplemented with variations at different assumed exchange rates (sensitivity versions)
> - Use forecasts to secure liquidity headroom — e.g. negotiate an overdraft facility with Group banks sized to the predicted worst-case scenario
> - Medium-term: if the shift persists, inform Ouyang Qi (Marketing Director) so pricing strategy can change; hold a contingency plan for changing selling prices of both printers and associated raw-material supplies to offset the E$ value fall
>
> *Scenario 2 — Ennland interest rates rise significantly:*
> - Rates don't move without underlying economic causes — Treasury should understand the drivers, since higher rates raise the cost of servicing variable-rate debt and cut profitability (E$1.35bn variable borrowings)
> - Monitor economic indicators (e.g. rising inflation, which governments target with rates) to forewarn the Board of likely increases
> - Maintain strong lender relationships so concessions can be negotiated if cash flows strain — e.g. deferring additional interest payments
> - Headroom calculation: finance charges currently covered 10.9 times by operating profit — Kwirtmak could afford even significant rate rises (computed from the financial statements)
> - Still worth converting a proportion of the E$1.35bn (currently ALL variable) to fixed rate for balance; lenders charge more, but it removes worry about future rises
>
> *Scenario 3 — Treasury IT payment systems disrupted:*
> - Framing: fortunate it hit a competitor first — opportunity to assess own vulnerabilities, improve IT controls, and build scenario plans (Breskko article)
> - Ideally a HOT backup facility mirroring records in real time, able to take over quickly on main-system failure
> - Backup must be geographically distant from the main site ("so, not on the outskirts of Capital City") to avoid shared events like power failure, and capable of communicating with Kwirtmak's banks so receipts/payments continue
> - Backup alone insufficient — prepare a stakeholder communication plan (customers, suppliers, employees) in case switchover fails
> - Keep IT consultants on retainer for guaranteed immediate support; publish realistic restoration forecasts to give stakeholders confidence the crisis is managed
>
> **Conclusion/recommendation:** None labelled — each scenario ends in concrete recommended responses with justification (Level 3 = "Recommends response with justification"; description alone caps at Level 1).
>
> **L3 hooks (facts/numbers to cite):** 41% revenue invoiced in W$, E$1.35bn all-variable borrowings, interest cover 10.9x (computed), Ouyang Qi (Marketing Director), HQ on outskirts of Capital City, Breskko ransomware article (24-hour recovery claim)

## Task 3b — Should Kwirtmak pay a ransomware ransom? (~24 min · 13 marks · Core Activity D)

**Trigger:** Same Breskko ransomware trigger as 3a. Breskko refused to say whether it would pay the ransom; the CFO wants a clear recommendation on Kwirtmak's own policy if criminals ever encrypt its files. (Note: the grid header prints "17 marks" but the summary grid reconciles Task 3 as 20 + 13, so this is effectively 13 marks — likely a typo in the answers PDF.)

**Requirement:** *"Secondly, recommend with reasons whether or not Kwirtmak should pay any ransom that is demanded by criminals who manage to encrypt our files using ransomware."*

> [!question]- Reveal answer plan
> **Framework:** Cyber-risk response reasoning; counterparty/game-theory logic about criminals; corporate governance/shareholder accountability. No formal named framework.
>
> **Plan:**
> - Payment could be wasted money — payees are criminals with no guarantee of honouring the "agreement"; data may remain encrypted
> - Paying invites repeat targeting — having shown willingness to pay once, criminals may return with further demands and no real prospect of releasing the data
> - Decrypting actually endangers the criminals — releasing decryption tools makes them easier to trace, report and prosecute; once paid they can simply disappear anonymously, so no incentive for good faith
> - Counter-argument (raise then rebut): public knowledge that payment led to decryption would make future victims likelier to pay, giving hackers an incentive to decrypt — but most companies keep successful hacks secret, weakening this effect
> - Even "honest" hackers may plant further malware while in control — enabling a second, more damaging attack; a paid victim is a more desirable repeat target; malware could also hijack bank accounts or harvest valuable data
> - Governance/shareholder angle — paying could be seen as weak corporate governance; any IT-dependent company should have robust security, certainly Kwirtmak with its CAD software and likely IT integration with customers (printers need periodic software updates), which raises the stakes because customers' systems must also be protected
> - Director accountability — if financial statements show a ransom payment, shareholders will ask why the company was ever dependent on hackers for its own data; directors could lose their positions even if they believed there was no alternative
>
> **Conclusion/recommendation:** Do not pay — every substantive reason argues against payment (one-sided recommendation delivered through balanced-looking discussion: strongest counter-argument raised and immediately rebutted).
>
> **L3 hooks (facts/numbers to cite):** Breskko ransomware attack (24-hour recovery claim, silence on ransom), Kwirtmak's CAD software dependence, printers' periodic software updates implying IT integration with customers, ransom visible in financial statements

---

## Technique takeaways from this mock

- **Email format every time:** To/From/Subject header, one-line scope-setting intro ("Please find below my evaluation of..."); subject line can name both sub-tasks. Write to the addressee — respect the CFO's position/authority, reference the Chair by name when the trigger came from her.
- **Headers mirror the marking grid:** one header per challenge/argument-block/scenario (e.g. Task 1a's 4 challenge headers = 4 grid traits at 5 marks each; Task 3a's headers exactly mirror the three numbered scenarios).
- **Level 3 = justification tied to specifics:** every grid runs Level 1 (identifies/describes) → Level 2 (evaluates/explains/recommends) → Level 3 (with JUSTIFICATION). Anchor every theory point to a pre-seen number, person or place (41%, 64.3%, 90 countries, 2.3, E$44.3m, E$1.35bn, Ouyang Qi, Capital City).
- **Define the concept first** in technical questions (Task 2a opens by explaining what beta means) — definitional grounding scores.
- **Compute at least one simple ratio** from the pre-seen financials and embed it in prose as evidence (10.9x interest cover in Task 3a).
- **Always conclude with a position**, even when the verb is only "evaluate" — a balanced middle-ground recommendation scores well (Task 1b), and proposing a superior third option (better reporting lines to Audit/Risk Committee instead of a new ED, Task 2b) is a distinguishing feature.
- **One-sided recommendations can still look balanced:** raise the strongest counter-argument and immediately rebut it (Task 3b ransom question).
- **Exploit the "competitor incident" trigger pattern:** a rival's misfortune is a free lesson — "fortunate it happened to Breskko first; audit our own vulnerability."
- **Political/audience awareness:** flag when a proposal would "undermine your authority as CFO" — the marker rewards writing for the actual recipient.
