# Kwirtmak SWOT & likely exam themes

## SWOT (quote elements as hooks in any strategy answer)

**Strengths**
- Diverse product range/expertise — all five printing technologies
- Established position & reputation — founded 1992, listed 2004; premium quality + technical advice
- Global manufacturing & sales — 4 factories, worldwide market → geographic diversification
- Customer loyalty & consumables revenue — customers buy Kwirtmak materials for compatibility → steady stream beyond machines
- Strong technical leadership — CEO and CTO both hold relevant PhDs

**Weaknesses**
- Declining financials — revenue 2,856.6→2,320.0; operating profit 1,611.1→1,174.6
- High beta 2.3 — stock far more volatile than the market
- Dependence on third-party suppliers — disruption/quality issues halt operations, damage reputation
- High product cost — limits appeal to price-sensitive segments
- (Add: no IT Director; governance gaps)

**Opportunities**
- Medical/dental expansion — implants, heart valves, artificial limbs once **EHS-approved**; huge growth
- Advanced materials / carbon fibre — automotive, aerospace, sporting goods (tennis rackets, bike frames)
- Sustainability leadership — waste reduction, local production, recyclable PLA align with global trends
- Bespoke commercial applications — jewellery, aerospace one-offs, airport spare parts reducing inventory needs

**Threats**
- Intense competition — one of 8 majors; **Breskko** Ennland-based with near-identical range, now larger
- Economic/global volatility — interest rates, inflation → supplier costs and customer demand
- Regulatory/legal risk — H&S + environmental legislation; heavy penalties
- Technological obsolescence — rapid CAD/hardware change → continuous costly R&D

## The 10 key topics Kaplan flags for the unseen
1. **Declining financial performance** (revenue −18.8%, op profit −27.1%) vs Breskko growth — shareholder concern
2. **High market risk & volatility** (beta 2.3; volatile demand → forecasting difficulty, inventory overinvestment)
3. **Intense competition from Breskko** (near-identical range; now larger and more profitable)
4. **Product quality & mission-critical failures** (aerospace/medical parts → reputational + legal risk)
5. **Currency & global economic exposure** (2026 currency loss E$44.3m vs Breskko E$11.3m)
6. **Supply-chain dependency** (third-party components → operations & reputation)
7. **R&D & technological obsolescence** (E$270m, down from 285; hardware–CAD interface challenge)
8. **Carbon fibre / advanced materials expansion** (strength-to-weight demand)
9. **Regulatory pressure in healthcare** (EHS approval = barrier to entry + compliance burden)
10. **Sustainability & energy consumption** (kWh/kg pressure, metals vs plastics)

## Your own predicted angles (from class notes — keep alive)
- Whistleblowing/halt-operations policy stress-tested: would employees really act? incentives vs empowerment; how would the board handle a whistleblower?
- Short-termism risk: cutting discretionary spend (R&D) to protect margins → damages innovator reputation → investor perception → share price spiral
- New markets: sports/carbon fibre; dental practices once EHS approves
- Dividend policy comparison vs Breskko; financial gearing headroom (cash available but equity has a cost)
- Government links (Fedele/Rothenberg) → lobbying, early warning of legislation
