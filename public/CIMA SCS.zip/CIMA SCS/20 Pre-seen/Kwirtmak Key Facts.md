# Kwirtmak — key facts (learn cold)

The pre-seen ammunition. Every answer needs 2–4 of these woven in — this is what turns Level 2 into Level 3 marks. Drilled in [[Flashcards - Pre-seen Facts]].

## Identity
- **Kwirtmak**: industrial 3D printer manufacturer, founded **1992**, listed on the Ennland stock exchange since **2004**. One of **eight** major global manufacturers.
- **Mission**: "to transform its customers through innovation in design and production."
- **Vision**: to be the **leading provider of additive manufacturing solutions across industries, achieved in a sustainable manner** — the "**trusted provider**".
- **Five values**: creates wealth & success · innovations driven by customer need · **overdelivers on its promises** · **trusts its staff** · staff are team players.
- **Porter generic strategy: differentiator** — "prices tend to reflect the high quality of its products". Premium brand, high product cost (weakness with price-sensitive segments).
- Sells **printers AND compatible materials** — consumables lock-in gives recurring revenue and customer loyalty.
- Markets served: **aerospace, automotive, consumer electronics, jewellery** (medical pending EHS approval).
- Printer technologies (all five): **extrusion, stereolithography (SL), digital light processing (DLP), laser melting, material jetting**.
- Materials: plastics (**ABS** = very strong extrusion filament; **PLA** = biodegradable, lowest energy ~1 kWh/kg; nylon = flexible), metals (titanium, gold, silver, steel...), ceramics, composites (**carbon fibre** = light + rigid; growth in tennis rackets, bicycle frames).

## Footprint & structure
- **Four factories**, each in a different country/currency; largest factory + head office on the **outskirts of Capital City, Ennland**; **three overseas**. Sells into ~**90 countries**.
- **No IT Director** — recurring exam hook (cyber risk, integration risk, board skills gap).
- Revenue mix (Mock A trigger): **41% aircraft manufacturers in Westland (W$)**, 6% car manufacturers, ~53% across 90 countries.
- Dependent on **third-party suppliers** for parts/materials (supply-chain risk).
- Exposure to **health & safety and environmental legislation** — non-compliance = heavy penalties.

## Financials (y/e 31 March 2026, E$m) — see [[Kwirtmak Financial Analysis]] for ratios
- Revenue **2,320.0** (2025: 2,856.6) → **−18.8%**
- Operating profit **1,174.6** (2025: 1,611.1) → **−27.1%**
- Profit for year **810.6**; dividend paid **432.2** → payout **53.3%**, cover 1.9x
- Finance costs **108.0** on long-term borrowings **1,350.0** → implied rate **8%**
- Equity **2,106.3** · Total assets **3,789.1** · Cash **136.2** · PP&E 2,551.3 · Other intangibles 497.2
- R&D **270** (2025: 285, −5.2%) · Tax rate **24%** · Currency reserve loss **44.3** (Breskko only 11.3)
- **Share price ≈ E$50** at 30.4.26 (historically spiked above E$400–500) · **Beta 2.3** (asset beta ≈ 1.55 ungeared)

## Breskko (the rival — near-identical product range, also Ennland-based)
- Revenue **3,016.0** (2025: 2,744.6) → **+9.9%** — has now **overtaken Kwirtmak in size**
- Operating margin **53.1%** (Kwirtmak 50.6%) · ROCE **34.2%** stable both years
- Gearing D/(D+E) **29.9%** (Kwirtmak 39.1%) — less financial risk
- Interest cover **14.3x improving** (Kwirtmak 10.9x falling) · Dividend payout ~**70%**, cover 1.4x (confidence signalling?)
- Pushed **PLA printers for 12+ months → 30% of its sales mix** (Kwirtmak: PLA only ~3%)

## Board
| Person | Role | Hooks |
|---|---|---|
| **Madda Fedele** | Non-Exec **Chair** | ex-senior government administrator (business legislation); political connections; sits on ALL committees (governance issue); CCU Senate ties |
| **Dr David Wallace** | **CEO** | PhD precision control; ex-CTO; UCC + CCU alumnus (familiarity threat) |
| **Agata Paluch** | **CFO** | qualified accountant; financial reporting + treasury; usual exam addressee |
| **Dr Said Abouchdak** | **CTO** | PhD molten plastics; R&D; UCC ties |
| **Kristina Eder** | **Operations Director** | chemical engineer; factories, quality, H&S, **sustainability** (reports on it at every board meeting) |
| **Ouyang Qi** | **Marketing Director** | B2B sales career; marketing, PR, customer service |
| **Dr Ada Rothenberg** | **Senior Independent Director** | former Chief Economist; served on 3 government advisory committees |
| **Prof. Ahmet Usta** | NED | academic (UCC tie with Wallace/Abouchdak) |
| **Nina Abersek** | NED | tech entrepreneur; Chair of Ennland Opera |

- Balance: **5 executives vs 4 non-executives (3 independent NEDs + Chair)** → imbalance, weak independent challenge.
- Committees: **Audit, Risk & CSR (combined!), Remuneration, Nomination — all four with IDENTICAL membership** (Fedele, Rothenberg, Usta, Abersek). Chair sits on Audit Committee (against best practice). No NED with recent & relevant financial experience.
- CEO/Chair separated ✓ (the one clean compliance point).
- Missing roles to recommend: **IT/Cyber Director (urgent)**, Chief Sustainability Officer, HR Director, CRO/CCO, supply-chain expertise.

## Sustainability record (deploy on any sustainability question — see [[Answer Playbooks]] §16)
1. **Governance**: Operations Director owns sustainability at board level, reports every routine meeting; dedicated Risk & CSR Committee; **all staff trained in environmental issues and empowered to halt operations on serious environmental concerns** (e.g. excessive emissions).
2. **Inherent resource efficiency**: additive layer-by-layer uses only material required (vs subtractive waste); many plastics recyclable into new filament; design optimisation eliminates multi-part assembly.
3. **Localisation cuts carbon**: print at point of use → no transport emissions (airports print spare parts on site → also faster repairs, no grounded flights).
4. **Continuous improvement**: **32% cut in PLA printing energy** via nozzle-temperature and layer-thickness adjustments.
5. **Regulatory engagement**: Legal Department ensures compliance; proactively works with regulators on "realistic and effective" targets.

## Environment names
Ennland (home, currency **E$**) · Bank of Ennland (central bank) · **EHS** = Ennland Health Service (medical approval body) · Ennland Stock Market · Ennland Daily / Ennland Telegraph (press) · Westland (W$, aircraft) · Wexland (poor country, factory, workbook B1).

## Recurring exam hooks (the issues every mock circles)
- Falling revenue/margins vs Breskko growth — **cost control culture? market share loss? economic trend?** (Ouyang Qi must investigate)
- **Beta 2.3** — high systematic risk → cost of equity → WACC → NPV/share price chains
- **No IT Director** — cyber, integration, board-skills answers
- **Halt-operations empowerment + "trust" values** — double-edged: sustainability strength vs control weakness ("trust is not a control", "trust but verify")
- **"Overdeliver" culture** — lead indicator for corners being cut (security, vetting, procurement)
- Government links (Fedele, Rothenberg) — exploitable strength for regulated markets
- Medical/EHS opportunity · carbon fibre opportunity · PLA/sustainability gap vs Breskko
