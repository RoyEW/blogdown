# Kwirtmak vs Breskko — financial analysis (memorise the bold figures)

All E$m. Learn the 2026 figures and the *direction of travel* — the exam rewards quoting these unprompted. Drilled in [[Flashcards - Pre-seen Facts]].

## Profitability

| Ratio | Kwirtmak 2026 | Kwirtmak 2025 | Breskko 2026 | Breskko 2025 |
|---|---|---|---|---|
| Revenue | **2,320.0** | 2,856.6 (**−18.8%**) | **3,016.0** | 2,744.6 (**+9.9%**) |
| Operating profit | **1,174.6** | 1,611.1 (−27.1%) | 1,600.2 | — |
| Operating margin | **50.6%** | 56.4% | **53.1%** | 53.7% |
| Capital employed | 3,456.3 | 3,122.2 | 4,677.8 | 4,342.6 |
| ROCE | **34.0%** | **51.6%** | **34.2%** | 33.9% |
| Asset turnover | 0.67x | 0.91x | 0.64x | 0.63x |

**Story to tell:** Kwirtmak's revenue collapsed 18.8% but fixed overheads weren't cut at the same pace (R&D only trimmed 285→270 — and that spend is vital), so margin fell 56.4→50.6% and ROCE roughly halved from 51.6% to 34.0%. Breskko grew 9.9%, **overtook Kwirtmak in size** (in 2025 Kwirtmak was larger), and held margin ~53% and ROCE ~34% in both years — it now beats Kwirtmak on margin with excellent cost control. Board must urgently establish: **global economic trend or Breskko stealing market share?** (Ouyang Qi's job; volatile sales demand is already a recognised principal risk.)

## Funding

| Ratio | Kwirtmak 2026 | Kwirtmak 2025 | Breskko 2026 | Breskko 2025 |
|---|---|---|---|---|
| Borrowings | **1,350.0** (unchanged) | 1,350.0 | 1,400.0 (unchanged) | 1,400.0 |
| Equity | 2,106.3 | 1,772.2 | 3,277.8 | 2,942.6 |
| Gearing D/E | **64.1%** | 76.2% | **42.7%** | 47.6% |
| Gearing D/(D+E) | **39.1%** | 43.2% | **29.9%** | 32.2% |
| Interest cover | **10.9x** | 14.9x | **14.3x** | 13.1x |
| Implied interest rate | **8.0%** | 8.0% | 8.0% | 8.0% |
| Dividend cover / payout | **1.9x / 53.3%** | — | **1.4x / ~70%** | — |

**Story to tell:**
- Borrowings static at both firms → gearing fell naturally as retained profits grew equity.
- Kwirtmak is **noticeably more geared** (39.1% vs 29.9%) = higher financial risk — a key board concern given falling profits.
- Identical **8% rates suggest long-term fixed-rate debt** → both protected from rate volatility, certain finance costs.
- Interest cover **10.9x is still comfortable — the concern is the trajectory** (14.9→10.9 falling) while Breskko improved (13.1→14.3). Signals capacity for *some* more debt, but a worsening signal to investors.
- Dividends: Breskko's ~70% payout may be **deliberate confidence signalling**; Kwirtmak's conservative 53% may reflect retaining cash for R&D / a buffer while investigating declining sales. Both policies target stable long-term clienteles.

## Market data
- Share price ≈ **E$50** at 30.4.26; 5-year history highly volatile with spikes above **E$400–500** → severe decline tracks the 2026 results (revenue −19%, operating profit −E$436.5m) while Breskko grew — market fears lost competitive edge.
- **Beta 2.3** = 130% more volatile than the market. Equity beta = business risk + financial risk. Ungeared (book≈market, tax 24%, debt beta 0): **asset beta ≈ 1.55** — even without gearing, core 3D-printing operations carry well-above-market systematic risk.

## Ready-made calculation chains (rehearse — simple arithmetic in prose scores L3)
- **Interest cover**: 1,174.6 / 108.0 = **10.9x** → "could absorb significant rate rises; concern is the falling trend."
- **Implied interest rate**: 108 / 1,350 = **8%** → "suggests fixed-rate long-term debt."
- **New-debt stress test (Mock C)**: +E$2bn debt → total 3,350 → gearing D/E ≈ **159%** ("very aggressive" vs Breskko 42.7%); at say 10%, interest = **E$335m, +210%** → threatens margin and dividend.
- **Materiality test**: compare any proposal to total assets **3,789.1** or revenue **2,320** ("E$2bn = more than half of total assets").
- **Payout**: 432.2 / 810.6 = **53.3%**.
- **Rights issue scale (workbook C2)**: E$1.2bn ≈ **57% of existing equity** — a huge ask at a depressed price.
